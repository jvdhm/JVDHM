<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html b:css='false' b:defaultwidgetversion='2' b:layoutsVersion='3' b:responsive='true' b:templateVersion='1.0.0' expr:class='data:blog.languageDirection' expr:dir='data:blog.languageDirection' xmlns='http://www.w3.org/1999/xhtml' xmlns:b='http://www.google.com/2005/gml/b' xmlns:data='http://www.google.com/2005/gml/data' xmlns:expr='http://www.google.com/2005/gml/expr'>
  <head>
    <meta content='width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1' name='viewport'/>
    <title><data:view.title.escaped/></title>
    <link href='//1.bp.blogspot.com' rel='dns-prefetch'/>
    <link href='//2.bp.blogspot.com' rel='dns-prefetch'/>
    <link href='//3.bp.blogspot.com' rel='dns-prefetch'/>
    <link href='//4.bp.blogspot.com' rel='dns-prefetch'/>
    <link href='//www.blogger.com' rel='dns-prefetch'/>
    <link href='//www.w3.org' rel='dns-prefetch'/>
    <link href='//dnjs.cloudflare.com' rel='dns-prefetch'/>
    <link href='//fonts.gstatic.com' rel='dns-prefetch'/>
    <link href='//pagead2.googlesyndication.com' rel='dns-prefetch'/>
    <link href='//www.googletagmanager.com' rel='dns-prefetch'/>
    <link href='//www.google-analytics.com' rel='dns-prefetch'/>
    <link href='//connect.facebook.net' rel='dns-prefetch'/>
    <link href='//c.disquscdn.com' rel='dns-prefetch'/>
    <link href='//disqus.com' rel='dns-prefetch'/>
    <b:include name='theme-head'/>

    <!-- Jquery Library, Plyr Player and Font Awesome CDN -->
	<script src='https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js'/>
	<script src='https://cdn.jsdelivr.net/hls.js/latest/hls.js'/>
	<script src='https://cdn.plyr.io/3.6.2/plyr.js'/>
	<link href='https://cdn.plyr.io/3.6.2/plyr.css' rel='stylesheet'/>
    <link href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'/>
    <link crossorigin='anonymous' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css' integrity='sha256-h20CPZ0QyXlBuAw7A+KluUYx/3pK+c7lYEpqLTlxjYQ=' rel='stylesheet'/>
    
    <!-- Font Awesome Free 5.11.2 -->
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css' rel='stylesheet'/>
    <link href='https://fonts.googleapis.com/css2?family=Hanuman&amp;display=swap' rel='stylesheet'/>
    <link href='https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@600&amp;display=swap' rel='stylesheet'/>
    <link href='https://fonts.googleapis.com/css2?family=Varela+Round&amp;display=swap' rel='stylesheet'/>

    <!-- Template Style CSS -->
<b:skin version='1.0.0'><![CDATA[/*
-----------------------------------------------
Blogger Template Style
Name:        123MOVIES KH
Version:     1.7.0
Author:      Giant Template
Cracked:   https://www.gianttemplate.blogspot.com/
----------------------------------------------- */

/*
<!-- Variable definitions -->
<Variable name="keycolor" description="Main Color" type="color" default="$(main.color)" value="#1a7d99"/>

<Group description="Theme Widths" selector="body">
  <Variable name="row.width" description="Container Width" type="length" default="970px" min="960px" max="1063px" value="970px"/>
  <Variable name="sidebar.width" description="Sidebar Width" type="length" default="300px" min="250px" max="336px" value="300px"/>
</Group>

<Group description="Theme Fonts" selector="body">
<Variable name="main.font" description="Main Font" type="font" family="'Lato',Segoe UI,Helvetica Neue,Arial,sans-serif" default="normal 400 14px $(family)"  value="normal 400 14px $(family)"/>
<Variable name="meta.font" description="Meta Font" type="font" family="'Lato',Segoe UI,Helvetica Neue,Arial,sans-serif" default="normal 400 14px $(family)"  value="normal 400 14px $(family)"/>
<Variable name="text.font" description="Text Font" type="font" family="'Lato',Segoe UI,Helvetica Neue,Arial,sans-serif" default="normal 400 14px $(family)"  value="normal 400 14px $(family)"/>
</Group>

<Group description="Theme Colors" selector="body">
  <Variable name="main.color" description="Theme Color" type="color" default="#f2992e" value="#ff0000"/>
  <Variable name="title.color" description="Title Color" type="color" default="#ffff" value="#ffffff"/>
  <Variable name="title.hover.color" description="Title Hover Color" type="color" default="$(main.color)" value="#ff0000"/>
</Group>

<Group description="Theme Body" selector="body">
  <Variable name="body.background.color" description="Body Background - Boxed" type="color" default="#f5f5f5"  value="#000000"/>
  <Variable name="body.background" description="Background" type="background" color="$(body.background.color)" default="$(color) url() repeat scroll top left" value="$(color) url() repeat scroll top left"/>
  <Variable name="outer.bg" description="Outer Wrapper Background" type="color" default="#ffffff"  value="#ffffff"/>
  <Variable name="body.text.color" description="Body Text Color" type="color" default="#656565"  value="#656565"/>
  <Variable name="body.link.color" description="Colored Links" type="color" default="$(main.color)"  value="#ff0000"/>
</Group>

<Group description="Main Navbar" selector="div.navbar">
  <Variable name="navbar.bg" description="Navbar Background" type="color" default="#111" value="#111111"/>
  <Variable name="navbar.color" description="Navbar Color" type="color" default="#e7e8e9" value="#ffffff"/>
  <Variable name="menu.color" description="Menu Color" type="color" default="$(navbar.color)" value="#ffffff"/>
  <Variable name="item.hover.bg" description="Menu Link Hover Background" type="color" default="$(main.color)" value="#111111"/>
  <Variable name="item.hover.color" description="Menu Link Hover Color" type="color" default="#ffffff" value="#ff0000"/>
</Group>

<Group description="Sub Menu" selector="div.navbar">
  <Variable name="submenu.bg" description="SubMenu Background" type="color" default="#26272b" value="#111111"/>
  <Variable name="submenu.color" description="SubMenu Color" type="color" default="#f2f2f2" value="#f2f2f2"/>
  <Variable name="subitem.hover.bg" description="SubMenu Link Hover Background" type="color" default="#1f2024" value="#1f2024"/>
  <Variable name="subitem.hover.color" description="SubMenu Link Hover Color" type="color" default="#ffffff" value="#ffffff"/>
</Group>

<Group description="Mega Menu" selector="div.navbar">
  <Variable name="megamenu.bg" description="MegaMenu Background" type="color" default="$(submenu.bg)" value="#26272b"/>
  <Variable name="megamenu.color" description="MegaMenu Color" type="color" default="$(submenu.color)" value="#f2f2f2"/>
  <Variable name="megamenu.hover.color" description="MegaMenu Tab Active Color" type="color" default="#ffffff" value="#ffffff"/>
  <Variable name="megamenu.post.title.color" description="MegaMenu Post Title Color" type="color" default="#f2f2f2" value="#f2f2f2"/>
  <Variable name="megamenu.post.title.hover" description="MegaMenu Post Title Hover Color" type="color" default="$(main.color)" value="#111111"/>
</Group>

<Group description="Breaking News" select="#breaking-wrap">
  <Variable name="breaking.bg" description="Breaking Background" type="color" default="$(main.color)" value="#000000"/>
  <Variable name="breaking.color" description="Breaking Title Color" type="color" default="#ffffff" value="#ffffff"/>
  <Variable name="breaking.hover.color" description="Breaking Title Hover Color" type="color" default="#ffffff" value="#ffffff"/>
</Group>

<Group description="Blog Posts" select="#main-wrapper">
  <Variable name="post.title.color" description="Post Title Color" type="color" default="$(title.color)" value="#ffffff"/>
  <Variable name="post.title.hover.color" description="Post Title Hover Color" type="color" default="$(main.color)" value="#ff0000"/>
  <Variable name="post.text.color" description="Post Text Color" type="color" default="$(body.text.color)" value="#656565"/>
  <Variable name="meta.color" description="Meta Color" type="color" default="#aaa" value="#ffffff"/>
  <Variable name="itempost.title.size" description="ItemPost Title Font Size" type="length" default="17px" min="20px" max="37px" value="17px"/>
  <Variable name="itempost.content.size" description="ItemPost Text Font Size" type="length" default="15px" min="14px" max="20px" value="15px"/>
</Group>

<Group description="Widget Title">
  <Variable name="main.wtitle.bg" description="Main Widget Title Background" type="color" default="#111" value="#111111"/>
  <Variable name="main.wtitle.color" description="Main Widget Title Color" type="color" default="#ffffff" value="#ffffff"/>
  <Variable name="sidebar.wtitle.bg" description="Sidebar Widget Title Background" type="color" default="#111" value="#111111"/>
  <Variable name="sidebar.wtitle.color" description="Sidebar Widget Title Color" type="color" default="#ffffff" value="#ffffff"/>
  <Variable name="tab.active.bg" description="Sidebar Tab Active Background" type="color" default="$(main.color)" value="#3d444f"/>
  <Variable name="tab.active.color" description="Sidebar Tab Active Color" type="color" default="#ffffff" value="#ffffff"/>
</Group>

<Group description="Theme Buttons">
  <Variable name="button.bg" description="Colored Button" type="color" default="$(main.color)" value="#ff0000"/>
  <Variable name="button.color" description="Colored Button Color" type="color" default="#ffffff" value="#ffffff"/>
  <Variable name="darkbutton.bg" description="Dark Button Background" type="color" default="#1f2024" value="#1f2024"/>
  <Variable name="darkbutton.color" description="Dark Button Color" type="color" default="#ffffff" value="#ffffff"/>
</Group>

<Group description="Theme Footer" selector="div.footer-widgets-wrap">
  <Variable name="footer.bg" description="Footer Background" type="color" default="#1f2024" value="#1f2024"/>
  <Variable name="footer.widget.title.color" description="Widget Title Color" type="color" default="#f2f2f2" value="#f2f2f2"/>
  <Variable name="footer.color" description="Footer Color" type="color" default="#f2f2f2" value="#f2f2f2"/>
  <Variable name="footer.hover.color" description="Footer Links Hover Color" type="color" default="$(title.hover.color)" value="#ff0000"/>
  <Variable name="footer.post.title.hover.color" description="Footer Post Title Hover Color" type="color" default="$(post.title.hover.color)" value="#ff4545"/>
  <Variable name="footer.text.color" description="Footer Text Color" type="color" default="#aaaaaa" value="#aaaaaa"/>
</Group>

<Group description="Footer Bar" selector="#sub-footer-wrapper">
  <Variable name="footer.bar.bg" description="Footer Bar Background" type="color" default="#161619" value="#161619"/>
  <Variable name="footer.bar.color" description="Footer Bar Color" type="color" default="#f2f2f2" value="#f2f2f2"/>
  <Variable name="footer.bar.hover.color" description="Footer Bar Links Hover Color" type="color" default="$(title.hover.color)" value="#aaaaaa"/>
</Group>

<!-- Main Font -->
<Variable name="mainfont.medium" description="Main Font Medium" hideEditor="true" type="font" default="normal 500 14px $(main.font.family)" value="normal 500 14px $(family)"/>
<Variable name="mainfont.semibold" description="Main Font SemiBold" hideEditor="true" type="font" default="normal 600 14px $(main.font.family)" value="normal 600 14px $(family)"/>
<Variable name="mainfont.bold" description="Main Font Bold" hideEditor="true" type="font" default="normal 700 14px $(main.font.family)" value="normal 700 14px $(family)"/>
<Variable name="mainfont.italic" description="Main Font Italic" hideEditor="true" type="font" default="italic 500 14px $(main.font.family)" value="italic 500 14px $(family)"/>
<Variable name="mainfont.mediumitalic" description="Main Font Medium Italic" hideEditor="true" type="font" default="italic 500 14px $(main.font.family)" value="italic 500 14px $(family)"/>
<Variable name="mainfont.semibolditalic" description="Main Font SemiBold Italic" hideEditor="true" type="font" default="italic 600 14px $(main.font.family)" value="italic 600 14px $(family)"/>
<Variable name="mainfont.bolditalic" description="Main Font Bold Italic" hideEditor="true" type="font" default="italic 700 14px $(main.font.family)" value="italic 700 14px $(family)"/>

<!-- Meta Font -->
<Variable name="metafont.medium" description="Meta Font Medium" hideEditor="true" type="font" default="normal 500 14px $(meta.font.family)" value="normal 500 14px $(family)"/>
<Variable name="metafont.semibold" description="Meta Font SemiBold" hideEditor="true" type="font" default="normal 600 14px $(meta.font.family)" value="normal 600 14px $(family)"/>
<Variable name="metafont.bold" description="Meta Font Bold" hideEditor="true" type="font" default="normal 700 14px $(meta.font.family)" value="normal 700 14px $(family)"/>

<!-- Text Font -->
<Variable name="textfont.medium" description="Text Font Medium" hideEditor="true" type="font" default="normal 500 14px $(text.font.family)" value="normal 500 14px $(family)"/>
<Variable name="textfont.semibold" description="Text Font SemiBold" hideEditor="true" type="font" default="normal 600 14px $(text.font.family)" value="normal 600 14px $(family)"/>
<Variable name="textfont.bold" description="Text Font Bold" hideEditor="true" type="font" default="normal 700 14px $(text.font.family)" value="normal 700 14px $(family)"/>
<Variable name="textfont.italic" description="Text Font Italic" hideEditor="true" type="font" default="italic 500 14px $(text.font.family)" value="italic 500 14px $(family)"/>
<Variable name="textfont.mediumitalic" description="Text Font Medium Italic" hideEditor="true" type="font" default="italic 500 14px $(text.font.family)" value="italic 500 14px $(family)"/>
<Variable name="textfont.semibolditalic" description="Text Font SemiBold Italic" hideEditor="true" type="font" default="italic 600 14px $(text.font.family)" value="italic 600 14px $(family)"/>
<Variable name="textfont.bolditalic" description="Text Font Bold Italic" hideEditor="true" type="font" default="italic 700 14px $(text.font.family)" value="italic 700 14px $(family)"/>

<!-- Comments Default -->
<Variable name="body.text.font" description="Font" hideEditor="true" type="font" default="14px 'Lato', sans-serif"  value="14px &#39;Lato&#39;, sans-serif"/>
<Variable name="tabs.font" description="Font 2" hideEditor="true" type="font" default="14px 'Lato', sans-serif"  value="14px &#39;Lato&#39;, sans-serif"/>
<Variable name="posts.background.color" description="Post Background" hideEditor="true" type="color" default="$(outer.bg)"  value="#ffffff"/>
<Variable name="posts.title.color" description="Post title color" hideEditor="true" type="color" default="$(post.title.color)"  value="#111111"/>
<Variable name="posts.text.color" description="Post text color" hideEditor="true" type="color" default="$(post.text.color)"  value="#ffffff"/>
<Variable name="posts.icons.color" description="Post icons color" hideEditor="true" type="color" default="$(main.color)"  value="#ff4545"/>
<Variable name="labels.background.color" description="Label background color" hideEditor="true" type="color" default="$(main.color)"  value="#ff4545"/>
*/
/*-- Bayon --*/
@font-face{font-family:'Bayon';font-style:normal;font-weight:400;font-display:swap;src:local('Bayon Regular'),local('Bayon-Regular'),url(https://fonts.gstatic.com/s/bayon/v13/9XUrlJNmn0LPFm-lMBc0dw.woff2) format('woff2');unicode-range:U+1780-17FF,U+200C,U+25CC}
/* Google Font - Kdam Thmor
----------------------------------------------- */
@font-face{font-family:'Kdam Thmor';font-style:normal;font-weight:400;src:local('Kdam Thmor'),local('KdamThmor'),url(https://fonts.gstatic.com/s/kdamthmor/v6/MwQzbhjs3veF6QwJVf0JoG8fiIlP.woff2) format('woff2');unicode-range:U+1780-17FF,U+200C,U+25CC}
/* Google Font - Nokora
----------------------------------------------- */
@font-face{font-family:'Nokora';font-style:normal;font-weight:400;font-display:swap;src:local('Nokora Regular'),local('Nokora-Regular'),url(https://fonts.gstatic.com/s/nokora/v13/hYkIPuwgTubzaWxgNzAOkvY.woff2) format('woff2');unicode-range:U+1780-17FF,U+200C,U+25CC}
@font-face{font-family:'Nokora';font-style:normal;font-weight:700;font-display:swap;src:local('Nokora Bold'),local('Nokora-Bold'),url(https://fonts.gstatic.com/s/nokora/v13/hYkLPuwgTubzaWxohxUbptd9yB8.woff2) format('woff2');unicode-range:U+1780-17FF,U+200C,U+25CC}
/* Google Font - Odor Mean Chey
----------------------------------------------- */
@font-face{font-family:'Odor Mean Chey';font-style:normal;font-weight:400;font-display:swap;src:local('OdorMeanChey'),url(https://fonts.gstatic.com/s/odormeanchey/v11/raxkHiKDttkTe1aOGcJMR1A_4lrU0TukKQ.woff2) format('woff2');unicode-range:U+1780-17FF,U+200C,U+25CC}

/*-- Google Poppins Font --*/
@font-face{font-family:'Poppins';font-style:italic;font-weight:400;src:local('Poppins Italic'),local(Poppins-Italic),url(https://fonts.gstatic.com/s/poppins/v9/pxiGyp8kv8JHgFVrJJLucXtAKPY.woff2) format("woff2");unicode-range:U+0900-097F,U+1CD0-1CF6,U+1CF8-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FB}
@font-face{font-family:'Poppins';font-style:italic;font-weight:400;src:local('Poppins Italic'),local(Poppins-Italic),url(https://fonts.gstatic.com/s/poppins/v9/pxiGyp8kv8JHgFVrJJLufntAKPY.woff2) format("woff2");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Poppins';font-style:italic;font-weight:400;src:local('Poppins Italic'),local(Poppins-Italic),url(https://fonts.gstatic.com/s/poppins/v9/pxiGyp8kv8JHgFVrJJLucHtA.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'Poppins';font-style:italic;font-weight:500;src:local('Poppins Medium Italic'),local(Poppins-MediumItalic),url(https://fonts.gstatic.com/s/poppins/v9/pxiDyp8kv8JHgFVrJJLmg1hVFteOcEg.woff2) format("woff2");unicode-range:U+0900-097F,U+1CD0-1CF6,U+1CF8-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FB}
@font-face{font-family:'Poppins';font-style:italic;font-weight:500;src:local('Poppins Medium Italic'),local(Poppins-MediumItalic),url(https://fonts.gstatic.com/s/poppins/v9/pxiDyp8kv8JHgFVrJJLmg1hVGdeOcEg.woff2) format("woff2");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Poppins';font-style:italic;font-weight:500;src:local('Poppins Medium Italic'),local(Poppins-MediumItalic),url(https://fonts.gstatic.com/s/poppins/v9/pxiDyp8kv8JHgFVrJJLmg1hVF9eO.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'Poppins';font-style:italic;font-weight:600;src:local('Poppins SemiBold Italic'),local(Poppins-SemiBoldItalic),url(https://fonts.gstatic.com/s/poppins/v9/pxiDyp8kv8JHgFVrJJLmr19VFteOcEg.woff2) format("woff2");unicode-range:U+0900-097F,U+1CD0-1CF6,U+1CF8-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FB}
@font-face{font-family:'Poppins';font-style:italic;font-weight:600;src:local('Poppins SemiBold Italic'),local(Poppins-SemiBoldItalic),url(https://fonts.gstatic.com/s/poppins/v9/pxiDyp8kv8JHgFVrJJLmr19VGdeOcEg.woff2) format("woff2");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Poppins';font-style:italic;font-weight:600;src:local('Poppins SemiBold Italic'),local(Poppins-SemiBoldItalic),url(https://fonts.gstatic.com/s/poppins/v9/pxiDyp8kv8JHgFVrJJLmr19VF9eO.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'Poppins';font-style:italic;font-weight:700;src:local('Poppins Bold Italic'),local(Poppins-BoldItalic),url(https://fonts.gstatic.com/s/poppins/v9/pxiDyp8kv8JHgFVrJJLmy15VFteOcEg.woff2) format("woff2");unicode-range:U+0900-097F,U+1CD0-1CF6,U+1CF8-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FB}
@font-face{font-family:'Poppins';font-style:italic;font-weight:700;src:local('Poppins Bold Italic'),local(Poppins-BoldItalic),url(https://fonts.gstatic.com/s/poppins/v9/pxiDyp8kv8JHgFVrJJLmy15VGdeOcEg.woff2) format("woff2");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Poppins';font-style:italic;font-weight:700;src:local('Poppins Bold Italic'),local(Poppins-BoldItalic),url(https://fonts.gstatic.com/s/poppins/v9/pxiDyp8kv8JHgFVrJJLmy15VF9eO.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'Poppins';font-style:normal;font-weight:400;src:local('Poppins Regular'),local(Poppins-Regular),url(https://fonts.gstatic.com/s/poppins/v9/pxiEyp8kv8JHgFVrJJbecmNE.woff2) format("woff2");unicode-range:U+0900-097F,U+1CD0-1CF6,U+1CF8-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FB}
@font-face{font-family:'Poppins';font-style:normal;font-weight:400;src:local('Poppins Regular'),local(Poppins-Regular),url(https://fonts.gstatic.com/s/poppins/v9/pxiEyp8kv8JHgFVrJJnecmNE.woff2) format("woff2");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Poppins';font-style:normal;font-weight:400;src:local('Poppins Regular'),local(Poppins-Regular),url(https://fonts.gstatic.com/s/poppins/v9/pxiEyp8kv8JHgFVrJJfecg.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'Poppins';font-style:normal;font-weight:500;src:local('Poppins Medium'),local(Poppins-Medium),url(https://fonts.gstatic.com/s/poppins/v9/pxiByp8kv8JHgFVrLGT9Z11lFc-K.woff2) format("woff2");unicode-range:U+0900-097F,U+1CD0-1CF6,U+1CF8-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FB}
@font-face{font-family:'Poppins';font-style:normal;font-weight:500;src:local('Poppins Medium'),local(Poppins-Medium),url(https://fonts.gstatic.com/s/poppins/v9/pxiByp8kv8JHgFVrLGT9Z1JlFc-K.woff2) format("woff2");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Poppins';font-style:normal;font-weight:500;src:local('Poppins Medium'),local(Poppins-Medium),url(https://fonts.gstatic.com/s/poppins/v9/pxiByp8kv8JHgFVrLGT9Z1xlFQ.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'Poppins';font-style:normal;font-weight:600;src:local('Poppins SemiBold'),local(Poppins-SemiBold),url(https://fonts.gstatic.com/s/poppins/v9/pxiByp8kv8JHgFVrLEj6Z11lFc-K.woff2) format("woff2");unicode-range:U+0900-097F,U+1CD0-1CF6,U+1CF8-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FB}
@font-face{font-family:'Poppins';font-style:normal;font-weight:600;src:local('Poppins SemiBold'),local(Poppins-SemiBold),url(https://fonts.gstatic.com/s/poppins/v9/pxiByp8kv8JHgFVrLEj6Z1JlFc-K.woff2) format("woff2");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Poppins';font-style:normal;font-weight:600;src:local('Poppins SemiBold'),local(Poppins-SemiBold),url(https://fonts.gstatic.com/s/poppins/v9/pxiByp8kv8JHgFVrLEj6Z1xlFQ.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'Poppins';font-style:normal;font-weight:700;src:local('Poppins Bold'),local(Poppins-Bold),url(https://fonts.gstatic.com/s/poppins/v9/pxiByp8kv8JHgFVrLCz7Z11lFc-K.woff2) format("woff2");unicode-range:U+0900-097F,U+1CD0-1CF6,U+1CF8-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FB}
@font-face{font-family:'Poppins';font-style:normal;font-weight:700;src:local('Poppins Bold'),local(Poppins-Bold),url(https://fonts.gstatic.com/s/poppins/v9/pxiByp8kv8JHgFVrLCz7Z1JlFc-K.woff2) format("woff2");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Poppins';font-style:normal;font-weight:700;src:local('Poppins Bold'),local(Poppins-Bold),url(https://fonts.gstatic.com/s/poppins/v9/pxiByp8kv8JHgFVrLCz7Z1xlFQ.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
/*-- Reset CSS --*/
a,abbr,acronym,address,applet,b,big,blockquote,body,caption,center,cite,code,dd,del,dfn,div,dl,dt,em,fieldset,font,form,h1,h2,h3,h4,h5,h6,html,i,iframe,img,ins,kbd,label,legend,li,object,p,pre,q,s,samp,small,span,strike,strong,sub,sup,table,tbody,td,tfoot,th,thead,tr,tt,u,ul,var{padding:0;border:0;outline:0;vertical-align:baseline;background:0 0;text-decoration:none}form,textarea,input,button{-webkit-appearance:none;-moz-appearance:none;appearance:none;border-radius:0}dl,ul{list-style-position:inside;font-weight:400;list-style:none}ul li{list-style:none}caption,th{text-align:center}img{border:none;position:relative}a,a:visited{text-decoration:none}.clearfix{clear:both}.section,.widget,.widget ul{margin:0;padding:0}a{color:$(body.link.color)}a img{border:0}abbr{text-decoration:none}.CSS_LIGHTBOX{z-index:999999!important}.CSS_LIGHTBOX_ATTRIBUTION_INDEX_CONTAINER .CSS_HCONT_CHILDREN_HOLDER > .CSS_LAYOUT_COMPONENT.CSS_HCONT_CHILD:first-child > .CSS_LAYOUT_COMPONENT{opacity:0}.separator{display:none}#navbar-iframe,.widget-item-control,a.quickedit,.home-link,.feed-links{display:none!important}.center{display:table;margin:0 auto;position:relative}.widget > h2,.widget > h3{display:none}.widget iframe,.widget img{max-width:100%}

/*-- Body Content CSS --*/
:root{--body-font:'Bayon','Josefin Sans',sans-serif;--meta-font:'Bayon','Varela Round',sans-serif;--text-font:'Hanuman','Varela Round',sans-serif;}
body{position:relative;background-color:$(body.background.color);background:$(body.background);font-family:var(--body-font);font-size:14px;color:$(body.text.color);font-weight:400;font-style:normal;line-height:1.4em;word-wrap:break-word;margin:0;padding:0}
.rtl{direction:rtl}
.no-items.section{display:none}
h1,h2,h3,h4,h5,h6{font-family:var(--text-font);font-weight:700}
#outer-wrapper{position:relative;overflow:hidden;width:100%;max-width:100%;margin:0 auto;background-color:#1f2024;box-shadow:0 0 20px rgba(0,0,0,0.1)}
.row-x1{width:$(row.width)}
#content-wrapper{margin:35px auto;overflow:hidden}
#main-wrapper{float:left;overflow:hidden;width:calc(100% - ($(sidebar.width) + 35px));box-sizing:border-box;padding:0}
.index #main-wrapper{width:100%}
#sidebar-wrapper{position:relative;float:right;width:310px;box-sizing:border-box;padding:0}
.index #sidebar-wrapper{display:none}
.col-left:after{content:'';position:absolute;top:0;left:0;width:100%;height:100%;z-index:5;background-color:rgba(0,0,0,0.10);opacity:0;transition:all 0.2s}
.entry-image-link:after{content:'';position:absolute;top:0;left:0;width:100%;height:100%;z-index:5;background-color:rgba(0,0,0,0.10);opacity:0;transition:all 0.2s}
.entry-image-link:hover:after{opacity:1}
.entry-image-link,.cmm-avatar,.comments .avatar-image-container{background-color:rgba(155,155,155,0.08);color:transparent!important}
.entry-thumb{display:block;position:relative;width:100%;height:100%;background-size:cover;background-position:center center;background-repeat:no-repeat;z-index:1;opacity:0;transition:opacity .35s ease,transform .35s ease}
.entry-thumb.lazy-ify{opacity:1}
.entry-image-link:hover .entry-thumb,.featured-item-inner:hover .entry-image-wrap .entry-thumb{transform:scale(1.03)}
.before-mask:before{content:'';position:absolute;left:0;right:0;bottom:0;height:65%;background-image:linear-gradient(to bottom,transparent,rgba(0,0,0,0.65));-webkit-backface-visibility:hidden;backface-visibility:hidden;z-index:2;opacity:1;margin:-1px;transition:opacity .25s ease}
.entry-thumb.lazy-load{opacity:1}
.entry-title a{display:block}
.entry-image-link:after{content:'\f04b';position:absolute;top:calc(50% - 135px);left:calc(50% - 90px);width:185px;height:270px;background-color:rgba(0,0,0,0.50);font-family:FontAwesome;font-size:32px;color:#fff;font-weight:600;text-align:center;line-height:280px;z-index:3;box-sizing:border-box;padding:0 0 0 0px;border:0px solid #fff;border-radius:0%}
.entry-title{color:$(post.title.color)}
.entry-title a{color:$(post.title.color);display:block}
.entry-title a:hover{color:$(post.title.hover.color)}
.entry-info .entry-title a:hover{text-decoration:underline}
.excerpt{font-family:var(--text-font)}
.product-header .bk-left {display: block;margin: 0 0 10px;}
.product-header .bk-left b {font-family:var(--text-font);font-size: 12px;color:$(title.color);font-weight: 700;margin: 0 5px 0 0;}
.product-header .bk-left .product_author {font-family:var(--text-font);font-size: 12px;color: #ffff;font-family:var(--text-font);font-size: 12px;font-weight: 700;}
.social a:before{display:inline-block;font-family:'Font Awesome 5 Brands';font-style:normal;font-weight:400}
.social .blogger a:before{content:"\f37d"}
.social .facebook a:before{content:"\f09a"}
.social .facebook-f a:before{content:"\f39e"}
.social .twitter a:before{content:"\f099"}
.social .rss a:before{content:"\f09e";font-family:'Font Awesome 5 Free';font-weight:900}
.social .youtube a:before{content:"\f167"}
.social .skype a:before{content:"\f17e"}
.social .stumbleupon a:before{content:"\f1a4"}
.social .tumblr a:before{content:"\f173"}
.social .vk a:before{content:"\f189"}
.social .stack-overflow a:before{content:"\f16c"}
.social .github a:before{content:"\f09b"}
.social .linkedin a:before{content:"\f0e1"}
.social .dribbble a:before{content:"\f17d"}
.social .soundcloud a:before{content:"\f1be"}
.social .behance a:before{content:"\f1b4"}
.social .digg a:before{content:"\f1a6"}
.social .instagram a:before{content:"\f16d"}
.social .pinterest a:before{content:"\f0d2"}
.social .pinterest-p a:before{content:"\f231"}
.social .twitch a:before{content:"\f1e8"}
.social .delicious a:before{content:"\f1a5"}
.social .codepen a:before{content:"\f1cb"}
.social .flipboard a:before{content:"\f44d"}
.social .reddit a:before{content:"\f281"}
.social .whatsapp a:before{content:"\f232"}
.social .messenger a:before{content:"\f39f"}
.social .snapchat a:before{content:"\f2ac"}
.social .telegram a:before{content:"\f3fe"}
.social .email a:before{content:"\f0e0";font-family:'Font Awesome 5 Free';font-weight:400}
.social .external-link a:before{content:"\f35d";font-family:'Font Awesome 5 Free';font-weight:900}
.social-color .blogger a,.social-hover-color .blogger a:hover{background-color:#ff5722}
.social-color .facebook a,.social-color .facebook-f a,.social-hover-color .facebook a:hover,.social-hover-color .facebook-f a:hover{background-color:#3b5999}
.social-color .twitter a,.social-hover-color .twitter a:hover{background-color:#00acee}
.social-color .youtube a,.social-hover-color .youtube a:hover{background-color:#f50000}
.social-color .instagram a,.social-hover-color .instagram a:hover{background:linear-gradient(15deg,#ffb13d,#dd277b,#4d5ed4)}
.social-color .pinterest a,.social-color .pinterest-p a,.social-hover-color .pinterest a:hover,.social-hover-color .pinterest-p a:hover{background-color:#ca2127}
.social-color .dribbble a,.social-hover-color .dribbble a:hover{background-color:#ea4c89}
.social-color .linkedin a,.social-hover-color .linkedin a:hover{background-color:#0077b5}
.social-color .tumblr a,.social-hover-color .tumblr a:hover{background-color:#365069}
.social-color .twitch a,.social-hover-color .twitch a:hover{background-color:#6441a5}
.social-color .rss a,.social-hover-color .rss a:hover{background-color:#ffc200}
.social-color .skype a,.social-hover-color .skype a:hover{background-color:#00aff0}
.social-color .stumbleupon a,.social-hover-color .stumbleupon a:hover{background-color:#eb4823}
.social-color .vk a,.social-hover-color .vk a:hover{background-color:#4a76a8}
.social-color .stack-overflow a,.social-hover-color .stack-overflow a:hover{background-color:#f48024}
.social-color .github a,.social-hover-color .github a:hover{background-color:#24292e}
.social-color .soundcloud a,.social-hover-color .soundcloud a:hover{background:linear-gradient(#ff7400,#ff3400)}
.social-color .behance a,.social-hover-color .behance a:hover{background-color:#191919}
.social-color .digg a,.social-hover-color .digg a:hover{background-color:#1b1a19}
.social-color .delicious a,.social-hover-color .delicious a:hover{background-color:#0076e8}
.social-color .codepen a,.social-hover-color .codepen a:hover{background-color:#000}
.social-color .flipboard a,.social-hover-color .flipboard a:hover{background-color:#f52828}
.social-color .reddit a,.social-hover-color .reddit a:hover{background-color:#ff4500}
.social-color .whatsapp a,.social-hover-color .whatsapp a:hover{background-color:#3fbb50}
.social-color .messenger a,.social-hover-color .messenger a:hover{background-color:#0084ff}
.social-color .snapchat a,.social-hover-color .snapchat a:hover{background-color:#ffe700}
.social-color .telegram a,.social-hover-color .telegram a:hover{background-color:#179cde}
.social-color .email a,.social-hover-color .email a:hover{background-color:#888}
.social-color .external-link a,.social-hover-color .external-link a:hover{background-color:$(darkbutton.bg)}
#header-wrapper{position:relative;float:left;width:100%;margin:0;box-shadow:0 0 20px rgba(0,0,0,.15)}
.navbar-wrap,.navbar{position:relative;float:left;width:100%;height:60px;background-color:$(posts.title.color);padding:0;margin:0}
#header-wrapper .container{position:relative;margin:0 auto}
.main-logo-wrap{position:relative;float:left;margin:0 30px 0 0}
.rtl .main-logo-wrap{float:right;margin:0 0 0 30px}
.main-logo{position:relative;float:left;width:100%;height:34px;padding:13px 0;margin:0}
.main-logo .main-logo-img{float:left;height:34px;overflow:hidden}
.main-logo img{max-width:100%;height:34px;margin:0}
.main-logo h1{font-size:22px;color:$(navbar.color);line-height:34px;margin:0}
.main-logo h1 a{color:$(navbar.color)}
.main-logo #h1-tag{position:absolute;top:-9000px;left:-9000px;display:none;visibility:hidden}
.main-menu-wrap{position:static;float:left;height:60px;margin:0}
.rtl .main-menu-wrap{float:right}
#galaxymag-main-menu .widget,#galaxymag-main-menu .widget > .widget-title{display:none}
#galaxymag-main-menu .show-menu{display:block}
#galaxymag-main-menu{position:static;width:100%;height:60px;z-index:10}
#galaxymag-main-menu ul > li{position:relative;float:left;display:inline-block;padding:0;margin:0}
.rtl #galaxymag-main-menu ul > li{float:right}
#galaxymag-main-menu-nav > li > a{position:relative;display:block;height:60px;font-size:14px;color:$(menu.color);font-weight:500;text-transform:uppercase;line-height:60px;padding:0 15px;margin:0}
#galaxymag-main-menu-nav > li:hover > a{background-color:$(item.hover.bg);color:$(item.hover.color)}
#galaxymag-main-menu ul > li > ul{position:absolute;float:left;left:0;top:60px;width:180px;background-color:$(submenu.bg);z-index:99999;visibility:hidden;opacity:0;padding:0;box-shadow:0 2px 5px 0 rgba(0,0,0,0.15),0 2px 10px 0 rgba(0,0,0,0.17)}
.rtl #galaxymag-main-menu ul > li > ul{left:auto;right:0}
#galaxymag-main-menu ul > li > ul > li > ul{position:absolute;float:left;top:0;left:100%;margin:0}
.rtl #galaxymag-main-menu ul > li > ul > li > ul{float:left;left:auto;right:100%}
#galaxymag-main-menu ul > li > ul > li{display:block;float:none;position:relative}
.rtl #galaxymag-main-menu ul > li > ul > li{float:none}
#galaxymag-main-menu ul > li > ul > li a{position:relative;display:block;height:auto;font-family:var(--meta-font);font-size:13px;color:$(submenu.color);line-height:1.5em;font-weight:400;box-sizing:border-box;padding:8px 15px;margin:0;border-bottom:1px solid rgba(155,155,155,0.07)}
#galaxymag-main-menu ul > li > ul > li:last-child a{border:0}
#galaxymag-main-menu ul > li > ul > li:hover > a{background-color:$(subitem.hover.bg);color:$(subitem.hover.color)}
#galaxymag-main-menu ul > li.has-sub > a:after{content:'\f078';float:right;font-family:'Font Awesome 5 Free';font-size:9px;font-weight:900;margin:-1px 0 0 5px}
.rtl #galaxymag-main-menu ul > li.has-sub > a:after{float:left;margin:-1px 5px 0 0}
#galaxymag-main-menu ul > li > ul > li.has-sub > a:after{content:'\f054';float:right;margin:0}
.rtl #galaxymag-main-menu ul > li > ul > li.has-sub > a:after{content:'\f053'}
#galaxymag-main-menu ul > li:hover > ul,#galaxymag-main-menu ul > li > ul > li:hover > ul{visibility:visible;opacity:1}
#galaxymag-main-menu ul ul{transition:all .17s ease}
#galaxymag-main-menu .getMega{display:none}
#galaxymag-main-menu .mega-menu{position:static!important}
#galaxymag-main-menu .mega-menu > ul{width:100%;background-color:$(megamenu.bg);box-sizing:border-box;padding:20px 10px}
#galaxymag-main-menu .mega-menu > ul.mega-widget,#galaxymag-main-menu .mega-menu > ul.complex-tabs{overflow:hidden}
#galaxymag-main-menu .mega-menu > ul.complex-tabs > ul.select-tab{position:relative;float:left;width:20%;box-sizing:border-box;padding:20px 0;margin:-20px 0 0 -10px}
.rtl #galaxymag-main-menu .mega-menu > ul.complex-tabs > ul.select-tab{float:right;margin:-20px -10px 0 0}
#galaxymag-main-menu .mega-menu > ul.complex-tabs > ul.select-tab:before{content:'';position:absolute;left:0;top:0;width:100%;height:100vh;background-color:rgba(155,155,155,0.07);box-sizing:border-box;display:block}
#galaxymag-main-menu .mega-menu > ul.complex-tabs > ul.select-tab > li{width:100%;margin:0}
#galaxymag-main-menu ul > li > ul.complex-tabs > ul.select-tab > li > a{position:relative;display:block;height:auto;font-size:13px;color:$(megamenu.color);line-height:33px;padding:0 20px}
#galaxymag-main-menu .mega-menu > ul.complex-tabs > ul.select-tab > li.active > a:after{content:'\f054';font-family:'Font Awesome 5 Free';font-weight:900;font-size:9px;float:right}
.rtl #galaxymag-main-menu .mega-menu > ul.complex-tabs > ul.select-tab > li.active > a:after{content:'\f053';float:left}
#galaxymag-main-menu .mega-menu > ul.complex-tabs > ul.select-tab > li.active,#galaxymag-main-menu .mega-menu > ul.complex-tabs > ul.select-tab > li:hover{background-color:$(megamenu.bg)}
#galaxymag-main-menu .mega-menu > ul.complex-tabs > ul.select-tab > li.active > a,#galaxymag-main-menu .mega-menu > ul.complex-tabs > ul.select-tab > li:hover > a{color:$(megamenu.hover.color)}
.mega-tab{display:none;position:relative;width:80%;float:right;margin:0}
.rtl .mega-tab{float:left}
.tab-active{display:block}
.tab-animated,.post-animated{-webkit-animation-duration:.5s;animation-duration:.5s;-webkit-animation-fill-mode:both;animation-fill-mode:both}
@keyframes fadeIn {
from{opacity:0}
to{opacity:1}
}
.tab-fadeIn,.post-fadeIn{animation-name:fadeIn}
@keyframes fadeInUp {
from{opacity:0;transform:translate3d(0,5px,0)}
to{opacity:1;transform:translate3d(0,0,0)}
}
.tab-fadeInUp,.post-fadeInUp{animation-name:fadeInUp}
.mega-widget .mega-item{float:left;width:20%;box-sizing:border-box;padding:0 10px}
.rtl .mega-widget .mega-item{float:right}
.mega-tab .mega-widget .mega-item{width:25%}
.mega-widget .mega-content{position:relative;width:100%;overflow:hidden;padding:0}
.mega-content .entry-image-link{width:100%;height:120px;min-height:120px;background-color:rgba(255,255,255,0.01);z-index:1;display:block;position:relative;overflow:hidden;padding:0}
.mega-tab .entry-thumb{width:calc(($(row.width) - 120px) / 5);height:120px}
.mega-content .entry-title{position:relative;font-size:13px;font-weight:700;line-height:1.4em;margin:8px 0 2px;padding:0}
.mega-content .entry-title a{color:$(megamenu.post.title.color)}
.mega-content .entry-title a:hover{color:$(megamenu.post.title.hover)}
.no-posts{display:block;font-size:14px;color:$(title.color);padding:35px 0;font-weight:400}
.mega-menu .no-posts{color:$(meta.color);text-align:center;padding:0}
.show-search,.hide-search{position:absolute;top:0;right:0;display:block;width:60px;height:60px;background-color:$(navbar.bg);color:$(navbar.color);font-size:15px;line-height:60px;text-align:right;cursor:pointer;z-index:20}
.rtl .show-search,.rtl .hide-search{right:auto;left:0;text-align:left}
.show-search:before{content:"\f002";font-family:'Font Awesome 5 Free';font-weight:900}
.hide-search:before{content:"\f00d";font-family:'Font Awesome 5 Free';font-weight:900}
.show-search:hover,.hide-search:hover{color:$(item.hover.color)}
#nav-search{display:none;position:absolute;left:0;top:0;width:100%;height:60px;z-index:25;background-color:$(navbar.bg);box-sizing:border-box;padding:0}
#nav-search .search-form{width:100%;height:60px;background-color:rgba(0,0,0,0);line-height:60px;overflow:hidden;padding:0}
#nav-search .search-input{width:100%;height:60px;color:$(menu.color);margin:0;padding:0 60px 0 0;background-color:rgba(0,0,0,0);font-family:inherit;font-family:var(--text-font);font-size:14px;font-weight:400;box-sizing:border-box;border:0}
.rtl #nav-search .search-input{padding:0 0 0 60px}
#nav-search .search-input:focus{color:$(menu.color);outline:none}
#nav-search .search-input::placeholder{color:$(menu.color);opacity:.5}
.overlay{visibility:hidden;opacity:0;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.7);z-index:1000;margin:0;transition:all .25s ease}
.show-mobile-menu{display:none;position:absolute;top:0;left:0;height:60px;color:$(menu.color);font-size:16px;font-weight:600;line-height:60px;text-align:center;cursor:pointer;z-index:20;padding:0 20px}
.rtl .show-mobile-menu{left:auto;right:0}
.show-mobile-menu:before{content:"\f0c9";font-family:'Font Awesome 5 Free';font-weight:900}
.show-mobile-menu:hover{color:$(item.hover.color)}
#slide-menu{display:none;position:fixed;width:300px;height:100%;top:0;left:0;bottom:0;background-color:$(navbar.bg)ee;overflow:auto;z-index:1010;left:0;transform:translateX(-100%);visibility:hidden;box-shadow:3px 0 7px rgba(0,0,0,0.1);transition:all .25s ease}
.rtl #slide-menu{left:unset;right:0;transform:translateX(100%)}
.nav-active #slide-menu,.rtl .nav-active #slide-menu{transform:translateX(0);visibility:visible}
.slide-menu-header{float:left;width:100%;height:60px;background-color:$(navbar.bg);overflow:hidden;box-sizing:border-box;box-shadow:0 0 20px rgba(0,0,0,0.15)}
.mobile-logo{float:left;max-width:calc(100% - 60px);height:34px;overflow:hidden;box-sizing:border-box;padding:0 20px;margin:13px 0 0}
.rtl .mobile-logo{float:right}
.mobile-logo a{display:block;height:34px;font-size:22px;color:$(menu.color);line-height:34px;font-weight:700}
.mobile-logo img{max-width:100%;height:34px}
.hide-mobile-menu{position:absolute;top:0;right:0;display:block;height:60px;color:$(menu.color);font-size:16px;line-height:60px;text-align:center;cursor:pointer;z-index:20;padding:0 20px}
.rtl .hide-mobile-menu{right:auto;left:0}
.hide-mobile-menu:before{content:"\f00d";font-family:'Font Awesome 5 Free';font-weight:900}
.hide-mobile-menu:hover{color:$(item.hover.color)}
.slide-menu-flex{display:flex;flex-direction:column;justify-content:space-between;float:left;width:100%;height:calc(100% - 60px)}
.mobile-menu{position:relative;float:left;width:100%;box-sizing:border-box;padding:20px}
.mobile-menu > ul{margin:0}
.mobile-menu .m-sub{display:none;padding:0}
.mobile-menu ul li{position:relative;display:block;overflow:hidden;float:left;width:100%;font-size:14px;font-weight:700;line-height:1.5em;margin:0;padding:0}
.mobile-menu > ul li ul{overflow:hidden}
.mobile-menu ul li a{color:$(menu.color);padding:10px 0;display:block}
.mobile-menu > ul > li > a{text-transform:uppercase}
.mobile-menu ul li.has-sub .submenu-toggle{position:absolute;top:0;right:0;color:$(menu.color);cursor:pointer;padding:10px 0}
.rtl .mobile-menu ul li.has-sub .submenu-toggle{right:auto;left:0}
.mobile-menu ul li.has-sub .submenu-toggle:after{content:'\f078';font-family:'Font Awesome 5 Free';font-weight:900;float:right;width:40px;font-size:12px;text-align:right;transition:all .17s ease}
.rtl .mobile-menu ul li.has-sub .submenu-toggle:after{text-align:left}
.mobile-menu ul li.has-sub.show > .submenu-toggle:after{content:'\f077'}
.mobile-menu ul li a:hover,.mobile-menu ul li.has-sub.show > a,.mobile-menu ul li.has-sub.show > .submenu-toggle{color:$(item.hover.color)}
.mobile-menu > ul > li > ul > li a{font-family:var(--text-font);font-size:13px;font-weight:400;opacity:.8;padding:10px 0 10px 15px}
.rtl .mobile-menu > ul > li > ul > li a{padding:10px 15px 10px 0}
.mobile-menu > ul > li > ul > li > ul > li > a{padding:10px 0 10px 30px}
.rtl .mobile-menu > ul > li > ul > li > ul > li > a{padding:10px 30px 10px 0}
.mobile-menu ul > li > .submenu-toggle:hover{color:$(item.hover.color)}
.social-mobile{position:relative;float:left;width:100%;margin:0}
.social-mobile ul{display:block;text-align:center;padding:20px;margin:0}
.social-mobile ul li{display:inline-block;margin:0 5px}
.social-mobile ul li a{display:block;font-size:17px;color:$(menu.color);padding:0 5px}
.social-mobile ul li a:hover{color:$(item.hover.color)}
.is-fixed{position:fixed;top:-60px;left:0;width:100%;z-index:990;transition:top .17s ease}
.navbar.show{top:0;box-shadow:0 0 20px rgba(0,0,0,.15)}
.nav-active .is-fixed{top:0}
.loader{position:relative;height:100%;overflow:hidden;display:block}
.loader:after{content:'';position:absolute;top:50%;left:50%;width:28px;height:28px;margin:-16px 0 0 -16px;border:2px solid $(main.color);border-right-color:rgba(155,155,155,0.17);border-radius:100%;animation:spinner .8s infinite linear;transform-origin:center}
@-webkit-keyframes spinner {
0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}
to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}
}
@keyframes spinner {
0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}
to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}
}
.owl-carousel{display:none;width:100%;-webkit-tap-highlight-color:transparent;position:relative;z-index:1}
.owl-carousel .owl-stage{position:relative;-ms-touch-action:pan-Y}
.owl-carousel .owl-stage:after{content:".";display:block;clear:both;visibility:hidden;line-height:0;height:0}
.owl-carousel .owl-stage-outer{position:relative;overflow:hidden;-webkit-transform:translate3d(0px,0px,0px)}
.owl-carousel .owl-controls .owl-nav .owl-prev,.owl-carousel .owl-controls .owl-nav .owl-next,.owl-carousel .owl-controls .owl-dot{cursor:pointer;cursor:hand;-webkit-user-select:none;-khtml-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}
.owl-carousel.owl-loaded{display:block}
.owl-carousel.owl-loading{opacity:0;display:block}
.owl-carousel.owl-hidden{opacity:0}
.owl-carousel .owl-refresh .owl-item{display:none}
.owl-carousel .owl-item{position:relative;min-height:1px;float:left;-webkit-backface-visibility:visible;-webkit-tap-highlight-color:transparent;-webkit-touch-callout:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}
.owl-carousel .owl-item img{display:block;width:100%;-webkit-transform-style:preserve-3d;transform-style:preserve-3d}
.owl-carousel.owl-text-select-on .owl-item{-webkit-user-select:auto;-moz-user-select:auto;-ms-user-select:auto;user-select:auto}
.owl-carousel .owl-grab{cursor:move;cursor:-webkit-grab;cursor:-o-grab;cursor:-ms-grab;cursor:grab}
.owl-carousel.owl-rtl{direction:rtl}
.owl-carousel.owl-rtl .owl-item{float:right}
.no-js .owl-carousel{display:block}
.owl-carousel .animated{-webkit-animation-duration:1000ms;animation-duration:1000ms;-webkit-animation-fill-mode:both;animation-fill-mode:both}
.owl-carousel .owl-animated-in{z-index:1}
.owl-carousel .owl-animated-out{z-index:0}
.owl-height{-webkit-transition:height 500ms ease-in-out;-moz-transition:height 500ms ease-in-out;-ms-transition:height 500ms ease-in-out;-o-transition:height 500ms ease-in-out;transition:height 500ms ease-in-out}
.owl-prev,.owl-next{position:relative;float:left;width:22px;height:22px;background-color:rgba(0,0,0,0);font-family:'Font Awesome 5 Free';font-size:10px;line-height:20px;font-weight:900;color:$(meta.color);text-align:center;cursor:pointer;border:1px solid rgba(155,155,155,0.17);border-radius:2px;box-sizing:border-box}
.rtl .owl-prev,.rtl .owl-next{float:right}
.owl-prev:before,.rtl .owl-next:before{content:"\f053"}
.owl-next:before,.rtl .owl-prev:before{content:"\f054"}
.owl-prev:hover,.owl-next:hover{background-color:$(main.color);color:#fff;border-color:$(main.color)}
#breaking-wrap{position:relative;float:left;width:100%;background-color:$(breaking.bg);margin:0}
#breaking-wrap .container{margin:0 auto}
#breaking-sec .widget{display:block;height:24px;padding:5px 0;margin:0}
#breaking-sec .no-posts{height:24px;line-height:24px;text-align:left;padding:0 0 0 15px}
#breaking-sec .widget > .widget-title{display:block;position:relative;float:left;height:24px;color:$(breaking.color);font-family:var(--text-font);font-size:10px;line-height:24px;text-transform:uppercase;padding:0}
.rtl #breaking-sec .widget > .widget-title{float:right}
#breaking-sec .widget > .widget-title > h3{font-weight:700;margin:0}
#breaking-sec .widget > .widget-title > h3:before{content:'\f0e7';font-family:'Font Awesome 5 Free';float:left;font-size:11px;font-weight:900;margin:0 5px 0 0}
.rtl #breaking-sec .widget > .widget-title > h3:before{float:right;margin:0 0 0 5px}
#breaking-sec .widget-content{position:relative;font-size:12px;display:none;overflow:hidden;height:24px;line-height:23px;opacity:0;box-sizing:border-box;padding:0}
#breaking-sec .show-ify .widget-content{display:block;opacity:1}
#breaking-sec .no-posts{color:$(breaking.color)}
.breaking-news{width:100%!important;box-sizing:border-box;padding:0 0 0 15px}
.rtl .breaking-news{padding:0 15px 0 0}
.breaking-news:after{content:"";position:absolute;background-image:linear-gradient(to right,$(breaking.bg)00,$(breaking.bg));top:0;right:48px;width:50px;height:24px}
.rtl .breaking-news:after{background-image:linear-gradient(to left,$(breaking.bg)00,$(breaking.bg));right:auto;left:48px}
.breaking-news .breaking-item{position:relative;float:left;display:block;height:24px;padding:0}
.rtl .breaking-news .breaking-item{float:right}
.breaking-news .entry-title{height:24px;font-family:var(--meta-font);font-size:13px;font-weight:400;line-height:24px;margin:0;padding:0}
.breaking-news .entry-title a{position:relative;display:block;color:$(breaking.color);overflow:hidden;opacity:.9}
.breaking-news .entry-title a:hover{color:$(breaking.hover.color);opacity:1}
.breaking-news .owl-nav{position:absolute;top:0;right:0;width:48px;height:22px;background-color:$(breaking.bg);margin:1px 0 0}
.rtl .breaking-news .owl-nav{right:auto;left:0}
.breaking-news .owl-nav .owl-prev,.breaking-news .owl-nav .owl-next{background-color:rgba(0,0,0,0);color:$(breaking.color);border-color:$(breaking.color)30}
.breaking-news .owl-nav .owl-prev:hover,.breaking-news .owl-nav .owl-next:hover{background-color:$(breaking.hover.color);color:$(breaking.bg);border-color:rgba(0,0,0,0)}
.breaking-news .owl-nav .owl-next{margin:0 0 0 4px}
.rtl .breaking-news .owl-nav .owl-next{margin:0 4px 0 0}
@keyframes fadeInLeft {
from{opacity:0;transform:translate3d(-30px,0,0)}
to{opacity:1;transform:none}
}
@keyframes fadeOutLeft {
from{opacity:1}
to{opacity:0;transform:translate3d(-30px,0,0)}
}
@keyframes fadeInRight {
from{opacity:0;transform:translate3d(30px,0,0)}
to{opacity:1;transform:none}
}
.fadeInRight{animation-name:fadeInRight}
.rtl .fadeInRight{animation-name:fadeInLeft}
@keyframes fadeOutRight {
from{opacity:1}
to{opacity:0;transform:translate3d(30px,0,0)}
}
.fadeOutRight{animation-name:fadeOutRight}
.rtl .fadeOutRight{animation-name:fadeOutLeft}
.header-ads-wrap{position:relative;float:left;width:100%;line-height:1}
.header-ads-wrap .container{text-align:center;margin:0 auto}
.header-ad .widget{position:relative;line-height:0;margin:35px 0 0}
.header-ad .widget > .widget-title{display:none!important}
#featured-wrapper .container{margin:0 auto}
#featured-sec .widget,#featured-sec .widget > .widget-title{display:none}
#featured-sec .show-ify{display:block!important;overflow:hidden}
#featured-sec .widget{position:relative;padding:0}
#featured-sec .show-ify .widget-content{position:relative;overflow:hidden;height:402px;margin:35px 0 0}
#featured-sec .no-posts{line-height:300px;text-align:center}
#featured-sec .featured-grid{position:relative;overflow:hidden;height:402px;margin:0 -1px}
.featured-item{position:relative;float:left;width:25%;height:200px;overflow:hidden;box-sizing:border-box;padding:0 1px}
.rtl .featured-item{float:right}
.featured-item-inner{position:relative;float:left;width:100%;height:100%;overflow:hidden;display:block}
.featured-item .entry-image-link{width:100%;height:100%;position:relative;overflow:hidden;display:block}
.entry-category{position:absolute;display:inline-block;top:10px;left:10px;height:18px;z-index:5;background-color:$(main.color);color:#fff;font-family:var(--text-font);font-size:10px;line-height:20px;text-transform:uppercase;padding:0 5px;border-radius:2px}
.rtl .entry-category{left:auto;right:15px}
.featured-item .entry-category{position:relative;top:auto;left:auto;right:auto;margin:0}
.entry-info{position:absolute;bottom:0;left:0;overflow:hidden;z-index:5;box-sizing:border-box;padding:15px;width:100%;background-image:linear-gradient(to bottom,transparent,rgba(0,0,0,0.3))}
.featured-item .entry-title{font-size:14px;font-weight:700;display:block;line-height:1.4em;margin:10px 0 0}
.font-size1 .featured-item .entry-title{font-size:13px}
.featured-item .entry-title a{color:#fff;display:block}
.entry-meta{font-family:var(--meta-font);font-size:11px;color:#aaaaaa;font-weight:400;padding:0}
.entry-meta span.by{color:#1f2024;font-size:0px;font-weight:600;margin:0}
.entry-meta .entry-comments-link{float:right;display:none}
.rtl .entry-meta .entry-comments-link{float:left}
.entry-meta .entry-comments-link.show{display:block}
.entry-meta .entry-comments-link:before{content:'\f086';font-family:'Font Awesome 5 Free';font-size:12px;color:#1f2024;font-weight:400;margin:0 4px 0 0}
.rtl .entry-meta .entry-comments-link:before{float:right;margin:0 0 0 4px}
.featured-item .entry-meta{color:#ccc;margin:5px 0 0}
.featured-item .entry-meta .by{color:#f2f2f2}
.featured1 .item-0{width:50%;height:402px}
.featured1 .item-1{width:50%;margin:0 0 2px}
.featured1 .item-0 .entry-info{padding:20px}
.featured1 .item-0 .entry-title{font-size:25px}
.font-size1 .featured1 .item-0 .entry-title{font-size:23px}
.featured1 .item-1 .entry-title{font-size:17px}
.featured2 .item-0{width:50%;height:402px}
.featured2 .item-1,.featured2 .item-2{margin:0 0 2px}
.featured2 .item-0 .entry-info{padding:20px}
.featured2 .item-0 .entry-title{font-size:25px}
.font-size1 .featured2 .item-0 .entry-title{font-size:23px}
.featured3 .featured-item{width:calc(100% / 3)}
.featured3 .item-0,.featured3 .item-1,.featured3 .item-2{margin:0 0 2px}
.featured3 .featured-item .entry-title{font-size:16px}
.featured4 .featured-item{width:calc(100% / 3);height:180px}
.featured4 .item-0,.featured4 .item-1{width:50%;height:220px;margin:0 0 2px}
.featured4 .featured-item .entry-title{font-size:16px}
.featured4 .item-0 .entry-title,.featured4 .item-1 .entry-title{font-size:19px}
.featured5 .featured-item{width:calc(100% / 3)}
.featured5 .item-0{height:402px}
.featured5 .item-1,.featured5 .item-2{margin:0 0 2px}
.featured5 .featured-item .entry-title{font-size:16px}
.featured6 .featured-item{width:calc(100% / 3);height:402px}
.featured6 .featured-item .entry-title{font-size:16px}

.title-wrap,.block-posts .widget > .widget-title{position:relative;float:left;width:100%;height:30px;display:block;margin:0 0 25px;border-bottom:2px solid $(main.wtitle.bg)}
.title-wrap > h3,.block-posts .widget > .widget-title > h3{position:relative;float:left;height:30px;background-color:$(main.wtitle.bg);font-family:var(--body-font);font-size:13px;color:$(main.wtitle.color);font-weight:500;line-height:35px;text-transform:uppercase;padding:0 13px;margin:0}
.title-wrap > h3:after, .block-posts .widget-title > h3:after {position: absolute;content: '';height: 0;width: 0;bottom: 0;right: -15px;border-top: 32px solid transparent;border-left: 15px solid #111;border-right: 0 solid #111;border-bottom: 0;}
.rtl .title-wrap > h3,.rtl .block-posts .widget > .widget-title > h3{float:right}
.title-wrap > a.more,.widget-title > a.more{float:right;font-family:var(--text-font);font-size:13px;color:$(meta.color);line-height:30px;padding:0}
.more1 .title-wrap > a.more,.more1 .widget-title > a.more{font-family:var(--title-font)}
.rtl .title-wrap > a.more,.rtl .widget-title > a.more{float:left}
.title-wrap > a.more:hover,.block-posts .widget > .widget-title > a.more:hover{color:$(title.hover.color)}

.block-posts .widget{display:none;position:relative;float:left;width:100%;margin:0 0 35px}
#block-posts-2 .widget:first-child{margin:35px 0}
#block-posts-2 .widget:last-child{margin-bottom:0}
.block-posts .show-ify{display:block}
.block-posts .widget-content{position:relative;float:left;width:100%;display:block}
.block-posts .loader{height:180px}
.block-posts-1 .block-item{position:relative;float:left;width:calc((100% - 30px) / 2);overflow:hidden;padding:0;margin:20px 0 0}
.rtl .block-posts-1 .block-item{float:right}
.block-posts-1 .item-0{margin:0 30px 0 0}
.rtl .block-posts-1 .item-0{margin:0 0 0 30px}
.block-posts-1 .item-1{margin:0}
.block-posts-1 .block-inner{position:relative;width:100%;height:320px;overflow:hidden}
.block-posts-1 .entry-image-link{position:relative;width:85px;height:65px;float:left;display:block;overflow:hidden;margin:0 12px 0 0}
.rtl .block-posts-1 .entry-image-link{float:right;margin:0 0 0 12px}
.block-posts-1 .block-inner .entry-image-link{width:100%;height:100%;margin:0}
.block-posts-1 .entry-header{overflow:hidden}
.block-posts-1 .entry-category{position:relative;top:auto;left:auto;right:auto;margin:0}
.block-posts-1 .entry-title{font-size:14px;font-weight:700;line-height:1.4em;margin:0 0 3px}
.font-size1 .block-posts-1 .entry-title{font-size:13px}
.block-posts-1 .entry-info .entry-title{font-size:17px;margin:10px 0 5px}
.block-posts-1 .entry-info .entry-title a{color:#fff}
.block-posts-1 .entry-info .entry-meta{color:#ccc}
.block-posts-1 .entry-info .entry-meta .by{color:#f2f2f2}
.block-posts-2 .block-grid{position:relative;display:flex;flex-wrap:wrap;margin:0 -10px}
.block-posts-2 .block-item{position:relative;float:left;width:calc(100% / 6);box-sizing:border-box;padding:0 10px;margin:20px 0 0}
.rtl .block-posts-2 .block-item{float:right}
.block-posts-2 .item-0{float:none;display:block;width:100%;padding:0;margin:0 0 5px}
.rtl .block-posts-2 .item-0{float:none}
.block-posts-2 .block-inner{position:relative;width:100%;height:320px;overflow:hidden}
.block-posts-2 .entry-image{position:relative}
.block-posts-2 .entry-image-link{width:100%;height:130px;position:relative;display:block;overflow:hidden}
.block-posts-2 .item-0 .entry-image-link{height:100%;margin:0}
.block-posts-2 .entry-header{overflow:hidden}
.block-posts-2 .entry-title{font-size:14px;font-weight:700;line-height:1.4em;margin:8px 0 3px}
.font-size1 .block-posts-2 .entry-title{font-size:13px}
.block-posts-2 .item-0 .entry-info{padding:20px}
.block-posts-2 .item-0 .entry-category{position:relative;top:auto;left:auto;right:auto;margin:0}
.block-posts-2 .item-0 .entry-title{font-size:25px;margin:10px 0 5px}
.font-size1 .block-posts-2 .item-0 .entry-title{font-size:23px}
.block-posts-2 .item-0 .entry-title a{color:#fff}
.block-posts-2 .item-0 .entry-meta{color:#ccc}
.block-posts-2 .item-0 .entry-meta .by{color:#f2f2f2}
.block-posts .block-column{width:calc((100% - 30px) / 2)}
.block-posts .column-left{float:left}
.block-posts .column-right{float:right}
.block-column .column-item{position:relative;float:left;width:100%;overflow:hidden;padding:0;margin:20px 0 0}
.block-column .column-item.item-0{margin:0 0 5px}
.column-inner{position:relative;width:100%;height:200px;overflow:hidden}
.column-posts .entry-image-link{position:relative;width:85px;height:65px;float:left;display:block;overflow:hidden;margin:0 12px 0 0}
.rtl .column-posts .entry-image-link{float:right;margin:0 0 0 12px}
.column-inner .entry-image-link{width:100%;height:100%;margin:0}
.column-posts .entry-header{overflow:hidden}
.column-posts .entry-category{position:relative;top:auto;left:auto;right:auto;margin:0}
.column-posts .entry-title{font-size:14px;font-weight:700;line-height:1.4em;margin:0 0 3px}
.font-size1 .column-posts .entry-title{font-size:13px}
.column-posts .entry-info .entry-title{font-size:17px;margin:10px 0 5px}
.column-posts .entry-info .entry-title a{color:#fff}
.column-posts .entry-info .entry-meta{color:#ccc}
.column-posts .entry-info .entry-meta .by{color:#f2f2f2}
.grid-posts-1{position:relative;overflow:hidden;display:flex;flex-wrap:wrap;padding:0;margin:0 -10px}
.grid-posts-1 .grid-item{position:relative;float:left;width:calc(100% / 6);box-sizing:border-box;padding:0 10px;margin:0px 0 0}
.rtl .grid-posts-1 .grid-item{flaot:right}
.grid-posts-1 .grid-item.item-0,.grid-posts-1 .grid-item.item-1,.grid-posts-1 .grid-item.item-2{margin:0}
.grid-posts-1 .entry-image{position:relative}
.grid-posts-1 .entry-image-link{width:100%;height:190px;position:relative;display:block;overflow:hidden}
.grid-posts-1 .entry-title{font-family:var(--text-font);font-size:12px;font-weight:600;line-height:1.4em;margin:8px 0 3px}
.font-size1 .grid-posts-1 .entry-title{font-size:13px}
.grid-posts-2{position:relative;overflow:hidden;display:flex;flex-wrap:wrap;padding:0;margin:0 -10px}
.grid-posts-2 .grid-item{position:relative;float:left;width:calc(100% / 6);overflow:visible;margin:0 0 15px;box-sizing:border-box;padding:0 10px}
.rtl .grid-posts-2 .grid-item{float:right}
.grid-posts-2 .grid-item.item-0,.grid-posts-2 .grid-item.item-1{margin:0}
.grid-posts-2 .entry-image{position:relative}
.grid-posts-2 .entry-image-link{width:100%;height:210px;position:relative;display:block;overflow:hidden}
.grid-posts-2 .entry-title{font-family:var(--text-font);font-size:12px;font-weight:600;line-height:1.5em;margin:10px 0 8px;display:-webkit-box;-webkit-box-orient:vertical;text-overflow:ellipsis;-webkit-line-clamp:2;overflow:hidden}

.font-size1 .grid-posts-2 .entry-title{font-size:18px}
.block-carousel{position:relative;overflow:hidden}
.block-carousel .carousel-item{position:relative;float:left;width:100%;overflow:hidden;box-sizing:border-box;padding:0;margin:0}
.rtl .block-carousel .carousel-item{float:right}
.block-carousel .entry-image{position:relative}
.block-carousel .entry-image-link{width:100%;height:210px;position:relative;display:block;overflow:hidden}
.block-carousel .entry-title{font-family:var(--text-font);font-size:12px;font-weight:600;line-height:1.5em;margin:10px 0 8px;display:-webkit-box;-webkit-box-orient:vertical;text-overflow:ellipsis;-webkit-line-clamp:2;overflow:hidden}
.font-size1 .block-carousel .entry-title{font-size:13px}
.block-carousel .owl-nav{position:relative;float:left;margin:0px 0 0}
.rtl .block-carousel .owl-nav{float:left}
.block-carousel .owl-prev,.block-carousel .owl-next{width:22px;height:22px;line-height:20px;z-index:10}
.block-carousel .owl-prev{margin:0 4px 0 0}
.rtl .block-carousel .owl-prev{margin:0 0 0 4px}
.block-videos{position:relative;overflow:hidden;display:flex;flex-wrap:wrap;padding:0;margin:0 -10px}
.block-videos .videos-item{position:relative;float:left;width:calc(100% / 3);overflow:hidden;box-sizing:border-box;padding:0 10px;margin:20px 0 0}
.rtl .block-videos .videos-item{float:right}
.block-videos .videos-item.item-0,.block-videos .videos-item.item-1,.block-videos .videos-item.item-2{margin:0}
.block-videos .entry-image-link{width:100%;height:130px;position:relative;display:block;overflow:hidden}
.block-videos .videos-inner:hover .entry-image-link:after{opacity:1}
.block-videos .entry-title{font-family:var(--text-font);font-size:12px;font-weight:600;line-height:1.4em;margin:8px 0 3px}
.font-size1 .block-videos .entry-title{font-size:13px}
.block-videos .video-icon{position:absolute;top:calc(50% - (34px / 2));right:calc(50% - (34px / 2));background-color:rgba(0,0,0,0.5);height:34px;width:34px;color:#fff;font-size:12px;text-align:center;line-height:32px;z-index:5;margin:0;box-sizing:border-box;border:2px solid #fff;border-radius:100%;opacity:.85;transition:opacity .25s ease}
.block-videos .video-icon:after{content:'\f04b';display:block;font-family:'Font Awesome 5 Free';font-weight:900;padding:0 0 0 3px}
.block-videos .videos-item:hover .video-icon{opacity:1}
#home-ad .widget{position:relative;float:left;width:100%;line-height:0;margin:0 0 35px}
#home-ad .widget > .widget-title{display:none!important}
#custom-ads{float:left;width:100%;opacity:0;visibility:hidden;margin:0}
#before-ad,#after-ad{float:left;width:100%;margin:0}
#before-ad .widget > .widget-title > h3,#after-ad .widget > .widget-title > h3{height:auto;font-size:10px;color:$(meta.color);font-weight:400;line-height:1;text-transform:inherit;margin:0 0 5px}
#before-ad .widget,#after-ad .widget{width:100%;margin:25px 0 0}
#before-ad .widget-content,#after-ad .widget-content{position:relative;width:100%;line-height:1}
#new-before-ad #before-ad,#new-after-ad #after-ad{float:none;display:block;margin:0}
#new-before-ad #before-ad .widget,#new-after-ad #after-ad .widget{margin:0}
.item-post .FollowByEmail{box-sizing:border-box}
#main-wrapper #main{float:left;width:100%;box-sizing:border-box}
.queryMessage{overflow:hidden;color:$(title.color);font-size:14px;padding:0 0 15px;margin:0 0 35px;border-bottom:1px solid rgba(155,155,155,0.13)}
.queryMessage .query-info{margin:0}
.queryMessage .search-query,.queryMessage .search-label{font-weight:600;text-transform:uppercase}
.queryMessage .search-query:before,.queryMessage .search-label:before{content:"\201c"}
.queryMessage .search-query:after,.queryMessage .search-label:after{content:"\201d"}
.queryMessage a.show-more{float:right;color:$(body.link.color);text-decoration:underline}
.queryMessage a.show-more:hover{color:$(title.color);text-decoration:none}
.queryEmpty{font-size:13px;font-weight:400;padding:0;margin:40px 0;text-align:center}

.blog-post{display:block;word-wrap:break-word}
.item .blog-post{float:left;width:100%}
.index-post-wrap{position:relative;display:flex;flex-wrap:wrap;margin:0 -10px}
.post-animated{-webkit-animation-duration:.5s;animation-duration:.5s;-webkit-animation-fill-mode:both;animation-fill-mode:both}
@keyframes fadeIn {
from{opacity:0}
to{opacity:1}
}
.post-fadeIn{animation-name:fadeIn}
@keyframes fadeInUp {
from{opacity:0;transform:translate3d(0,5px,0)}
to{opacity:1;transform:translate3d(0,0,0)}
}
.post-fadeInUp{animation-name:fadeInUp}
.index-post{position:relative;float:left;width:calc(100% / 6);overflow:visible;margin:0 0 15px;box-sizing:border-box;padding:0 10px}
.rtl .index-post{float:right}
.blog-posts .index-post:nth-child(1),.blog-posts .index-post:nth-child(2),.blog-posts .index-post:nth-child(3){margin:0}
.index-post .entry-header{overflow:hidden}
.index-post .entry-title{font-size:13px;font-weight:400;line-height:1.3em;margin:10px 0 5px}
.index-post .entry-image{position:relative;width:100%;height:210px;overflow:hidden;margin:0}
.index-post .entry-image-link{position:relative;float:left;width:100%;height:100%;z-index:1;overflow:hidden}
.index-post .entry-title{font-family:var(--text-font);font-size:12px;font-weight:600;line-height:1.5em;margin:10px 0 8px;display:-webkit-box;-webkit-box-orient:vertical;text-overflow:ellipsis;-webkit-line-clamp:2;overflow:hidden}
.inline-ad-wrap{position:relative;float:left;width:100%;margin:0}
.inline-ad{position:relative;float:left;width:100%;text-align:center;line-height:1;margin:0}
.item-post-inner{position:relative;float:left;width:100%;box-sizing:border-box;padding:0}
.bk-left{font-family:var(--text-font);font-size:12px}
.col-right{font-family:var(--text-font);font-size:12px;color:$(title.color)}
.product-header .bk-left b {font-family:var(--text-font);font-size: 12px;color:var(--title-color);font-weight: 700;margin: 0 5px 0 0;}
.product-header .bk-left .product_author {font-size: 12px;color: #111;font-family:var(--text-font);font-size: 12px;font-weight: 700;}
.index-post .post-image-wrap {transition: all .3s ease;-webkit-transition: all .3s ease;-moz-transition: all .3s ease;-o-transition: all .3s ease;-webkit-perspective: 600px;-moz-perspective: 600px;perspective: 600px;}
.product-header .bk-left .entry-image-link:after{width:32px;height:22px;line-height:22px;font-size:10px;border-radius:4px}
.index-post .post-image-wrap:hover .bk-left {-webkit-transform: rotateY(-45deg);-o-transform: rotateY(45deg);transform: rotateY(-45deg);top: -12px;height: 110%;}
.product-header{position:relative;float:left;width:100%;background-color:rgba(155,155,155,0.1);box-sizing:border-box;padding:15px;margin:0 0 30px}
.product_off{position:absolute;top:15px;left:15px;height:30px;background-color:#f50000;font-size:14px;color:#fff;font-weight:700;text-align:center;line-height:30px;z-index:2;padding:0 10px}
.index-post .product_off,.FeaturedPost .product_off,.product-header .product_off{visibility:hidden;opacity:0;transition:all .17s ease}
.index-post .product_off.show,.FeaturedPost .product_off.show,.product-header .product_off.show{visibility:visible;opacity:1}
.col-left{position:relative;float:left;width:150px;padding:5px;box-sizing:border-box}
.col-left .post-image-wrap{position:relative;float:left;width:100%;height:200px;;box-sizing:border-box;overflow:hidden}
.col-left a:hover{background-color:rgba(155,155,155,0.1)}
.col-right{position:relative;float:right;width:calc(100% - 160px)}

.product-post .post-body img{display:none}
.product-post h1.post-title{position:relative;display:block;font-family:var(--text-font);font-size:13px;color:#111111;(title.color);line-height:1.5em;font-weight:600;text-transform:uppercase;margin:10px 0 10px;padding:0 0 10px;border-bottom:3px solid #ebebeb}
.product-post h1.post-title:after{position:absolute;content:'';background-color:#de5b52;(main.color);width:45px;height:3px;bottom:-3px;left:0;margin:0}
.static_page .item-post h1.post-title{position:relative;display:block;font-family:var(--text-font);font-size:13px;color:#(title.color);line-height:1.5em;font-weight:600;text-transform:uppercase;margin:0 0 10px;padding:0 0 10px;border-bottom:1px solid #ebebeb}
.static_page .item-post h1.post-title:after{position:absolute;content:'';background-color:#(main.color);width:45px;height:2px;bottom:-1px;left:0;margin:0}
.col-right .item_price{display:none;margin:0 0 10px}
.col-right .item_price.show{display:block}
.col-right .item_price b{font-family:var(--text-font);font-size:13px;rcolo:#(title.color);font-weight:700;margin:0 5px 0 0}
.col-right .meta-price{font-size:13px}
.kdm-product-buy-buttons{display:block;overflow:hidden;margin:0 0 30px}
.kdm-product-buy-buttons{font-size:11px}
.kdm-product-buy-buttons a i{margin:0 5px 0 0}

#breadcrumb{position:relative;float:left;width:100%;background-color:$(tab.active.bg);font-family:var(--text-font);font-size:12px;color:$(meta.color);font-weight:600;box-sizing:border-box;padding:7px;margin:0 0 0px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;border-radius:0px;box-shadow:0 10px 10px rgba(0,0,0,.05)}
#breadcrumb a{color:var(--main-color);transition:color .25s}
#breadcrumb a:hover{color:$(title.color)}
#breadcrumb a,#breadcrumb em{display:inline-block}
#breadcrumb .delimiter:after{content:'\f054';font-family:'Font Awesome 5 Free';font-size:9px;font-weight:900;font-style:normal;margin:0 3px}

.item-post .blog-entry-header{position:relative;float:left;width:100%;overflow:hidden;padding:0}
.item-post .blog-entry-header .entry-meta{font-size:13px}
.item-post h1.entry-title{font-family:var(--meta-font);font-size:$(itempost.title.size);line-height:1.4em;font-weight:600;position:relative;display:block;margin:0 0 13px}
.static_page .item-post h1.entry-title{margin:0}
.item-post .post-body{position:relative;float:left;width:100%;overflow:hidden;font-family:var(--text-font);font-size:$(itempost.content.size);color:$(post.text.color);line-height:1.6em;padding:25px 0 0;margin:0}
.post-body h1,.post-body h2,.post-body h3,.post-body h4{font-size:18px;color:$(post.title.color);margin:0 0 15px}
.post-body h1,.post-body h2{font-size:23px}
.post-body h3{font-size:21px}
blockquote{background-color:rgba(155,155,155,0.05);color:$(post.title.color);font-style:italic;padding:15px 25px;margin:0;border-left:1px solid $(main.color)}
.rtl blockquote{border-left:0;border-right:1px solid $(main.color)}
blockquote:before,blockquote:after{display:inline-block;font-family:'Font Awesome 5 Free';font-style:normal;font-weight:900;color:$(post.title.color);line-height:1}
blockquote:before,.rtl blockquote:after{content:'\f10d';margin:0 10px 0 0}
blockquote:after,.rtl blockquote:before{content:'\f10e';margin:0 0 0 10px}
.post-body ul,.widget .post-body ol{line-height:1.5;font-weight:400;padding:0 0 0 15px;margin:10px 0}
.rtl .post-body ul,.rtl .widget .post-body ol{padding:0 15px 0 0}
.post-body li{margin:5px 0;padding:0;line-height:1.5}
.post-body ul li{list-style:disc inside}
.post-body ol li{list-style:decimal inside}
.post-body u{text-decoration:underline}
.post-body strike{text-decoration:line-through}
.post-body a{color:$(body.link.color)}
.post-body a:hover{text-decoration:underline}
.post-body a.button{display:inline-block;height:32px;background-color:$(button.bg);font-family:var(--body-font);font-size:14px;color:$(button.color);font-weight:400;line-height:32px;text-align:center;text-decoration:none;cursor:pointer;padding:0 15px;margin:0 5px 5px 0;border-radius:2px}
.rtl .post-body a.button{margin:0 0 5px 5px}
.post-body a.colored-button{color:#fff}
.post-body a.button:hover{background-color:$(darkbutton.bg);color:$(darkbutton.color)}
.post-body a.colored-button:hover{background-color:$(darkbutton.bg)!important;color:$(darkbutton.color)!important}
.button:before{font-family:'Font Awesome 5 Free';font-weight:900;display:inline-block;margin:0 5px 0 0}
.rtl .button:before{margin:0 0 0 5px}
.button.preview:before{content:"\f06e"}
.button.download:before{content:"\f019"}
.button.link:before{content:"\f0c1"}
.button.cart:before{content:"\f07a"}
.button.info:before{content:"\f06a"}
.button.share:before{content:"\f1e0"}
.alert-message{position:relative;display:block;padding:15px;border:1px solid rgba(155,155,155,0.17);border-radius:2px}
.alert-message.alert-success{background-color:rgba(34,245,121,0.03);border:1px solid rgba(34,245,121,0.5)}
.alert-message.alert-info{background-color:rgba(55,153,220,0.03);border:1px solid rgba(55,153,220,0.5)}
.alert-message.alert-warning{background-color:rgba(185,139,61,0.03);border:1px solid rgba(185,139,61,0.5)}
.alert-message.alert-error{background-color:rgba(231,76,60,0.03);border:1px solid rgba(231,76,60,0.5)}
.alert-message:before{font-family:'Font Awesome 5 Free';font-size:16px;font-weight:900;display:inline-block;margin:0 5px 0 0}
.rtl .alert-message:before{margin:0 0 0 5px}
.alert-message.alert-success:before{content:"\f058"}
.alert-message.alert-info:before{content:"\f05a"}
.alert-message.alert-warning:before{content:"\f06a"}
.alert-message.alert-error:before{content:"\f057"}
.contact-form{overflow:hidden}
.contact-form .widget-title{display:none}
.contact-form .contact-form-name{width:calc(50% - 5px)}
.rtl .contact-form .contact-form-name{float:right}
.contact-form .contact-form-email{width:calc(50% - 5px);float:right}
.rtl .contact-form .contact-form-email{float:left}
.contact-form .contact-form-button-submit{font-family:var(--body-font)}
.code-box{position:relative;display:block;background-color:rgba(155,155,155,0.1);font-family:Monospace;font-size:13px;white-space:pre-wrap;line-height:1.4em;padding:10px;margin:0;border:1px solid rgba(155,155,155,0.3);border-radius:2px}

.entry-tags{overflow:hidden;float:left;width:100%;height:auto;position:relative;margin:25px 0 0}
.entry-tags a,.entry-tags span{float:left;height:24px;background-color:rgba(155,155,155,0.05);font-size:11px;color:$(meta.color);font-weight:400;line-height:22px;box-sizing:border-box;padding:0 9px;margin:5px 5px 0 0;border:1px solid rgba(0,0,0,.1);border-bottom-width:2px;border-radius:2px}
.rtl .entry-tags a,.rtl .entry-tags span{float:right;margin:5px 0 0 5px}
.entry-tags span{background-color:$(darkbutton.bg);color:$(darkbutton.color)}
.entry-tags a:hover{background-color:$(button.bg);color:$(button.color)}

.post-share{position:relative;float:left;width:100%;overflow:hidden;padding:0;margin:30px 0 0}
ul.share-links{position:relative}
.share-links li{float:left;overflow:hidden;margin:0 7px 0 0}
.rtl .share-links li{float:right;margin:0 0 0 7px}
.share-links li a{display:block;cursor:pointer;width:34px;height:32px;line-height:32px;color:#fff;font-size:14px;font-weight:400;text-align:center;border-radius:2px}
.share-links li a.facebook,.share-links li a.twitter{width:auto}
.share-links li a.facebook:before,.share-links li a.twitter:before{width:32px;background-color:rgba(255,255,255,0.05)}
.share-links li a span{font-family:var(--text-font);font-size:13px;padding:0 13px}
.share-links li a:hover{opacity:.8}
.share-links .show-hid a{background-color:rgba(155,155,155,0.1);font-size:14px;color:#888}
.share-links .show-hid a:before{content:'\f067';font-family:'Font Awesome 5 Free';font-weight:900}
.show-hidden .show-hid a:before{content:'\f068'}
.share-links li.pinterest-p,.share-links li.linkedin,.share-links li.whatsapp,.share-links li.telegram{display:none}
.show-hidden li.pinterest-p,.show-hidden li.linkedin,.show-hidden li.whatsapp,.show-hidden li.telegram{display:inline-block}
.post-footer{position:relative;float:left;width:100%;box-sizing:border-box;padding:0}
#related-wrap{overflow:hidden;float:left;width:100%;box-sizing:border-box;padding:0;margin:35px 0 0}
#related-wrap .related-tag{display:none}
.galaxymag-related-content{float:left;width:100%}
.galaxymag-related-content .loader{height:200px}
.related-posts{position:relative;display:flex;flex-wrap:wrap;overflow:hidden;margin:0 -10px;padding:0}
.related-posts .related-item{position:relative;float:left;width:calc(100% / 5);overflow:visible;margin:0 0 15px;box-sizing:border-box;padding:0 10px}
.related-posts .entry-image-link:after{width:0px;height:0px;line-height:0px;font-size:0px;border-radius:4px}
.related-posts .related-item.item-0,.related-posts .related-item.item-1,.related-posts .related-item.item-2{margin:0}
.related-posts .related-item-inner{position:relative;width:100%;display:block}
.related-posts .entry-image{position:relative}
.related-posts .entry-image-link{position:relative;display:block;width:100%;height:160px;margin:0}
.related-posts .entry-title{font-family:var(--text-font);font-size:12px;font-weight:600;line-height:1.5em;margin:10px 0 8px;display:-webkit-box;-webkit-box-orient:vertical;text-overflow:ellipsis;-webkit-line-clamp:2;overflow:hidden}
.font-size1 .related-posts .entry-title{font-size:13px}
.about-author{position:relative;float:left;width:100%;overflow:hidden;box-sizing:border-box;padding:20px;margin:35px 0 0;border:1px solid rgba(155,155,155,0.17)}
.about-author .avatar-container{position:relative;float:left;width:60px;height:60px;background-color:rgba(155,155,155,0.1);overflow:hidden;margin:0 17px 0 0;border-radius:100%}
.rtl .about-author .avatar-container{float:right;margin:0 0 0 17px}
.about-author .author-avatar{float:left;width:100%;height:100%;background-size:100% 100%;background-position:0 0;background-repeat:no-repeat;opacity:0;overflow:hidden;border-radius:100%;transition:opacity .25s ease}
.about-author .author-avatar.lazy-ify{opacity:1}
.about-author .author-name{display:block;font-size:18px;font-weight:700;margin:0 0 10px}
.about-author .author-name span{color:$(title.color)}
.about-author .author-name a{color:$(body.link.color)}
.about-author .author-name a:hover{color:$(title.color);text-decoration:none}
.author-description{overflow:hidden}
.author-description span{display:block;overflow:hidden;font-family:var(--body-font);font-size:14px;color:$(body.text.color);font-weight:400;line-height:1.6em}
.author-description span br{display:none}
.author-description a{display:none;float:left;font-size:14px;color:$(title.color);text-align:center;padding:0;margin:12px 13px 0 0}
.rtl .author-description a{float:right;margin:12px 0 0 13px}
.author-description a:hover{color:$(title.hover.color)}
.author-description.show-icons li,.author-description.show-icons a{display:inline-block}
.post-nav{position:relative;float:left;width:100%;overflow:hidden;font-family:var(--meta-font);font-size:13px;box-sizing:border-box;margin:35px 0 0}
.post-nav a{color:$(meta.color)}
.post-nav a:hover{color:$(title.hover.color)}
.post-nav span{color:$(meta.color);opacity:.8}
.post-nav .blog-pager-newer-link:before,.post-nav .blog-pager-older-link:after{margin-top:1px}
.post-nav .blog-pager-newer-link,.rtl .post-nav .blog-pager-older-link{float:left}
.post-nav .blog-pager-older-link,.rtl .post-nav .blog-pager-newer-link{float:right}
.post-nav .blog-pager-newer-link:before,.rtl .post-nav .blog-pager-older-link:after{content:'\f053';float:left;font-family:'Font Awesome 5 Free';font-size:9px;font-weight:900;margin:0 4px 0 0}
.post-nav .blog-pager-older-link:after,.rtl .post-nav .blog-pager-newer-link:before{content:'\f054';float:right;font-family:'Font Awesome 5 Free';font-size:9px;font-weight:900;margin:0 0 0 4px}
#blog-pager{float:left;width:100%;font-size:15px;font-weight:600;text-align:center;clear:both;box-sizing:border-box;padding:0;margin:35px 0 0}
#blog-pager .load-more{display:inline-block;height:28px;font-family:var(--text-font);font-size:13px;color:$(meta.color);font-weight:400;line-height:28px;padding:0 13px;border:1px solid rgba(155,155,155,0.17)}
#blog-pager #load-more-link{color:$(title.color);cursor:pointer}
#blog-pager #load-more-link:hover{background-color:$(button.bg);color:$(button.color);bordder-color:$(button.bg)}
#blog-pager .load-more.no-more{background-color:rgba(155,155,155,0.05)}
#blog-pager .loading,#blog-pager .no-more{display:none}
#blog-pager .loading .loader{height:30px}
#blog-pager .no-more.show{display:inline-block}
#blog-pager .loading .loader:after{width:26px;height:26px;margin:-15px 0 0 -15px}
.galaxymag-blog-post-comments{display:none;float:left;width:100%;box-sizing:border-box;padding:0;margin:0}
#comments,#disqus_thread{float:left;width:100%}
.galaxymag-blog-post-comments .fb_iframe_widget_fluid_desktop, .galaxymag-blog-post-comments .fb_iframe_widget_fluid_desktop span, .galaxymag-blog-post-comments .fb_iframe_widget_fluid_desktop iframe{float:left;display:block!important;width:100%!important}
.comments-system-facebook{width:calc(100% + 16px);margin-left:-8px}
.fb-comments{padding:0;margin:35px 0 0}
.comments{display:block;clear:both;padding:0;margin:35px 0 0}
.comments-system-disqus .comments{margin:25px 0 0}
.comments .comments-content{float:left;width:100%;margin:0}
#comments h4#comment-post-message{display:none}
.comments .comment-block{padding:0 0 0 50px}
.rtl .comments .comment-block{padding:0 50px 0 0}
.comments .comment-content{font-family:var(--text-font);font-size:14px;color:$(body.text.color);line-height:1.6em;margin:8px 0 12px}
.comments .comment-content > a:hover{text-decoration:underline}
.comment-thread .comment{position:relative;padding:0;margin:25px 0 0;list-style:none;border-radius:0}
.comment-thread ol{padding:0;margin:0}
.toplevel-thread ol > li:first-child{margin:0}
.comment-thread.toplevel-thread > ol > .comment > .comment-replybox-single iframe{box-sizing:border-box;padding:0 0 0 50px;margin:15px 0 0}
.comment-thread ol ol .comment:before{content:'\f3bf';position:absolute;left:-20px;top:-5px;font-family:'Font Awesome 5 Free';font-size:15px;color:rgba(155,155,155,0.17);font-weight:700;transform:rotate(90deg);margin:0}
.comment-thread .avatar-image-container{position:absolute;top:0;left:0;width:35px;height:35px;border-radius:100%;overflow:hidden}
.rtl .comment-thread .avatar-image-container{left:auto;right:0}
.avatar-image-container img{width:100%;height:100%;border-radius:100%}
.comments .comment-header .user{font-size:16px;color:$(title.color);display:inline-block;font-style:normal;font-weight:700;margin:0 0 3px}
.comments .comment-header .user a{color:$(title.color)}
.comments .comment-header .user a:hover{color:$(title.hover.color)}
.comments .comment-header .icon.user{display:none}
.comments .comment-header .icon.blog-author{display:inline-block;font-size:12px;color:$(main.color);font-weight:400;vertical-align:top;margin:-3px 0 0 5px}
.rtl .comments .comment-header .icon.blog-author{margin:-3px 5px 0 0}
.comments .comment-header .icon.blog-author:before{content:'\f058';font-family:'Font Awesome 5 Free';font-weight:400}
.comments .comment-header .datetime{display:inline-block;font-family:var(--meta-font);margin:0 0 0 10px}
.rtl .comments .comment-header .datetime{margin:0 10px 0 0}
.comment-header .datetime a{font-size:11px;color:$(meta.color);padding:0}
.comments .comment-actions{display:block;margin:0}
.comments .comment-actions a{color:$(body.link.color);font-size:13px;font-style:italic;margin:0 15px 0 0}
.rtl .comments .comment-actions a{margin:0 0 0 15px}
.comments .comment-actions a:hover{color:$(title.color)}
.item-control{display:none}
.loadmore.loaded a{display:inline-block;border-bottom:1px solid rgba(155,155,155,.51);text-decoration:none;margin-top:15px}
.comments .continue{display:none}
.comments .toplevel-thread > #top-continue a{display:block;color:$(body.link.color);text-align:center;margin:35px 0 0}
.comments .toplevel-thread > #top-continue a:hover{color:$(title.color)}
.comments .comment-replies{padding:0 0 0 50px}
.thread-expanded .thread-count a,.loadmore{display:none}
.comments .footer,.comments .comment-footer{float:left;width:100%;font-size:13px;margin:0}
.comments .comment-thread > .comment-replybox-thread{margin:25px 0 0}
.comment-form{float:left;width:100%;margin:0}
p.comments-message{font-size:15px;color:$(meta.color);font-style:italic;padding:0 0 25px;margin:0}
p.comments-message > a{color:$(body.link.color)}
p.comments-message > a:hover{text-decoration:underline}
p.comments-message > em{color:#d63031;font-style:normal}
.comment-form > p{display:none}
p.comment-footer span{color:$(meta.color)}
p.comment-footer span:after{content:'\002A';color:#d63031}
iframe#comment-editor{min-height:93px}
#sidebar-wrapper .sidebar{float:left;width:100%}
.sidebar > .widget{position:relative;float:left;width:100%;box-sizing:border-box;padding:0;margin:0 0 35px}
#sidebar3 > .widget:last-child{margin:0}
.sidebar .widget > .widget-title{position:relative;float:left;width:100%;height:30px;display:block;margin:0 0 25px;border-bottom:2px solid $(sidebar.wtitle.bg)}
.sidebar .widget > .widget-title > h3{position:relative;float:left;height:30px;background-color:$(sidebar.wtitle.bg);font-size:13px;color:$(sidebar.wtitle.color);font-weight:700;line-height:35px;text-transform:uppercase;padding:0 13px;margin:0}
.rtl .sidebar .widget > .widget-title > h3{float:right}
.sidebar .widget-content{float:left;width:100%;box-sizing:border-box;padding:0}
.sidebar .loader{height:180px}
#sidebar-tabs{display:none;position:relative;overflow:hidden;box-sizing:border-box;padding:0;margin:0 0 35px}
.sidebar-tabs .select-tab{position:relative;width:100%;height:32px;background-color:$(sidebar.wtitle.bg);overflow:hidden;margin:0 0 25px}
.sidebar-tabs .select-tab li{position:relative;float:left;display:inline-block;width:100%;height:32px;font-size:13px;color:$(sidebar.wtitle.color);font-weight:700;line-height:33px;text-align:center;text-transform:uppercase;cursor:pointer;list-style:none;margin:0;padding:0}
.rtl .sidebar-tabs .select-tab li{float:right}
.tabs-1 .select-tab li{position:relative;float:left;width:auto}
.tabs-1 .select-tab li,.tabs-1 .select-tab li a{cursor:auto}
.tabs-2 .select-tab li{width:50%}
.tabs-3 .select-tab li{width:calc(100% / 3)}
.tabs-4 .select-tab li{width:25%;font-size:11px}
.tabs-4 .select-tab li a{padding:0 5px}
.sidebar-tabs .select-tab li > a{color:$(sidebar.wtitle.color);display:block;padding:0 10px}
.tabs-1 .select-tab li > a{padding:0 13px}
.sidebar-tabs .select-tab li:hover,.sidebar-tabs .select-tab li.active,.sidebar-tabs .select-tab li.active:hover{background-color:$(tab.active.bg);color:$(tab.active.color)}
.sidebar-tabs .select-tab li.active a,.sidebar-tabs .select-tab li.active:hover a,.sidebar-tabs .select-tab li:hover a{color:$(tab.active.color)}
.sidebar-tabs .widget{display:none}
.sidebar-tabs .tab-active{display:block}
.sidebar-tabs .widget{padding:0;margin:0;border:0}
.sidebar-tabs > .widget > .widget-title{display:none}
ul.social-icons{display:flex;flex-wrap:wrap;margin:0 -2px}
.social-icons li{float:left;width:calc(100% / 3);box-sizing:border-box;padding:0 2px;margin:4px 0 0}
.rtl .social-icons li{float:right}
.social-icons li.link-0,.social-icons li.link-1,.social-icons li.link-2{margin:0}
.social-icons li a{float:left;width:100%;height:32px;font-size:15px;color:#fff;text-align:center;line-height:33px;padding:0;border-radius:2px}
.social-icons li a:before{float:left;width:32px;background-color:rgba(255,255,255,0.05)}
.rtl .social-icons li a:before{float:right}
.social-icons li a span{float:right;font-size:14px;padding:0 13px}
.font-size1 .social-icons li a span{font-size:13px}
.social-icons li a:hover{opacity:.85}
.custom-widget .custom-item{display:block;overflow:hidden;padding:0;margin:20px 0 0}
.custom-widget .custom-item.item-0{margin:0}
.custom-widget .entry-image-link{position:relative;float:left;width:85px;height:65px;overflow:hidden;margin:0 12px 0 0}
.rtl .custom-widget .entry-image-link{float:right;margin:0 0 0 12px}
.custom-widget .entry-image-link .entry-thumb{width:85px;height:65px}
.custom-widget .cmm-avatar{width:55px;height:55px;margin:0 12px 0 0;border-radius:50%}
.custom-widget .cmm-avatar .entry-thumb{border-radius:50%;width:55px;height:55px}
.custom-widget .cmm-snippet{display:block;font-size:12px;line-height:1.4em;margin:2px 0 0}
.custom-widget .entry-header{overflow:hidden}
.custom-widget .entry-title{font-size:14px;font-weight:700;line-height:1.4em;margin:0 0 3px}
.font-size1 .custom-widget .entry-title{font-size:13px}

.PopularPosts .popular-post{display:block;overflow:hidden;margin:20px 0 0}
.PopularPosts .popular-post.item-0{margin:0}
.PopularPosts .entry-image-link{position:relative;float:left;width:85px;height:90px;overflow:hidden;z-index:1;margin:0 12px 0 0}
.PopularPosts .popular-post{width:310px;padding:0;background-color:rgba(155,155,155,0.1)}
.PopularPosts .popular-post:hover{background-color:#111}
.PopularPosts .entry-image-link:after{width:32px;height:22px;line-height:22px;font-size:8px;border-radius:4px}
.rtl .PopularPosts .entry-image-link{float:right;margin:0 0 0 12px}
.PopularPosts .entry-image-link .entry-thumb{width:85px;height:100px}
.PopularPosts .entry-header{overflow:hidden}
.PopularPosts .entry-title{font-family:var(--text-font);font-size:12px;font-weight:600;line-height:1.5em;margin:10px 0 8px;display:-webkit-box;-webkit-box-orient:vertical;text-overflow:ellipsis;-webkit-line-clamp:2;overflow:hidden}
.font-size1 .PopularPosts .entry-title{font-size:16px;margin:0}

.FeaturedPost .entry-image-link{position:relative;float:left;width:100%;height:180px;z-index:1;overflow:hidden;margin:0}
.FeaturedPost .entry-header{float:left;margin:0}
.FeaturedPost .entry-title{font-size:19px;font-weight:700;line-height:1.4em;margin:10px 0 5px}
.font-size1 .FeaturedPost .entry-title{font-size:18px}
.FollowByEmail .widget-content{position:relative;box-sizing:border-box;padding:0;border:1px solid rgba(155,155,155,0.17)}
.FollowByEmail .widget-content-inner{padding:20px}
.follow-by-email-content{position:relative;z-index:5}
.follow-by-email-title{font-size:18px;color:$(title.color);margin:0 0 13px}
.follow-by-email-text{font-family:var(--text-font);font-size:13px;line-height:1.5em;margin:0 0 15px}
.follow-by-email-address{width:100%;height:34px;background-color:rgba(255,255,255,0.05);font-family:inherit;font-size:12px;color:#333;box-sizing:border-box;padding:0 10px;margin:0 0 10px;border:1px solid rgba(155,155,155,0.17);border-radius:2px}
.follow-by-email-address:focus{border-color:rgba(155,155,155,0.4)}
.follow-by-email-submit{width:100%;height:34px;background-color:$(button.bg);font-family:inherit;font-size:15px;color:$(button.color);font-weight:400;line-height:34px;cursor:pointer;padding:0 20px;border:0;border-radius:2px}
.follow-by-email-submit:hover{background-color:$(darkbutton.bg);color:$(darkbutton.color)}

.list-label li,.archive-list li{position:relative;display:block}
.list-label li a,.archive-list li a{display:block;color:#ffff;font-family:var(--meta-font);font-size:12px;font-weight:400;text-transform:capitalize;padding:5px 0}
.archive-list li a{text-transform:capitalize}
.list-label li:first-child a,.archive-list li:first-child a{padding:0 0 5px}
.list-label li:last-child a,.archive-list li:last-child a{padding-bottom:0}
.list-label li a:before,.archive-list li a:before{content:'\f0da';font-family:'Font Awesome 5 Free';float:left;font-size:12px;font-weight:900;font-style:normal;margin:0 3px}
.rtl .list-label li a:before,.rtl .archive-list li a:before{content:'\f053';float:right;margin:0 0 0 3px}
.list-label li a:hover,.archive-list li a:hover{color:var(--title-hover-color)}
.list-label .label-count,.archive-list .archive-count{float:right;font-size:12px;color:var(--title-hover-color);text-decoration:none;margin:2px 0 0 5px}
.rtl .list-label .label-count,.rtl .archive-list .archive-count{float:left;margin:2px 5px 0 0}

.cloud-label li{position:relative;float:left;margin:0 5px 5px 0}
.rtl .cloud-label li{float:right;margin:0 0 5px 5px}
.cloud-label li a{display:block;height:26px;background-color:rgba(155,155,155,0.1);color:$(title.color);font-family:var(--meta-font);font-size:12px;line-height:26px;font-weight:400;padding:0 10px;border-radius:2px}
.cloud-label li a:hover{background-color:$(button.bg);color:$(button.color)}
.cloud-label .label-count{display:none}
.BlogSearch .search-form{display:flex;background-color:rgba(255,255,255,0.05);padding:2px;border:1px solid rgba(155,155,155,0.17);border-radius:2px}
.BlogSearch .search-input{float:left;width:100%;height:32px;background-color:rgba(0,0,0,0);font-family:inherit;font-weight:400;font-size:13px;color:$(body.text.color);line-height:32px;box-sizing:border-box;padding:0 10px;margin:0;border:0}
.BlogSearch .search-input:focus{outline:none}
.BlogSearch .search-action{float:right;width:auto;height:32px;font-family:inherit;font-size:15px;font-weight:400;line-height:32px;cursor:pointer;box-sizing:border-box;background-color:$(button.bg);color:$(button.color);padding:0 15px;border:0;border-radius:2px}
.BlogSearch .search-action:hover{background-color:$(darkbutton.bg);color:$(darkbutton.color)}
.Profile ul li{float:left;width:100%;margin:20px 0 0}
.Profile ul li:first-child{margin:0}
.Profile .profile-img{float:left;width:55px;height:55px;background-color:rgba(155,155,155,0.08);overflow:hidden;color:transparent!important;margin:0 12px 0 0;border-radius:50%}
.Profile .profile-datablock{margin:0}
.Profile .profile-info > .profile-link{display:inline-block;font-size:12px;color:$(body.link.color);font-weight:400;margin:3px 0 0}
.Profile .profile-info > .profile-link:hover{color:$(title.color)}
.Profile .g-profile,.Profile .profile-data .g-profile{font-size:15px;color:$(title.color);font-weight:700;line-height:1.4em;margin:0 0 5px}
.Profile .g-profile:hover,.Profile .profile-data .g-profile:hover{color:$(title.hover.color)}
.Profile .profile-textblock{display:none}
.profile-data.location{font-family:var(--meta-font);font-size:12px;color:$(meta.color);line-height:1.4em;margin:2px 0 0}
.galaxymag-widget-ready .PageList ul li,.galaxymag-widget-ready .LinkList ul li{position:relative;display:block}
.galaxymag-widget-ready .PageList ul li a,.galaxymag-widget-ready .LinkList ul li a{display:block;color:$(title.color);font-size:13px;font-weight:400;padding:5px 0}
.galaxymag-widget-ready .PageList ul li:first-child a,.galaxymag-widget-ready .LinkList ul li:first-child a{padding:0 0 5px}
.galaxymag-widget-ready .PageList ul li a:hover,.galaxymag-widget-ready .LinkList ul li a:hover{color:$(title.hover.color)}
.Text .widget-content{font-family:var(--text-font);font-size:13px;line-height:1.6em}
.Image.about-image > .widget-title{display:none}
.Image .image-caption{font-size:13px;line-height:1.6em;margin:10px 0 0;display:block}
.Image.about-image .image-caption{margin:15px 0 0}
.contact-form-widget form{font-family:inherit;font-weight:400}
.contact-form-name{float:left;width:100%;height:34px;background-color:rgba(255,255,255,0.05);font-family:inherit;font-size:13px;color:$(body.text.color);line-height:34px;box-sizing:border-box;padding:5px 10px;margin:0 0 10px;border:1px solid rgba(155,155,155,0.17);border-radius:2px}
.contact-form-email{float:left;width:100%;height:34px;background-color:rgba(255,255,255,0.05);font-family:inherit;font-size:13px;color:$(body.text.color);line-height:34px;box-sizing:border-box;padding:5px 10px;margin:0 0 10px;border:1px solid rgba(155,155,155,0.17);border-radius:2px}
.contact-form-email-message{float:left;width:100%;background-color:rgba(255,255,255,0.05);font-family:inherit;font-size:13px;color:$(body.text.color);box-sizing:border-box;padding:5px 10px;margin:0 0 10px;border:1px solid rgba(155,155,155,0.17);border-radius:2px}
.contact-form-button-submit{float:left;width:100%;height:34px;background-color:$(button.bg);font-family:inherit;font-size:15px;color:$(button.color);font-weight:400;line-height:34px;cursor:pointer;box-sizing:border-box;padding:0 10px;margin:0;border:0;border-radius:2px}
.contact-form-button-submit:hover{background-color:$(darkbutton.bg);color:$(darkbutton.color)}
.contact-form-error-message-with-border{float:left;width:100%;background-color:rgba(0,0,0,0);font-size:12px;color:#e74c3c;text-align:left;line-height:12px;padding:3px 0;margin:10px 0;box-sizing:border-box;border:0}
.contact-form-success-message-with-border{float:left;width:100%;background-color:rgba(0,0,0,0);font-size:12px;color:#27ae60;text-align:left;line-height:12px;padding:3px 0;margin:10px 0;box-sizing:border-box;border:0}
.rtl .contact-form-error-message-with-border,.rtl .contact-form-success-message-with-border{text-align:right}
.contact-form-cross{cursor:pointer;margin:0 0 0 3px}
.rtl .contact-form-cross{margin:0 3px 0 0}
.contact-form-error-message,.contact-form-success-message{margin:0}
.contact-form-name:focus,.contact-form-email:focus,.contact-form-email-message:focus{background-color:rgba(155,155,155,0.05);border-color:rgba(155,155,155,0.4)}
#footer-wrapper{background-color:$(footer.bg);color:$(footer.text.color);border-top:1px solid rgba(155,155,155,0.17)}
#footer-wrapper > .container{position:relative;overflow:hidden;margin:0 auto}
.footer-widgets-wrap{position:relative;display:flex;margin:0 -17.5px}
#footer-wrapper .footer{display:inline-block;float:left;width:calc(100% / 3);box-sizing:border-box;padding:40px 17.5px}
.rtl #footer-wrapper .footer{float:right}
#footer-wrapper .footer.no-items{padding:0 17.5px}
#footer-wrapper .footer .widget{float:left;width:100%;padding:0;margin:35px 0 0}
#footer-wrapper .footer .widget:first-child{margin:0}
.footer .widget > .widget-title > h3,.footer .follow-by-email-title{position:relative;color:$(footer.widget.title.color);font-size:15px;font-weight:700;text-transform:uppercase;margin:0 0 20px}
.footer .follow-by-email-title{margin:0 0 13px}
.footer .about-text > .widget-title{display:none}
.footer .loader{height:145px}
.footer .no-posts{color:$(footer.text.color)}
.footer .PopularPosts .widget-content .post:first-child,.footer .custom-widget li:first-child,.footer .cmm-widget li:first-child{padding:0}
.footer .entry-title a,.footer .LinkList ul li a,.footer .PageList ul li a,.footer .Profile .g-profile,.footer .Profile .profile-data .g-profile{color:$(footer.color)}
.footer .entry-title a:hover{color:$(footer.post.title.hover.color)}
.footer .Profile .profile-info > .profile-link{color:$(footer.hover.color)}
.footer .Profile .profile-info > .profile-link:hover{color:$(footer.color)}
.footer .LinkList ul li a:hover,.footer .PageList ul li a:hover,.footer .Profile .g-profile:hover,.footer .Profile .profile-data .g-profile:hover{color:$(footer.hover.color)}
.footer .custom-widget .cmm-snippet,.footer .profile-data.location,.footer .Text .widget-content,.footer .Image .image-caption{color:$(footer.text.color)}
.footer .list-label li a,.footer .archive-list li a,.footer .PageList ul li a,.footer .LinkList ul li a{border-color:rgba(155,155,155,0.06)}
.footer .list-label li a,.footer .list-label li a:before,.footer .archive-list li a,.footer .archive-list li a:before{color:$(footer.color)}
.footer .list-label li > a:hover,.footer .archive-list li > a:hover,.footer .Text .widget-content a{color:$(footer.hover.color)}
.footer .cloud-label li a{color:$(footer.color)}
.footer .cloud-label li a:hover{background-color:$(button.bg);color:$(button.color)}
.footer .contact-form-name,.footer .contact-form-email,.footer .contact-form-email-message,.footer .BlogSearch .search-input{color:$(footer.color)}
#about-section{position:relative;float:left;width:100%;display:flex;flex-wrap:wrap;margin:0;padding:35px 0;border-top:1px solid rgba(155,155,155,0.1)}
#about-section.no-items{padding:0;border:0}
.compact-footer #about-section{border:0}
#about-section .widget{position:relative;float:left;box-sizing:border-box;margin:0}
.rtl #about-section .widget{float:right}
#about-section .widget > widget-content{display:none}
#about-section .widget-content .widget-title > h3{position:relative;color:$(footer.color);font-size:15px;font-weight:700;text-transform:uppercase;margin:0 0 10px}
#about-section .Image{width:70%;padding:0 35px 0 0}
.rtl #about-section .Image{padding:0 0 0 35px}
#about-section .Image .widget-content{position:relative;float:left;width:100%;margin:0}
#about-section .footer-logo{display:block;float:left;max-width:30%;height:34px;padding:19px 0;margin:0}
.rtl #about-section .footer-logo{float:right}
#about-section .footer-logo img{height:34px;vertical-align:middle}
#about-section .about-content{max-width:70%;display:block;float:left;padding:0 0 0 35px;box-sizing:border-box}
.rtl #about-section .about-content{float:right;padding:0 35px 0 0}
#about-section .Image .no-image .about-content{max-width:100%;padding:0 35px 0 0}
.rtl #about-section .Image .no-image .about-content{padding:0 0 0 35px}
#about-section .LinkList{float:right;width:30%}
.rtl #about-section .LinkList{float:left}
.about-section ul.social-footer{float:right;padding:20px 0 0}
.rtl .about-section ul.social-footer{float:left}
.about-section .social-footer li{float:left;margin:0 0 0 7px}
.rtl .about-section .social-footer li{float:right;margin:0 7px 0 0}
.about-section .social-footer li a{display:block;width:32px;height:32px;font-size:16px;color:#fff;text-align:center;line-height:32px;border-radius:2px}
.about-section .social-footer li a:hover{opacity:.85}
#sub-footer-wrapper{display:block;width:100%;background-color:$(footer.bar.bg);color:$(footer.bar.color);overflow:hidden}
#sub-footer-wrapper .container{padding:15px 0;margin:0 auto;overflow:hidden}
#footer-menu{float:right;position:relative;display:block}
.rtl #footer-menu{float:left}
#footer-menu .widget > .widget-title,#footer-copyright .widget > .widget-title{display:none}
#footer-menu ul li{float:left;display:inline-block;height:30px;padding:0;margin:0}
.rtl #footer-menu ul li{float:right}
#footer-menu ul li a{font-family:var(--text-font);font-size:13px;font-weight:400;display:block;color:$(footer.bar.color);line-height:31px;padding:0;margin:0 0 0 25px}
.rtl #footer-menu ul li a{margin:0 25px 0 0}
#footer-menu ul li a:hover{color:$(footer.bar.hover.color)}
#sub-footer-wrapper .footer-copyright{font-family:var(--meta-font);font-size:13px;float:left;height:30px;line-height:31px;font-weight:400}
.rtl #sub-footer-wrapper .footer-copyright{float:right}
#sub-footer-wrapper .footer-copyright a{color:$(main.color)}
#sub-footer-wrapper .footer-copyright a:hover{color:$(footer.bar.hover.color)}
.hidden-widgets{display:none;visibility:hidden}
.back-top{display:none;position:fixed;bottom:15px;right:15px;width:32px;height:32px;background-color:$(button.bg);cursor:pointer;overflow:hidden;font-size:13px;color:$(button.color);text-align:center;line-height:32px;z-index:2;border-radius:2px}
.rtl .back-top{right:auto;left:15px}
.back-top:after{content:'\f077';position:relative;font-family:'Font Awesome 5 Free';font-weight:900}
.back-top:hover{opacity:.9;box-shadow:0 0 5px rgba(0,0,0,0.15)}
.error404 #main-wrapper{width:100%}
.error404 #sidebar-wrapper{display:none}
.errorWrap{color:$(title.color);text-align:center;padding:60px 0}
.errorWrap h3{font-size:160px;line-height:1em;margin:0 0 20px}
.errorWrap h4{font-size:25px;margin:0 0 20px}
.errorWrap p{margin:0 0 10px}
.errorWrap a{display:inline-block;height:32px;background-color:$(button.bg);font-size:15px;color:$(button.color);font-weight:700;line-height:32px;padding:0 20px;margin:15px 0 0;border-radius:2px}
.errorWrap a:hover{background-color:$(darkbutton.bg);color:$(darkbutton.color)}
.cookie-choices-info{top:auto!important;bottom:0}
.normal h2.entry-title,.normal .sidebar-tabs .select-tab li,.normal #galaxymag-main-menu-nav > li > a,.normal .title-wrap > h3,.normal .about-author .author-name,.normal .comments .comment-header .user,.normal .mobile-menu ul li,.normal .follow-by-email-title{font-weight:400}
.normal .widget-title > h3{font-weight:400!important}
.medium h2.entry-title,.medium .sidebar-tabs .select-tab li,.medium #galaxymag-main-menu-nav > li > a,.medium .title-wrap > h3,.medium .about-author .author-name,.medium .comments .comment-header .user,.medium .mobile-menu ul li,.medium .follow-by-email-title{font-weight:500}
.medium .breaking-news .entry-title{font-weight:400}
.medium .widget-title > h3{font-weight:500!important}
.semibold h2.entry-title,.semibold .sidebar-tabs .select-tab li,.semibold #galaxymag-main-menu-nav > li > a,.semibold .title-wrap > h3,.semibold .about-author .author-name,.semibold .comments .comment-header .user,.semibold .mobile-menu ul li,.semibold .follow-by-email-title{font-weight:600}
.semibold .widget-title > h3{font-weight:600!important}
.semibold .sidebar-tabs .select-tab li{font-size:12px}
@media screen and (max-width: 1133px) {
#outer-wrapper{max-width:100%}
.row-x1{width:100%}
.navbar-wrap .navbar,#breaking-wrap .container,.header-ads-wrap .container,#featured-wrapper .container,#content-wrapper,#footer-wrapper > .container,#sub-footer-wrapper{box-sizing:border-box;padding:0 20px}
}
@media screen and (max-width: 980px) {
#main-wrapper{width:calc(100% - (30% + 35px))}
#sidebar-wrapper{width:30%}
}
@media screen and (max-width: 880px) {
.navbar-wrap .navbar{padding:0}
.main-logo-wrap{width:100%;text-align:center;z-index:15;margin:0}
.main-logo .header-widget,.main-logo .main-logo-img,.main-logo .blog-title{float:none;display:inline-block}
.nav-active #outer-wrapper{filter:blur(2px)}
.nav-active .back-top{opacity:0!important}
#outer-wrapper{transition:filter .17s ease}
.overlay,.show-mobile-menu,#slide-menu{display:block}
.nav-active .overlay{visibility:visible;opacity:1}
.show-search,.hide-search{width:auto;text-align:center;padding:0 20px}
#nav-search .search-input{padding:0 60px 0 20px}
.rtl #nav-search .search-input{padding:0 20px 0 60px}
.main-menu,.galaxymag-main-menu{display:none}
#main-wrapper,#sidebar-wrapper{width:100%}
#sidebar-wrapper{margin:35px 0 0}
.footer-widgets-wrap{display:block;overflow:hidden;padding:35px 0 0}
.compact-footer .footer-widgets-wrap{padding:0}
#footer-wrapper .footer{width:100%;padding:0 15px 35px}
#footer-wrapper .footer.no-items{padding:0 15px}
}
@media screen and (max-width: 680px) {
#breadcrumb{font-size:10px}
#breaking-sec .widget > .widget-title{font-size:0}
#breaking-sec .widget > .widget-title > h3:before,.rtl #breaking-sec .widget > .widget-title > h3:before{margin:0}
#breaking-sec .breaking-news{padding:0 0 0 10px}
.rtl #breaking-sec .breaking-news{padding:0 10px 0 0}
#featured-wrapper .container{padding:0}
#featured-sec .show-ify .widget-content,#featured-sec .featured-grid{height:auto!important}
#featured-sec .show-ify .loader{min-height:230px}
.featured-item{width:70%!important;height:150px!important;padding:0!important;margin:0 0 0 2px !important}
.rtl .featured-item{margin:0 2px 0 0 !important}
.featured-item.item-0{width:100%!important;height:200px!important;margin:0 0 2px!important}
.featured-item.item-1,.rtl .featured-item.item-1{margin:0!important}
.featured-item .entry-info{padding:15px!important}
.featured-item .entry-title{font-size:14px!important}
.featured-item.item-0 .entry-title{font-size:23px!important}
.featured-item .entry-meta{display:none}
.featured-item.item-0 .entry-meta{display:block}
.featured-scroll{position:relative;float:left;width:100%;height:150px;overflow:hidden;overflow-x:auto;white-space:nowrap;-webkit-overflow-scrolling:touch;margin:0}
.featured-scroll .featured-item{display:inline-block!important;float:none!important;white-space:normal!important}
.col-right{position:relative;float:right;width:calc(100% - 130px)}
.col-left{position:relative;float:left;width:120px}
.bk-left{font-family:var(--text-font);font-size:10px}
.col-left .post-image-wrap{position:relative;float:left;width:100%;height:160px;;box-sizing:border-box;overflow:hidden}
.product-header .bk-left b {font-family:var(--text-font);font-size:10px}
.col-right{font-size:8px}
.block-posts-1 .block-item{width:100%}
.block-posts-1 .item-0{width:100%;margin:0 0 5px}
.block-posts-1 .item-1{margin:20px 0 0}
.block-posts-1 .block-inner{height:200px}
.block-posts-2 .item-0 .entry-title,.font-size1 .block-posts-2 .item-0 .entry-title{font-size:17px}
.block-posts-2 .block-grid .block-item{width:50%}
.block-posts-2.total-4 .block-grid .block-item{width:100%}
.block-posts-2.total-4 .block-grid .entry-image-link{height:210px}
.block-posts-2.total-4 .block-grid .entry-title{margin:10px 0 3px}
.block-carousel .entry-image-link{height:210px}
.block-posts .block-column{width:100%}
.block-videos .videos-item{width:50%;padding:0 10px}
.block-videos .videos-item.item-2{margin:20px 0 0}
.block-videos.total-3 .videos-item{width:50%;padding:0 10px}
.block-videos.total-3 .videos-item.item-1{margin:0px 0 0}
.block-videos.total-3 .entry-image-link{height:105px}
.block-videos.total-3 .entry-title{margin:10px 0 3px}
.grid-posts-1 .grid-item{width:50%;padding:0 10px}
.grid-posts-1 .grid-item.item-2{margin:20px 0 0}
.grid-posts-1.total-3 .grid-item{width:100%;padding:0 10px}
.grid-posts-1.total-3 .grid-item.item-1{margin:20px 0 0}
.grid-posts-1.total-3 .entry-image-link{height:160px}
.grid-posts-1.total-3 .entry-title{margin:10px 0 3px}
.grid-posts-2 .grid-item{width:50%}
.grid-posts-2 .grid-item.item-1{margin:0px 0 0}
.grid-posts-2 .entry-image-link{height:220px}
.index-post{width:50%}
.index-post .entry-image{margin:20px 0 0}
.index-post{width:50%;padding:0 10px}
.index-post{margin:0px 0 0}
.index-post .entry-image{position:relative;width:100%;height:210px;overflow:hidden;margin:0}
.index-post .entry-title{margin:10px 0 3px}
.entry-tags{display:none}
.related-posts .related-item{width:50%;padding:0 10px}
.related-posts .related-item.item-2{margin:0px 0 0}
.related-posts.total-3 .related-item{width:100%;padding:0 10px}
.related-posts.total-3 .related-item.item-1{margin:20px 0 0}
.related-posts.total-3 .entry-image-link{height:150px}
.related-posts.total-3 .entry-title{margin:10px 0 3px}
#about-section{text-align:center}
#about-section .Image,.rtl #about-section .Image{width:100%;padding:0}
#about-section .footer-logo,.rtl #about-section .footer-logo{display:inline-block;float:none;max-width:100%;padding:0 0 30px}
#about-section .about-content,.rtl #about-section .about-content,#about-section .Image .no-image .about-content,.rtl #about-section .Image .no-image .about-content{max-width:100%;padding:0}
#about-section .LinkList{width:100%}
.about-section ul.social-footer,.rtl .about-section ul.social-footer{float:none;display:block;padding:35px 0 0}
.about-section .social-footer li,.rtl .about-section .social-footer li{float:none;display:inline-block;margin:0 5px}
#sub-footer-wrapper .container{padding:20px 0}
#footer-menu,#sub-footer-wrapper .footer-copyright{width:100%;height:auto;line-height:inherit;text-align:center}
#footer-menu ul li,.rtl #footer-menu ul li{float:none;height:auto}
#footer-menu ul li a,.rtl #footer-menu ul li a{line-height:inherit;margin:0 10px}
#sub-footer-wrapper .footer-copyright .widget{padding:0 0 20px}
}
@media screen and (max-width: 540px) {
.block-posts-2 .block-grid .entry-image-link,.grid-posts-1 .entry-image-link,.block-videos .entry-image-link,.related-posts .entry-image-link{height:220px}
.block-carousel .entry-title{margin:10px 0 3px}
.block-carousel .entry-image-link{width:100%;height:210px;position:relative;display:block;overflow:hidden}
}
@media screen and (max-width: 440px) {
.item-post h1.entry-title{font-size:25px}
.post-share{margin:25px 0 0}
.share-links li{margin:5px 5px 0 0}
.share-links li a.twitter{width:34px}
.share-links li a.twitter span{display:none}
.share-links li a.twitter:before{width:34px;background-color:rgba(0,0,0,0)}
.about-author .avatar-container{width:55px;height:55px;margin:0 15px 0 0}
}
@media screen and (max-width: 360px) {
#slide-menu{width:270px}
.featured-item{width:80%!important;height:100px!important}
.featured-item.item-0{width:100%!important;height:200px!important}
.featured-item.item-0 .entry-title{font-size:21px!important}
.featured-scroll{height:200px}
.block-posts-2 .block-grid .entry-image-link,.grid-posts-1 .entry-image-link,.block-videos .entry-image-link,.related-posts .entry-image-link{height:220px}
.item-post h1.entry-title{font-size:22px}
.about-author .author-name span{display:none}
.share-links li a,.share-links li a.twitter{width:32px}
.share-links li a.twitter:before{width:32px;background-color:rgba(0,0,0,0)}
.errorWrap h3{font-size:130px}
}
]]></b:skin>

<b:if cond='data:view.isLayoutMode'>
<b:template-skin>
<![CDATA[
/*------Layout (No Edit)----------*/
body#layout #outer-wrapper,body#layout .row{width:auto;padding:0}
body#layout{width:920px;position:relative;background-color:#f9f9f9;padding:95px 5px 0;margin:0}
body#layout:before{content:'Theme Options - v3.0';position:absolute;top:0;left:5px;right:5px;height:95px;font-family:Roboto,sans-serif;font-size:23px;color:#1f2024;line-height:95px;text-align:center}
body#layout div.section{display:block;background-color:#f1f1f1!important;margin:0 5px 10px!important;padding:16px 16px 18px!important;border-color:#e5e5e5}
body#layout .no-items.section{display:block}
body#layout .section h4{font-size:14px;color:#1f2024;text-transform:uppercase;margin:0}
body#layout .section h4:after{text-transform:initial;color:#656565;font-weight:400}
body#layout .add_widget a{color:#0084b4!important}
body#layout .widget-wrap3{overflow:hidden}
body#layout .widget-content{width:auto;max-width:none;max-height:none;margin:0;border:1px solid #e5e5e5;border-left:0}
body#layout .locked-widget .widget-content{border-left:1px solid #0084b4}
body#layout .locked-widget .widget-content:hover{border-left-color:#79b530}
body#layout .widget .widget-content a.editlink{border-radius:2px}
body#layout .visibility .editlink{background:#0084b4 url(https://1.bp.blogspot.com/-iQoCOwqjB-w/Wy1bDznOM4I/AAAAAAAACGA/8BUOPStr0sk5oud9hWpHBQTrmkeJDoAvACK4BGAYYCw/s18-c/mode_edit_w600_24dp.png) no-repeat center!important}
body#layout .visibility .editlink:hover{background-color:#79b530!important}
body#layout .draggable-widget .widget-wrap2{background:#0084b4 url(https://1.bp.blogspot.com/-yTAuT5aZ1EY/Wy1eEeo4SbI/AAAAAAAACGM/FxOTPwL-Ch0_lyZxLRzhv2EWHINOmCjWACK4BGAYYCw/s22/draggable.png) no-repeat 4px 50%!important}
body#layout .draggable-widget .widget-wrap1:hover .widget-wrap2{background-color:#79b530!important}
body#layout .visibility .layout-widget-state.visible{background-image:url(https://4.bp.blogspot.com/-cgTj6sYN20w/XG1MixYFa3I/AAAAAAAAD94/1Q79bEtkdMc6se8dvKvseNL-cedMPz3JQCK4BGAYYCw/s1600/visibility_c3_600_24dp.png)!important}
body#layout .visibility .layout-widget-state.not-visible{background-image:url(https://4.bp.blogspot.com/-xCIqf_dm-jE/XG1MsEOgHYI/AAAAAAAAD-A/hpgoQ1p4kGwjvbi37Z1a5eGItNKRxkh1QCK4BGAYYCw/s1600/visibility_off_c3_600_24dp.png)!important;opacity:1}
body#layout div.layout-widget-description{font-size:11px;line-height:1.2em}
body#layout .theme-options,body#layout #galaxymag-main-menu .widget{display:block!important}
body#layout div.ify-panel{background-color:#edf4ff!important;overflow:hidden!important;border-color:#cdd4ef}
body#layout .ify-panel .widget{float:left;width:32%;margin-right:2%}
body#layout .ify-panel .widget-content{border-color:#cdd4ef!important}
body#layout .ify-panel #LinkList151{margin-right:0}
body#layout .ify-panel div.layout-widget-description{display:none}
body#layout .navbar > .container{display:block;padding:0}
body#layout .show-mobile-menu,body#layout .show-search,body#layout #nav-search{display:none}
body#layout .main-logo-wrap,body#layout .main-menu-wrap{float:left;width:50%;margin:0}
body#layout #content-wrapper{margin:0}
body#layout #content-wrapper > .container{display:flex;margin:0}
body#layout #main-wrapper{width:67%;padding:0}
body#layout #sidebar-wrapper{width:33%;padding:0}
body#layout #custom-ads{display:block!important;display:flex!important}
body#layout #custom-ads .section{width:50%}
body#layout #ify-panel > h4:after{content:' - By Giant Template'}
body#layout #main-logo > h4:after{content:' - Site Logo (Standard height = 34px)'}
body#layout #galaxymag-main-menu > h4:after{content:' - DropDown and MegaMenu'}
body#layout #breaking-sec > h4:after{content:' - After Navbar on HomePage'}
body#layout #header-ads > h4:after{content:' - Before Featured Posts'}
body#layout #featured-sec > h4:after{content:' - 6 Featured Posts Styles'}
body#layout .block-posts > h4:after{content:' - 8 Block Posts Styles'}
body#layout #home-ad > h4:after{content:' - Before Blog Posts'}
body#layout #main > h4:after{content:' - Default Blog Posts Section'}
body#layout #main-before-ad > h4:after{content:' - Before Post Content'}
body#layout #main-after-ad > h4:after{content:' - After Post Content'}
body#layout .sidebar > h4:after{content:' - Default Gadgets'}
body#layout #social-counter > h4:after{content:' - Social Icons'}
body#layout #sidebar-tabs > h4:after{content:' - Max 4 Gadgets'}
body#layout #footer-sec1 > h4:after{content:' - Left Section'}
body#layout #footer-sec2 > h4:after{content:' - Center Section'}
body#layout #footer-sec3 > h4:after{content:' - Right Section'}
body#layout #about-section > h4:after{content:' - Site Logo, Description and Social Links'}
body#layout #footer-copyright > h4:after{content:' - Custom Footer Credits'}
body#layout #footer-menu > h4:after{content:' - Footer Links'}
body#layout .footer-widgets-wrap{display:flex}
body#layout .footer-widgets-wrap div.footer{width:100%}
body#layout #about-section{overflow:hidden!important}
body#layout #about-section .widget{float:left;width:49%;margin-right:2%}
body#layout #about-section .LinkList{margin-right:0}
body#layout #sub-footer-wrapper .container{display:flex}
body#layout #footer-menu,body#layout #footer-copyright{width:50%}
body#layout:after{content:'Design by Giant Template';display:block;font-family:Roboto,sans-serif;font-size:14px;color:#555;line-height:1;text-align:center;visibility:visible;padding:20px 0}
/*------Layout (end)----------*/
]]></b:template-skin>
</b:if>

<!-- Global Variables -->
<script defer='defer' type='text/javascript'>
//<![CDATA[
    // Global variables with content. "Available for Edit"
    var monthFormat = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        fixedMenu = true,
        fixedSidebar = true,
        slideRTL = false,
        relatedPostsNum = 10, // 3 or 6
        commentsSystem = "blogger",
        disqusShortname = "galaxymag-theme",
        showMoreText = '',
        followByEmailText = '';
//]]>
</script>

<b:if cond='data:blog.languageDirection == &quot;rtl&quot;'>
<!-- Global Variables (RTL) -->
<script type='text/javascript'>
//<![CDATA[
    var monthFormat = ["يناير", "فبراير", "مارس", "أبريل", "ماي", "يونيو", "يوليوز", "غشت", "سبتمبر", "واكتوبر", "نونبر", "ديسمبر"],
        slideRTL = true;
//]]>
</script>
</b:if>

<b:defaultmarkups>
  <b:defaultmarkup type='Common'>
    <b:includable id='widget-title'>
      <b:if cond='data:title == &quot;about-image&quot;'>
        <b:class name='about-image'/>
      </b:if>
      <b:if cond='data:defaultTitle or data:title'>
        <div class='widget-title'>
          <h3 class='title'>
            <data:title/>
          </h3>
        </div>
      </b:if>
    </b:includable>  
    <b:includable id='theme-head'>
      <meta expr:content='&quot;text/html; charset=&quot; + data:blog.encoding' http-equiv='Content-Type'/>
      <meta content='blogger' name='generator'/>
      <link expr:href='data:blog.blogspotFaviconUrl' rel='icon' type='image/x-icon'/>
      <meta expr:content='data:skin.vars.keycolor' name='theme-color'/>
      <meta expr:content='data:skin.vars.keycolor' name='msapplication-navbutton-color'/>
      <b:if cond='data:blog.adultContent'>
        <meta content='adult' name='rating'/>
      </b:if>
      <link expr:href='data:view.url.canonical' rel='canonical'/>
      <data:blog.feedLinks/><data:blog.meTag/>
      <meta expr:content='data:view.description.escaped' name='description'/>
      <b:tag cond='data:view.isMultipleItems and data:widgets.Blog.first.posts[0].featuredImage' expr:href='data:widgets.Blog.first.posts[0].featuredImage' name='link' rel='image_src'/>
      <b:tag cond='data:view.isSingleItem and data:view.featuredImage' expr:href='data:view.featuredImage' name='link' rel='image_src'/>
      <b:include name='customOpenGraphMetaData'/>
    </b:includable>
    <b:includable id='customOpenGraphMetaData'>
      <!-- Metadata for Open Graph protocol. See http://ogp.me/. -->
      <b:if cond='data:view.isHomepage'>
        <meta content='website' property='og:type'/>
      </b:if>
      <b:if cond='data:view.isSingleItem'>
        <meta content='article' property='og:type'/>
      </b:if>
      <b:if cond='data:view.isMultipleItems and not data:view.isHomepage'>
        <meta content='object' property='og:type'/>
      </b:if>
      <meta expr:content='data:blog.title.escaped' property='og:site_name'/>
      <meta expr:content='data:view.title.escaped' property='og:title'/>
      <meta expr:content='data:blog.url.canonical' property='og:url'/>
      <meta expr:content='data:view.description.escaped' property='og:description'/>
      <b:tag cond='data:view.isMultipleItems and data:widgets.Blog.first.posts[0].featuredImage' expr:content='data:widgets.Blog.first.posts[0].featuredImage' name='meta' property='og:image'/>
      <b:if cond='data:view.featuredImage'>
        <meta expr:content='data:view.featuredImage' property='og:image'/>
        <meta expr:content='data:view.featuredImage' name='twitter:image'/>
      </b:if>
      <meta content='summary_large_image' name='twitter:card'/>
      <meta expr:content='data:view.title.escaped' name='twitter:title'/>
      <meta expr:content='data:blog.url.canonical' name='twitter:url'/>
      <meta expr:content='data:view.description.escaped' name='twitter:description'/>
      <b:if cond='data:view.isHomepage'>
        <script type='application/ld+json'>{&quot;@context&quot;:&quot;http://schema.org&quot;,&quot;@type&quot;:&quot;WebSite&quot;,&quot;name&quot;:&quot;<data:view.title.escaped/>&quot;,&quot;url&quot;:&quot;<data:view.url.canonical/>&quot;,&quot;potentialAction&quot;:{&quot;@type&quot;:&quot;SearchAction&quot;,&quot;target&quot;:&quot;<data:view.url.canonical/>search?q={search_term_string}&quot;,&quot;query-input&quot;:&quot;required name=search_term_string&quot;}}</script>
      </b:if>
    </b:includable>
    <b:includable id='translate'>
      <b:switch var='data:blog.locale.language'>
        <b:case value='en'/><b:include name='customLang'/>
        <b:default/><b:include name='customLang'/>
      </b:switch>
    </b:includable> 
    <b:includable id='customLang'>
      <b:switch var='data:message'>
        <b:case value='prevPost'/><b:if cond='data:blog.locale.language == &quot;en&quot;'>Previous Post<b:elseif cond='data:blog.locale.language == &quot;es&quot;'/></b:if>
<b:case value='followByEmailText'/><b:if cond='data:blog.locale.language == &quot;en&quot;'>Get all latest content delivered straight to your inbox.<b:elseif cond='data:blog.locale.language == &quot;es&quot;'/>Obtener todo el contenido más reciente directamente en su correo electrónico.<b:elseif cond='data:blog.locale.language == &quot;pt&quot;'/>Obtenha todo o conteúdo mais recente diretamente na sua caixa de entrada.<b:else/><data:messages.getEmailNotifications/></b:if>
<b:case value='loadMorePosts'/><b:if cond='data:blog.locale.language == &quot;en&quot;'>Load More Posts<b:elseif cond='data:blog.locale.language == &quot;es&quot;'/>Cargar Más Entradas<b:elseif cond='data:blog.locale.language == &quot;pt&quot;'/>Carregar Mais Postagens<b:else/><data:messages.loadMorePosts/></b:if>
<b:case value='noMorePosts'/><b:if cond='data:blog.locale.language == &quot;en&quot;'>That is All<b:elseif cond='data:blog.locale.language == &quot;es&quot;'/>Eso es Todo<b:elseif cond='data:blog.locale.language == &quot;pt&quot;'/>Isso é Tudo<b:else/><data:messages.noResultsFound/></b:if>
      </b:switch>
    </b:includable> 
  </b:defaultmarkup>
  <b:defaultmarkup type='Header'>
    <b:includable id='main' var='this'>
      <div class='header-widget'>
        <b:include cond='data:imagePlacement in {&quot;REPLACE&quot;, &quot;BEFORE_DESCRIPTION&quot;}' name='image'/>
        <b:include cond='data:imagePlacement == &quot;BEHIND&quot;' name='title'/>
      </div>
    </b:includable>
    <b:includable id='image'>
      <a class='main-logo-img' expr:href='data:blog.homepageUrl'>
        <img expr:alt='data:blog.title.escaped' expr:data-height='data:height' expr:data-width='data:width' expr:src='data:image'/>
        <b:if cond='data:view.isHomepage'><b:if cond='data:widget.sectionId == &quot;main-logo&quot;'><h1 id='h1-tag'><data:title/></h1></b:if></b:if>
      </a>
    </b:includable>
    <b:includable id='title'>
      <h1 class='blog-title'>
        <b:tag expr:href='data:blog.homepageUrl' name='a'>
          <data:title/>
        </b:tag>
      </h1>
    </b:includable>
  </b:defaultmarkup>
  <b:defaultmarkup type='PopularPosts'>
    <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <div class='widget-content'>
        <b:loop index='i' values='data:posts' var='post'>
            <b:include data='post' name='content'/>
        </b:loop>
      </div>
    </b:includable>
    <b:includable id='content' var='post'>
      <b:include data='post' name='defaultPost'/>
    </b:includable>
    <b:includable id='defaultPost' var='post'>
      <article class='popular-post post'>
        <b:class expr:name='&quot;item-&quot;+data:i'/>
        <b:if cond='data:post.featuredImage'>
          <b:if cond='data:post.featuredImage.isYouTube'>
            <a class='entry-image-link' expr:href='data:post.url'>
              <span class='entry-thumb' expr:data-image='data:post.featuredImage'/>
            </a>
            <b:else/>
            <a class='entry-image-link' expr:href='data:post.url'>
              <span class='entry-thumb' expr:data-image='resizeImage(data:post.featuredImage, 72, &quot;1:1&quot;)'/>
            </a>
          </b:if>
          <b:else/>
          <a class='entry-image-link' expr:href='data:post.url'>
            <span class='entry-thumb' data-image='https://4.bp.blogspot.com/-eALXtf-Ljts/WrQYAbzcPUI/AAAAAAAABjY/vptx-N2H46oFbiCqbSe2JgVSlHhyl0MwQCK4BGAYYCw/s72-c/nth-ify.png'/>
          </a>
        </b:if>
        <div class='entry-header'>
          <h2 class='entry-title'>
            <a expr:href='data:post.url'><data:post.title/></a>
          </h2>
          <div class='entry-meta'>
            <span class='entry-time'><time class='published' expr:datetime='data:post.date.iso8601'><data:post.date/></time></span>
          </div>
        </div>
      </article>
    </b:includable>
  </b:defaultmarkup>
  <b:defaultmarkup type='FeaturedPost'>
    <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <div class='widget-content'>
        <b:loop values='data:posts' var='post'>
          <b:include data='post' name='content'/>
        </b:loop>
      </div>
    </b:includable>
    <b:includable id='content' var='post'>
      <article class='post'>
        <b:if cond='data:post.featuredImage'>
          <b:if cond='data:post.featuredImage.isYouTube'>
            <a class='entry-image-link' expr:href='data:post.url'>
              <span class='entry-thumb' expr:data-image='data:post.featuredImage'/>
            </a>
            <b:else/>
            <a class='entry-image-link' expr:href='data:post.url'>
              <span class='entry-thumb' expr:data-image='resizeImage(data:post.featuredImage, 72, &quot;1:1&quot;)'/>
            </a>
          </b:if>
          <b:else/>
          <a class='entry-image-link' expr:href='data:post.url'>
            <span class='entry-thumb' data-image='https://4.bp.blogspot.com/-eALXtf-Ljts/WrQYAbzcPUI/AAAAAAAABjY/vptx-N2H46oFbiCqbSe2JgVSlHhyl0MwQCK4BGAYYCw/s72-c/nth-ify.png'/>
          </a>
        </b:if>
        <div class='entry-header'>
          <h2 class='entry-title'>
            <a expr:href='data:post.url'><data:post.title/></a>
          </h2>
          <div class='entry-meta'>
            <span class='entry-author'><b:if cond='data:widgets.Blog.first.allBylineItems.author.label != &quot;&quot;'><em><data:widgets.Blog.first.allBylineItems.author.label/></em></b:if><span class='by'><data:post.author.name/></span></span><span class='entry-time'><b:if cond='data:widgets.Blog.first.allBylineItems.timestamp.label != &quot;&quot;'><em><data:widgets.Blog.first.allBylineItems.timestamp.label/></em></b:if><time class='published' expr:datetime='data:post.date.iso8601'><data:post.date/></time></span>
          </div>
        </div>
      </article>
     <span class='entry-category'><data:post.labels.first.name/></span>
    </b:includable>
  </b:defaultmarkup>
  <b:defaultmarkup type='ContactForm'>
    <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <b:include name='content'/>
    </b:includable>
    <b:includable id='content'>
      <div class='widget-content contact-form-widget'>
        <div class='form'>
          <form name='contact-form'>
            <input class='contact-form-name' expr:id='data:widget.instanceId + &quot;_contact-form-name&quot;' expr:placeholder='data:contactFormNameMsg' name='name' size='30' type='text' value=''/>
            <input class='contact-form-email' expr:id='data:widget.instanceId + &quot;_contact-form-email&quot;' expr:placeholder='data:contactFormEmailMsg + &quot;*&quot;' name='email' size='30' type='text' value=''/>
            <textarea class='contact-form-email-message' cols='25' expr:id='data:widget.instanceId + &quot;_contact-form-email-message&quot;' expr:placeholder='data:contactFormMessageMsg + &quot;*&quot;' name='email-message' rows='5'/>
            <input class='contact-form-button contact-form-button-submit' expr:id='data:widget.instanceId + &quot;_contact-form-submit&quot;' expr:value='data:contactFormSendMsg' type='button'/>
            <p class='contact-form-error-message' expr:id='data:widget.instanceId + &quot;_contact-form-error-message&quot;'/>
            <p class='contact-form-success-message' expr:id='data:widget.instanceId + &quot;_contact-form-success-message&quot;'/>
          </form>
        </div>
      </div>
    </b:includable>       
  </b:defaultmarkup>
  <b:defaultmarkup type='Label'>
    <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <b:include name='content'/>
    </b:includable>
    <b:includable id='content'>
      <div class='widget-content'>
        <b:class expr:name='data:this.display + &quot;-label&quot;'/>
        <b:include cond='data:this.display == &quot;list&quot;' name='list'/>
        <b:include cond='data:this.display == &quot;cloud&quot;' name='cloud'/>
      </div>
    </b:includable>
    <b:includable id='list'>
      <ul>
        <b:loop values='data:labels' var='label'>
          <li>
            <a class='label-name' expr:href='data:label.url'>
              <data:label.name/><b:if cond='data:this.showFreqNumbers'><span class='label-count'>(<data:label.count/>)</span></b:if>
            </a>
          </li>
        </b:loop>
      </ul>
    </b:includable>
    <b:includable id='cloud'>
      <ul>
        <b:loop values='data:labels' var='label'>
          <li>
            <a class='label-name' expr:href='data:label.url'>
              <data:label.name/>
            </a>
          </li>
        </b:loop>
      </ul>
    </b:includable>
  </b:defaultmarkup>
  <b:defaultmarkup type='FollowByEmail'>
    <b:includable id='main' var='this'>
      <b:include name='content'/>
    </b:includable>
    <b:includable id='content'>
      <div class='widget-content'>
        <div class='widget-content-inner'>
          <div class='follow-by-email-content'>
            <h3 class='follow-by-email-title'>
              <data:title/>
            </h3>
            <p class='follow-by-email-text excerpt'><b:include data='{ message: &quot;followByEmailText&quot; }' name='translate'/></p>
            <div class='follow-by-email-inner'>
              <form action='https://feedburner.google.com/fb/a/mailverify' expr:onsubmit='&quot;window.open(\&quot;https://feedburner.google.com/fb/a/mailverify?uri=&quot; + data:feedPath + &quot;\&quot;, \&quot;popupwindow\&quot;, \&quot;scrollbars=yes,width=550,height=520\&quot;); return true&quot;' method='post' target='popupwindow'>
                <input autocomplete='off' class='follow-by-email-address' expr:placeholder='data:messages.emailAddress' name='email' type='email'/>
                <input class='follow-by-email-submit' expr:value='data:messages.subscribe' type='submit'/>
                <input expr:value='data:feedPath' name='uri' type='hidden'/>
                <input name='loc' type='hidden' value='en_US'/>
              </form>
            </div>
          </div>
        </div>
      </div>
    </b:includable>
  </b:defaultmarkup> 
  <b:defaultmarkup type='Image'>
    <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <b:include name='content'/>
    </b:includable>
    <b:includable id='content'>
      <div class='widget-content'>
        <div class='custom-image'>
          <b:tag cond='data:link' expr:href='data:link' name='a'>
            <img expr:alt='data:blog.title' expr:id='data:widget.instanceId + &quot;_img&quot;' expr:src='data:sourceUrl'/>
          </b:tag>
        </div>
        <b:if cond='data:caption'>
          <span class='image-caption excerpt'><data:caption/></span>
        </b:if>
      </div>
    </b:includable>
  </b:defaultmarkup> 
  <b:defaultmarkup type='BlogArchive'>
    <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <b:include name='content'/>
    </b:includable>
    <b:includable id='content'>
      <div class='widget-content'>
        <b:class name='archive-list'/>
        <b:include cond='data:this.style in {&quot;FLAT&quot;, &quot;MENU&quot;, &quot;HIERARCHY&quot;}' name='flat'/>
      </div>
    </b:includable>
    <b:includable id='flat'>
      <ul>
        <b:loop values='data:data' var='i'>
          <li>
            <a class='archive-name' expr:href='data:i.url'>
              <data:i.name/><span class='archive-count'>(<data:i.post-count/>)</span>
            </a>
          </li>
        </b:loop>
      </ul>
    </b:includable>
  </b:defaultmarkup>
  <b:defaultmarkup type='BlogSearch'>
    <b:includable id='main'>
      <b:include name='widget-title'/>
      <b:include name='content'/>
    </b:includable>
    <b:includable id='content'>
      <div class='widget-content' role='search'>
        <b:include name='searchForm'/>
      </div>
    </b:includable>
    <b:includable id='searchForm'>
      <form class='search-form' expr:action='data:blog.searchUrl'>
        <b:attr cond='not data:view.isPreview' name='target' value='_top'/>
        <b:include name='urlParamsAsFormInput'/>
        <input autocomplete='off' class='search-input' expr:aria-label='data:messages.searchThisBlog' expr:placeholder='data:messages.searchThisBlog' expr:value='data:view.isSearch ? data:view.search.query.escaped : &quot;&quot;' name='q'/>
        <b:include name='searchSubmit'/>
      </form>
    </b:includable>
    <b:includable id='searchSubmit'>
      <input class='search-action' expr:value='data:messages.search.escaped' type='submit'/>
    </b:includable>
  </b:defaultmarkup>
  <b:defaultmarkup type='Profile'>
    <b:includable id='userProfileImage'>
      <a expr:href='data:userUrl' rel='nofollow' target='_blank'>
        <b:include name='profileImage'/>
      </a>
    </b:includable>
    <b:includable id='teamProfileLink'>
      <a class='profile-link g-profile' expr:href='data:userUrl' rel='nofollow' target='_blank'>
        <b:include name='profileImage'/>
        <span class='profile-name'><data:display-name/></span>
      </a>
    </b:includable>
    <b:includable id='userProfileLink'>
      <a class='profile-link g-profile' expr:href='data:userUrl' rel='author nofollow' target='_blank'>
        <data:displayname/>
      </a>
    </b:includable>
    <b:includable id='viewProfileLink'>
      <a class='profile-link' expr:href='data:userUrl' rel='author nofollow' target='_blank'>
        <data:messages.viewMyCompleteProfile/>
      </a>
    </b:includable>
  </b:defaultmarkup>
</b:defaultmarkups>

<b:if cond='data:widgets.AdSense.first or data:blog.adsenseClientId'>
  <!-- Google AdSense -->
  <script async='async' src='//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js'/>
</b:if>

<!-- Google Analytics -->
<b:include data='blog' name='google-analytics'/>

</head>

<body expr:class='data:blog.pageType'>
  <b:class cond='data:view.isHomepage' name='home'/>
  <b:class cond='data:view.isPage' name='item'/>
  <b:class cond='data:view.isArchive' name='index'/>
  <b:class cond='data:view.isError' name='error404'/>
  <b:class cond='data:skin.vars.main_font_family == &quot;Open Sans&quot;' name='semibold font-size1 open-sans'/>
  <b:class cond='data:skin.vars.main_font_family == &quot;Roboto&quot;' name='medium roboto'/>
  <b:class cond='data:skin.vars.main_font_family == &quot;Oswald&quot;' name='normal more1 oswald'/>
  <b:class cond='data:skin.vars.main_font_family == &quot;Montserrat&quot;' name='semibold font-size1 montserrat'/>
  <b:class cond='data:skin.vars.main_font_family == &quot;Playfair Display&quot;' name='semibold playfair-display'/>
  <b:class cond='data:skin.vars.main_font_family == &quot;Lora&quot;' name='semibold more1 font-size1 lora'/>
  <b:class cond='data:skin.vars.main_font_family == &quot;Merriweather&quot;' name='semibold more1 font-size1 merriweather'/>
  <b:class cond='data:skin.vars.main_font_family == &quot;Josefin Sans&quot;' name='semibold josefin-sans'/>
  <b:class cond='data:skin.vars.main_font_family == &quot;Josefin Slab&quot;' name='semibold josefin-slab'/>
  <b:class cond='data:skin.vars.main_font_family == &quot;PT Sans&quot;' name='semibold pt-sans'/>

<!-- Theme Options -->
  <div class='theme-options' style='display:none'>
    <b:section class='ify-panel' id='ify-panel' maxwidgets='3' name='Advanced Options' showaddelement='no'>
      <b:widget id='HTML150' locked='true' title='Facebook SDK' type='HTML' version='2' visible='true'>
        <b:widget-settings>
          <b:widget-setting name='content'/>
        </b:widget-settings>
        <b:includable id='main'>
          <b:include name='content'/>
        </b:includable>
        <b:includable id='content'>
          <div class='widget-content'>
            <data:content/>
          </div>
        </b:includable>
      </b:widget>
      <b:widget id='HTML151' locked='true' title='Boxed Version' type='HTML' version='2' visible='true'>
        <b:widget-settings>
          <b:widget-setting name='content'/>
        </b:widget-settings>
        <b:includable id='main'>
          <b:include name='content'/>
        </b:includable>
        <b:includable id='content'>
          <b:if cond='data:content != &quot;&quot;'>
            <b:if cond='data:content == &quot;true&quot;'>
              &lt;style type=&#39;text/css&#39;&gt;
                  #outer-wrapper{max-width:calc(<data:skin.vars.row_width/> + 70px)}
              &lt;/style&gt;
            </b:if>
          </b:if>
        </b:includable>
      </b:widget>
      <b:widget id='LinkList151' locked='true' title='Default Variables' type='LinkList' version='2' visible='true'>
        <b:includable id='main'>
          <b:include name='content'/>
        </b:includable>
        <b:includable id='content'>
          &lt;script defer=&#39;defer&#39; type=&#39;text/javascript&#39;&gt;
          //&lt;![CDATA[
          <b:loop values='data:links' var='link'>
            <b:if cond='data:link.name == &quot;monthFormat&quot;'>
              var monthFormat = [<data:link.target/>];
            </b:if>
            <b:if cond='data:link.name == &quot;fixedMenu&quot;'>
              var fixedMenu = <data:link.target/>;
            </b:if>
            <b:if cond='data:link.name == &quot;fixedSidebar&quot;'>
              var fixedSidebar = <data:link.target/>;
            </b:if>
            <b:if cond='data:link.name == &quot;relatedPostsNum&quot;'>
              var relatedPostsNum = <data:link.target/>;
            </b:if>
            <b:if cond='data:link.name == &quot;showMoreText&quot;'>
              var showMoreText = &quot;<data:link.target/>&quot;;
            </b:if>
            <b:if cond='data:link.name == &quot;followByEmailText&quot;'>
              var followByEmailText = &quot;<data:link.target/>&quot;;
            </b:if>
            <b:if cond='data:link.name == &quot;commentsSystem&quot;'>
              var commentsSystem = &quot;<data:link.target/>&quot;;
            </b:if>
            <b:if cond='data:link.name == &quot;disqusShortname&quot;'>
              var disqusShortname = &quot;<data:link.target/>&quot;;
            </b:if>
          </b:loop>
          //]]&gt;
          &lt;/script&gt;
        </b:includable>
      </b:widget>
    </b:section>
  </div>

<!-- Outer Wrapper -->
<div id='outer-wrapper'>

  <!-- Header Wrapper -->
  <header id='header-wrapper'>
    <!-- Navbar -->
    <div class='navbar-wrap'>
      <div class='navbar'>
        <div class='container row-x1'>

          <span class='show-mobile-menu'/>

          <div class='main-logo-wrap'>
            <b:section class='main-logo' id='main-logo' maxwidgets='1' name='Main Logo' showaddelement='no'>
              <b:widget id='Header1' locked='true' title='Filmex 2024 - Os Melhores Filmes E Séries Você Só Encontra Aqui! (Cabeçalho)' type='Header' version='2' visible='true'>
                <b:widget-settings>
                  <b:widget-setting name='displayUrl'>https://blogger.googleusercontent.com/img/a/AVvXsEirkwqyyI9R91fh4Yif2jigVxDbJsjU3PmPwE66VAUz4M42tNmBNIWWHNV8m0PyER7U2_JfQeCGoo2bn-8TAWgEDhMpJ3Us7F6k_ZaPbP8OVGedy6Uy536X6YzQeXop63VVDhw3g3u2kA1r_NZmWTaT_bwHKhA_bzx1D6NimehWEPACyC2iH6qC22O97Ize=s647</b:widget-setting>
                  <b:widget-setting name='displayHeight'>121</b:widget-setting>
                  <b:widget-setting name='sectionWidth'>150</b:widget-setting>
                  <b:widget-setting name='useImage'>true</b:widget-setting>
                  <b:widget-setting name='shrinkToFit'>false</b:widget-setting>
                  <b:widget-setting name='imagePlacement'>REPLACE</b:widget-setting>
                  <b:widget-setting name='displayWidth'>647</b:widget-setting>
                </b:widget-settings>
                <b:includable id='main' var='this'>
                  <div class='header-widget'>
                    <b:include cond='data:imagePlacement in {&quot;REPLACE&quot;, &quot;BEFORE_DESCRIPTION&quot;}' name='image'/>
                    <b:include cond='data:imagePlacement == &quot;BEHIND&quot;' name='title'/>
                  </div>
                </b:includable>
                <b:includable id='behindImageStyle'>
                  <b:if cond='data:sourceUrl'>
                    <b:include cond='data:this.image' data='{                    image: data:this.image,                    selector: &quot;.header-widget&quot;                  }' name='responsiveImageStyle'/>
                    <style type='text/css'>
                      .header-widget {
                        background-position: <data:blog.locale.languageAlignment/>;
                        background-repeat: no-repeat;
                      }
                    </style>
                  </b:if>
                </b:includable>
                <b:includable id='description'>
                  <p>
                    <data:this.description/>
                  </p>
                </b:includable>
                <b:includable id='image'>
                  <a class='main-logo-img' expr:href='data:blog.homepageUrl'>
                    <img expr:alt='data:blog.title.escaped' expr:data-height='data:height' expr:data-width='data:width' expr:src='data:image'/>
                    <b:if cond='data:view.isHomepage'><b:if cond='data:widget.sectionId == &quot;main-logo&quot;'><h1 id='h1-tag'><data:title/></h1></b:if></b:if>
                  </a>
                </b:includable>
                <b:includable id='title'>
                  <h1 class='blog-title'>
                    <b:tag expr:href='data:blog.homepageUrl' name='a'>
                      <data:title/>
                    </b:tag>
                  </h1>
                </b:includable>
              </b:widget>
            </b:section>
          </div>

          <nav class='main-menu-wrap'>
            <b:section class='galaxymag-main-menu' id='galaxymag-main-menu' maxwidgets='1' name='Main Menu' showaddelement='no'>
              <b:widget id='LinkList155' locked='true' title='Main Menu' type='LinkList' version='2' visible='true'>
                <b:widget-settings>
                  <b:widget-setting name='text-10'>Séries</b:widget-setting>
                  <b:widget-setting name='sorting'>NONE</b:widget-setting>
                  <b:widget-setting name='link-1'>#</b:widget-setting>
                  <b:widget-setting name='link-2'>https://www.cinelivre.ga/search/label/Ação</b:widget-setting>
                  <b:widget-setting name='link-12'>https://filmex2024.blogspot.com/p/player-nao-funcionando.html</b:widget-setting>
                  <b:widget-setting name='link-0'>/</b:widget-setting>
                  <b:widget-setting name='link-11'>https://filmex2024.blogspot.com/p/galera-sejam-bem-vindos-pagina-de.html</b:widget-setting>
                  <b:widget-setting name='link-10'>/p/shortcodes.html</b:widget-setting>
                  <b:widget-setting name='text-9'>Filmes</b:widget-setting>
                  <b:widget-setting name='link-9'>https://www.cinelivre.ga/search/label/Filmes</b:widget-setting>
                  <b:widget-setting name='text-8'>_Musica</b:widget-setting>
                  <b:widget-setting name='link-7'>https://www.cinelivre.ga/search/label/Romance</b:widget-setting>
                  <b:widget-setting name='link-8'>https://www.cinelivre.ga/search/label/Musica</b:widget-setting>
                  <b:widget-setting name='link-5'>https://www.cinelivre.ga/search/label/Comédia</b:widget-setting>
                  <b:widget-setting name='link-6'>https://www.cinelivre.ga/search/label/Drama</b:widget-setting>
                  <b:widget-setting name='link-3'>https://www.cinelivre.ga/search/label/Animação</b:widget-setting>
                  <b:widget-setting name='link-4'>https://www.cinelivre.ga/search/label/Aventura</b:widget-setting>
                  <b:widget-setting name='text-1'>Categorias</b:widget-setting>
                  <b:widget-setting name='text-0'>Início</b:widget-setting>
                  <b:widget-setting name='text-3'>_Animação</b:widget-setting>
                  <b:widget-setting name='text-2'>_Ação</b:widget-setting>
                  <b:widget-setting name='text-5'>_Comédia</b:widget-setting>
                  <b:widget-setting name='text-4'>_Aventura</b:widget-setting>
                  <b:widget-setting name='text-7'>_Romance</b:widget-setting>
                  <b:widget-setting name='text-6'>_Drama</b:widget-setting>
                  <b:widget-setting name='text-11'>Pedidos</b:widget-setting>
                  <b:widget-setting name='text-12'>Player Não Funcionando?</b:widget-setting>
                </b:widget-settings>
                <b:includable id='main'>
                  <b:include name='content'/>
                </b:includable>
                <b:includable id='content'>
                  <ul id='galaxymag-main-menu-nav' role='menubar'>
                    <b:loop values='data:links' var='link'>
                      <li><a expr:href='data:link.target' role='menuitem'><data:link.name/></a></li>
                    </b:loop>
                  </ul>
                </b:includable>
              </b:widget>
            </b:section>
          </nav>

          <span class='show-search'/>
          <div id='nav-search'>
            <form class='search-form' expr:action='data:blog.searchUrl' role='search'>
              <input autocomplete='off' class='search-input' expr:placeholder='data:messages.searchThisBlog' expr:value='data:view.isSearch ? data:view.search.query.escaped : &quot;&quot;' name='q' type='search'/>
              <span class='hide-search'/>
            </form>
          </div>

        </div>
      </div>    
    </div>
    <b:if cond='data:view.isHomepage'>
      <div class='clearfix'/>
      <!-- Breaking News -->
      <div id='breaking-wrap'>
        <b:section class='breaking-sec container row-x1' id='breaking-sec' maxwidgets='1' name='Breaking News' showaddelement='yes'>
          <b:widget id='HTML2' locked='false' title='more movies' type='HTML' visible='false'>
            <b:widget-settings>
              <b:widget-setting name='content'><![CDATA[[getBreaking results="4" label="US"]]]></b:widget-setting>
            </b:widget-settings>
            <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
          </b:widget>
        </b:section>
      </div>
    </b:if>
  </header>

  <div class='clearfix'/>

  <b:if cond='data:view.isHomepage'>
    <!-- Header Ads Wrapper -->
    <div class='header-ads-wrap'>
      <b:section class='header-ad container row-x1' id='header-ads' maxwidgets='1' name='Header Ads' showaddelement='yes'/>
    </div>
    <div class='clearfix'/>
  </b:if>

  <b:if cond='data:view.isHomepage'> 
    <!-- Featured Wrapper -->
    <div id='featured-wrapper'>
      <b:section class='featured-sec container row-x1' id='featured-sec' maxwidgets='1' name='Main Featured' showaddelement='yes'/>
    </div>
    <div class='clearfix'/>
  </b:if>

  <!-- Content Wrapper -->
  <div class='row-x1' id='content-wrapper'>
    <div class='container'>

      <!-- Main Wrapper -->
      <main id='main-wrapper'>
        <b:if cond='data:view.isHomepage'> 
          <!-- Block Posts 01 -->
          <b:section class='block-posts' id='block-posts-1' name='Block Posts 1' showaddelement='yes'>
            <b:widget id='HTML25' locked='false' title='Lançamentos' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Lançamentos" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML26' locked='false' title='Filmes' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Filmes" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML32' locked='false' title='Filmes De Animes' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Filmes De Animes" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML30' locked='false' title='Filmes 2021' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Filmes 2021" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML31' locked='false' title='Filmes 2022' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Filmes 2022" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML28' locked='false' title='Filmes Dublados' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Filmes Dublados" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML29' locked='false' title='Filmes Legendados' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Filmes Legendados" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML27' locked='false' title='Séries' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Séries" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML33' locked='false' title='Séries De Animes' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'/>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML4' locked='false' title='Ação' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Ação" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML6' locked='false' title='Aventura' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Aventura" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML13' locked='false' title='Animação' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Animação" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML12' locked='false' title='Biografia' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Biografia" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML5' locked='false' title='Comédia' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Comédia" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML1' locked='false' title='Crime' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Crime" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML34' locked='false' title='Desenhos' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Desenhos" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML16' locked='false' title='Documentário' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Documentário" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML11' locked='false' title='Drama' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Drama" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML17' locked='false' title='Família' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Família" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML14' locked='false' title='Ficção Científica' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Ficção Científica" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML18' locked='false' title='Faroeste' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Faroeste" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML19' locked='false' title='Guerra' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Guerra" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML15' locked='false' title='História' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="História" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML20' locked='false' title='Mistério' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Mistério" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML21' locked='false' title='Nacional' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'/>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML36' locked='false' title='Policial' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Policial" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML9' locked='false' title='Romance' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Romance" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML22' locked='false' title='Suspense' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Suspense" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML23' locked='false' title='Terror' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Terror" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML24' locked='false' title='Thriller' type='HTML' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="Thriller" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='BlogSearch1' locked='false' title='Pesquisar este blog' type='BlogSearch' visible='true'>
              <b:includable id='main'>
      <b:include name='widget-title'/>
      <b:include name='content'/>
    </b:includable>
              <b:includable id='content'>
      <div class='widget-content' role='search'>
        <b:include name='searchForm'/>
      </div>
    </b:includable>
              <b:includable id='searchForm'>
      <form class='search-form' expr:action='data:blog.searchUrl'>
        <b:attr cond='not data:view.isPreview' name='target' value='_top'/>
        <b:include name='urlParamsAsFormInput'/>
        <input autocomplete='off' class='search-input' expr:aria-label='data:messages.searchThisBlog' expr:placeholder='data:messages.searchThisBlog' expr:value='data:view.isSearch ? data:view.search.query.escaped : &quot;&quot;' name='q'/>
        <b:include name='searchSubmit'/>
      </form>
    </b:includable>
              <b:includable id='searchSubmit'>
      <input class='search-action' expr:value='data:messages.search.escaped' type='submit'/>
    </b:includable>
            </b:widget>
            <b:widget id='Attribution1' locked='false' title='' type='Attribution' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='copyright'/>
              </b:widget-settings>
              <b:includable id='main' var='this'>
  <div class='widget-content'>
    <div class='blogger'>
      <a expr:href='data:bloggerUrl' rel='nofollow'>
        <b:include name='flatBloggerIcon'/>
        <b:message name='messages.poweredByBlogger'/>
      </a>
    </div>

    <b:if cond='data:imageAuthor'>
      <div class='image-attribution'>
        <b:if cond='data:imageAuthor.url'>
          <b:message name='messages.templateImagesByLink'>
            <b:param expr:value='data:imageAuthor.url'/>
            <b:param expr:value='data:imageAuthor.name'/>
          </b:message>
        <b:else/>
          <b:message name='messages.templateImagesBy'>
            <b:param expr:value='data:imageAuthor.name'/>
          </b:message>
        </b:if>
      </div>
    </b:if>

    <b:if cond='data:copyright != &quot;&quot;'>
      <div class='copyright'><data:copyright/></div>
    </b:if>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='BlogArchive1' locked='false' title='' type='BlogArchive' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='showStyle'>FLAT</b:widget-setting>
                <b:widget-setting name='yearPattern'>yyyy</b:widget-setting>
                <b:widget-setting name='showWeekEnd'>true</b:widget-setting>
                <b:widget-setting name='monthPattern'>MMMM yyyy</b:widget-setting>
                <b:widget-setting name='dayPattern'>MMM dd</b:widget-setting>
                <b:widget-setting name='weekPattern'>MM/dd</b:widget-setting>
                <b:widget-setting name='chronological'>false</b:widget-setting>
                <b:widget-setting name='showPosts'>true</b:widget-setting>
                <b:widget-setting name='frequency'>MONTHLY</b:widget-setting>
              </b:widget-settings>
              <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <b:include name='content'/>
    </b:includable>
              <b:includable id='content'>
      <div class='widget-content'>
        <b:class name='archive-list'/>
        <b:include cond='data:this.style in {&quot;FLAT&quot;, &quot;MENU&quot;, &quot;HIERARCHY&quot;}' name='flat'/>
      </div>
    </b:includable>
              <b:includable id='flat'>
      <ul>
        <b:loop values='data:data' var='i'>
          <li>
            <a class='archive-name' expr:href='data:i.url'>
              <data:i.name/><span class='archive-count'>(<data:i.post-count/>)</span>
            </a>
          </li>
        </b:loop>
      </ul>
    </b:includable>
              <b:includable id='hierarchy'>
  <b:include data='data' name='interval'/>
</b:includable>
              <b:includable id='interval' var='intervals'>
  <ul class='hierarchy'>
    <b:loop values='data:intervals' var='interval'>
      <li class='archivedate'>
        <div class='hierarchy-title'>
          <a class='post-count-link' expr:href='data:interval.url'>
            <data:interval.name/>
            <span class='post-count'><data:interval.post-count/></span>
          </a>
        </div>
        <div class='hierarchy-content'>
          <b:include cond='data:interval.data' data='interval.data' name='interval'/>
          <b:include cond='data:interval.posts' data='interval.posts' name='posts'/>
        </div>
      </li>
    </b:loop>
  </ul>
</b:includable>
              <b:includable id='posts' var='posts'>
  <ul class='posts hierarchy'>
    <b:loop values='data:posts' var='post'>
      <li>
        <a expr:href='data:post.url'><data:post.title/></a>
      </li>
    </b:loop>
  </ul>
</b:includable>
            </b:widget>
            <b:widget id='ReportAbuse1' locked='false' title='' type='ReportAbuse' visible='true'>
              <b:includable id='main'>
  <b:include name='reportAbuse'/>
</b:includable>
            </b:widget>
            <b:widget cond='!data:view.isPost' id='PageList1' locked='false' title='' type='PageList' visible='false'>
              <b:widget-settings>
                <b:widget-setting name='pageListJson'><![CDATA[{"home":{"href":"http://filmex2024.blogspot.com/","position":0,"title":"Página inicial"}}]]></b:widget-setting>
                <b:widget-setting name='homeTitle'>Página inicial</b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <b:include name='content'/>
</b:includable>
              <b:includable id='content'>
  <div class='widget-content'>
    <b:include name='pageList'/>
  </div>
</b:includable>
              <b:includable id='overflowButton'>
  <b:include name='verticalMoreIcon'/>
</b:includable>
              <b:includable id='overflowablePageList'>
  <div class='overflowable-container'>
    <div class='overflowable-contents'>
      <div class='container'>
        <b:with value='true' var='overflow'>
        <b:with value='&quot;tabs&quot;' var='pageListClass'>
          <b:include name='pageList'/>
        </b:with>
        </b:with>
      </div>
    </div>
    <div class='overflow-button hidden'>
      <b:include name='overflowButton'/>
    </div>
  </div>
</b:includable>
              <b:includable id='pageLink'>
  <li>
    <b:class cond='data:overflow' name='overflowable-item'/>
    <b:class cond='data:link.isCurrentPage' name='selected'/>

    <a expr:href='data:link.href'><data:link.title/></a>
  </li>
</b:includable>
              <b:includable id='pageList'>
  <ul>
    <b:class cond='data:pageListClass' expr:name='data:pageListClass'/>
    <b:loop values='data:links' var='link'>
      <b:include name='pageLink'/>
    </b:loop>
  </ul>
</b:includable>
            </b:widget>
            <b:widget id='Profile1' locked='false' title='Quem sou eu' type='Profile' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='showaboutme'>true</b:widget-setting>
                <b:widget-setting name='showlocation'>false</b:widget-setting>
              </b:widget-settings>
              <b:includable id='main' var='this'>
  <b:include name='widget-title'/>
  <b:include name='content'/>
</b:includable>
              <b:includable id='authorProfileImage'>
  <img class='profile-img' expr:alt='data:messages.myPhoto' expr:height='data:authorPhoto.height' expr:src='data:authorPhoto.image' expr:width='data:authorPhoto.width'/>
</b:includable>
              <b:includable id='content'>
  <b:if cond='data:team'>
    <div class='widget-content team'>
      <b:include name='teamProfile'/>
    </div>
  <b:else/>
    <div class='widget-content individual'>
      <b:include name='userProfile'/>
    </div>
  </b:if>
</b:includable>
              <b:includable id='defaultProfileImage'>
  <div class='default-avatar'/>
</b:includable>
              <b:includable id='profileImage'>
  <b:if cond='data:authorPhoto.image'>
    <b:include name='authorProfileImage'/>
  <b:else/>
    <b:include name='defaultProfileImage'/>
  </b:if>
</b:includable>
              <b:includable id='teamProfile'>
  <ul>
    <b:loop values='data:authors' var='author'>
      <li>
        <div class='team-member'>
          <b:include data='author' name='teamProfileLink'/>
        </div>
      </li>
    </b:loop>
  </ul>
</b:includable>
              <b:includable id='teamProfileLink'>
      <a class='profile-link g-profile' expr:href='data:userUrl' rel='nofollow' target='_blank'>
        <b:include name='profileImage'/>
        <span class='profile-name'><data:display-name/></span>
      </a>
    </b:includable>
              <b:includable id='userLocation'>
  <dd class='profile-data location'><data:location/></dd>
</b:includable>
              <b:includable id='userProfile'>
  <b:include name='userProfileImage'/>
  <b:include name='userProfileInfo'/>
</b:includable>
              <b:includable id='userProfileData'>
  <dt class='profile-data'>
    <a class='profile-link g-profile' expr:href='data:userUrl' rel='author nofollow'>
      <data:displayname/>
    </a>
  </dt>
</b:includable>
              <b:includable id='userProfileImage'>
      <a expr:href='data:userUrl' rel='nofollow' target='_blank'>
        <b:include name='profileImage'/>
      </a>
    </b:includable>
              <b:includable id='userProfileInfo'>
  <div class='profile-info'>
    <dl class='profile-datablock'>
      <b:class cond='data:showlocation and data:location != &quot;&quot;' name='has-location'/>

      <b:include name='userProfileData'/>
      <b:include cond='data:showlocation and data:location != &quot;&quot;' name='userLocation'/>
      <b:include cond='data:aboutme != &quot;&quot;' name='userProfileText'/>
    </dl>
    <b:include name='viewProfileLink'/>
  </div>
</b:includable>
              <b:includable id='userProfileLink'>
      <a class='profile-link g-profile' expr:href='data:userUrl' rel='author nofollow' target='_blank'>
        <data:displayname/>
      </a>
    </b:includable>
              <b:includable id='userProfileText'>
  <dd class='profile-textblock'>
    <data:aboutme/>
  </dd>
</b:includable>
              <b:includable id='viewProfileLink'>
      <a class='profile-link' expr:href='data:userUrl' rel='author nofollow' target='_blank'>
        <data:messages.viewMyCompleteProfile/>
      </a>
    </b:includable>
            </b:widget>
            <b:widget cond='data:view.isHomepage' id='FeaturedPost1' locked='false' title='' type='FeaturedPost' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='showSnippet'>true</b:widget-setting>
                <b:widget-setting name='showPostTitle'>true</b:widget-setting>
                <b:widget-setting name='showFirstImage'>true</b:widget-setting>
                <b:widget-setting name='useMostRecentPost'>true</b:widget-setting>
              </b:widget-settings>
              <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <div class='widget-content'>
        <b:loop values='data:posts' var='post'>
          <b:include data='post' name='content'/>
        </b:loop>
      </div>
    </b:includable>
              <b:includable id='content' var='post'>
      <article class='post'>
        <b:if cond='data:post.featuredImage'>
          <b:if cond='data:post.featuredImage.isYouTube'>
            <a class='entry-image-link' expr:href='data:post.url'>
              <span class='entry-thumb' expr:data-image='data:post.featuredImage'/>
            </a>
            <b:else/>
            <a class='entry-image-link' expr:href='data:post.url'>
              <span class='entry-thumb' expr:data-image='resizeImage(data:post.featuredImage, 72, &quot;1:1&quot;)'/>
            </a>
          </b:if>
          <b:else/>
          <a class='entry-image-link' expr:href='data:post.url'>
            <span class='entry-thumb' data-image='https://4.bp.blogspot.com/-eALXtf-Ljts/WrQYAbzcPUI/AAAAAAAABjY/vptx-N2H46oFbiCqbSe2JgVSlHhyl0MwQCK4BGAYYCw/s72-c/nth-ify.png'/>
          </a>
        </b:if>
        <div class='entry-header'>
          <h2 class='entry-title'>
            <a expr:href='data:post.url'><data:post.title/></a>
          </h2>
          <div class='entry-meta'>
            <span class='entry-author'><b:if cond='data:widgets.Blog.first.allBylineItems.author.label != &quot;&quot;'><em><data:widgets.Blog.first.allBylineItems.author.label/></em></b:if><span class='by'><data:post.author.name/></span></span><span class='entry-time'><b:if cond='data:widgets.Blog.first.allBylineItems.timestamp.label != &quot;&quot;'><em><data:widgets.Blog.first.allBylineItems.timestamp.label/></em></b:if><time class='published' expr:datetime='data:post.date.iso8601'><data:post.date/></time></span>
          </div>
        </div>
      </article>
     <span class='entry-category'><data:post.labels.first.name/></span>
    </b:includable>
            </b:widget>
          </b:section>
          <div class='clearfix'/>
          <b:section class='home-ad' id='home-ad' maxwidgets='1' name='HOME ADS' showaddelement='yes'/>
          <div class='clearfix'/>
        </b:if>
        <b:section class='main' id='main' maxwidgets='1' name='Main Posts' showaddelement='yes'>
          <b:widget id='Blog1' locked='true' title='Postagens no blog' type='Blog' version='2' visible='true'>
            <b:widget-settings>
              <b:widget-setting name='showDateHeader'>false</b:widget-setting>
              <b:widget-setting name='commentLabel'>Comentários/Comments</b:widget-setting>
              <b:widget-setting name='style.textcolor'>#ffffff</b:widget-setting>
              <b:widget-setting name='showShareButtons'>false</b:widget-setting>
              <b:widget-setting name='authorLabel'>by</b:widget-setting>
              <b:widget-setting name='showCommentLink'>true</b:widget-setting>
              <b:widget-setting name='style.urlcolor'>#ffffff</b:widget-setting>
              <b:widget-setting name='showAuthor'>false</b:widget-setting>
              <b:widget-setting name='style.linkcolor'>#ffffff</b:widget-setting>
              <b:widget-setting name='style.unittype'>TextAndImage</b:widget-setting>
              <b:widget-setting name='style.bgcolor'>#ffffff</b:widget-setting>
              <b:widget-setting name='timestampLabel'/>
              <b:widget-setting name='reactionsLabel'/>
              <b:widget-setting name='showAuthorProfile'>true</b:widget-setting>
              <b:widget-setting name='style.layout'>1x1</b:widget-setting>
              <b:widget-setting name='showLabels'>true</b:widget-setting>
              <b:widget-setting name='showLocation'>false</b:widget-setting>
              <b:widget-setting name='postLabelsLabel'>Categoria</b:widget-setting>
              <b:widget-setting name='showTimestamp'>true</b:widget-setting>
              <b:widget-setting name='postsPerAd'>1</b:widget-setting>
              <b:widget-setting name='showBacklinks'>false</b:widget-setting>
              <b:widget-setting name='style.bordercolor'>#ffffff</b:widget-setting>
              <b:widget-setting name='showInlineAds'>false</b:widget-setting>
              <b:widget-setting name='showReactions'>false</b:widget-setting>
            </b:widget-settings>
            <b:includable id='main' var='this'>
              <b:include name='blogPostsHeadline'/>
              <b:include name='searchMessage'/>
              <div class='blog-posts hfeed container'>
                <b:class cond='data:view.isMultipleItems' name='index-post-wrap'/>
                <b:class cond='data:view.isSingleItem' name='item-post-wrap'/>
                <b:loop index='i' values='data:posts' var='post'>
                  <b:include data='post' name='postCommentsAndAd'/>
                </b:loop>
              </div>
              <b:include cond='data:view.isMultipleItems' name='postPagination'/>
              <b:include name='feedLinks'/>
              <b:include name='jsMessages'/>
            </b:includable>
            <b:includable id='aboutPostAuthor'>
              <b:comment>Disabled.</b:comment>
            </b:includable>
            <b:includable id='addComments'>
              <a expr:href='data:post.commentsUrl' expr:onclick='data:post.commentsUrlOnclick'>
                <b:message name='messages.postAComment'/>
              </a>
            </b:includable>
            <b:includable id='backLinks' var='post'>
              <b:comment>Disabled.</b:comment>
            </b:includable>
            <b:includable id='blogPostsHeadline'>
              <b:if cond='data:view.isHomepage'>
                <b:if cond='data:blog.jumpLinkMessage != &quot;hide&quot;'>
                  <div class='blog-posts-headline title-wrap'>           
                    <h3 class='title custom-title'>FILMES E SÉRIES ADICIONADOS RECENTEMENTE</h3>     
                    <a class='more' href='/search'/>
                  </div>
                  <div class='clearfix'/>
                </b:if>
              </b:if>
            </b:includable>
            <b:includable id='blogThisShare'>
  <b:with value='&quot;window.open(this.href, \&quot;_blank\&quot;, \&quot;height=270,width=475\&quot;); return false;&quot;' var='onclick'>
    <b:include name='platformShare'/>
  </b:with>
</b:includable>
            <b:includable id='bylineByName' var='byline'>
  <b:switch var='data:byline.name'>
  <b:case value='share'/>
    <b:include cond='data:post.shareUrl' name='postShareButtons'/>
  <b:case value='comments'/>
    <b:include cond='data:post.allowComments' name='postCommentsLink'/>
  <b:case value='location'/>
    <b:include cond='data:post.location' name='postLocation'/>
  <b:case value='timestamp'/>
    <b:include cond='not data:view.isPage' name='postTimestamp'/>
  <b:case value='author'/>
    <b:include name='postAuthor'/>
  <b:case value='labels'/>
    <b:include cond='data:post.labels' name='postLabels'/>
  <b:case value='icons'/>
    <b:include cond='data:post.emailPostUrl' name='emailPostIcon'/>
  <b:case value='reactions'/>
    <b:include cond='data:post.reactionsUrl' name='postReactions'/>
  </b:switch>
</b:includable>
            <b:includable id='bylineRegion' var='regionItems'>
  <b:loop values='data:regionItems' var='byline'>
    <b:include data='byline' name='bylineByName'/>
  </b:loop>
</b:includable>
            <b:includable id='commentAuthorAvatar'>
              <div class='avatar-image-container'>
                <img class='author-avatar' expr:src='data:comment.authorAvatarSrc' height='35' width='35'/>
              </div>
            </b:includable>
            <b:includable id='commentDeleteIcon' var='comment'>
              <span expr:class='&quot;item-control &quot; + data:comment.adminClass'>
                <b:if cond='data:showCmtPopup'>
                  <div class='goog-toggle-button'>
                    <div class='goog-inline-block comment-action-icon'/>
                  </div>
                  <b:else/>
                  <a class='comment-delete' expr:href='data:comment.deleteUrl' expr:title='data:messages.deleteComment'>
                    <img src='https://resources.blogblog.com/img/icon_delete13.gif'/>
                  </a>
                </b:if>
              </span>
            </b:includable>
            <b:includable id='commentForm' var='post'>
              <div class='comment-form'>
                <a name='comment-form'/>
                <h4 id='comment-post-message'><data:messages.postAComment/></h4>
                <b:if cond='data:this.messages.blogComment != &quot;&quot;'>
                  <p><data:this.messages.blogComment/></p>
                </b:if>
                <b:include data='post' name='commentFormIframeSrc'/>
                <iframe allowtransparency='allowtransparency' class='blogger-iframe-colorize blogger-comment-from-post' expr:height='data:cmtIframeInitialHeight ?: &quot;90px&quot;' frameborder='0' id='comment-editor' name='comment-editor' src='' width='100%'/>
                <data:post.cmtfpIframe/>
                <script type='text/javascript'>
                  BLOG_CMT_createIframe(&#39;<data:post.appRpcRelayPath/>&#39;);
                </script>
              </div>
            </b:includable>
            <b:includable id='commentFormIframeSrc' var='post'>
              <a expr:href='data:post.commentFormIframeSrc + &quot;&amp;skin=contempo&quot;' id='comment-editor-src'/>
            </b:includable>
            <b:includable id='commentItem' var='comment'>
              <div class='comment' expr:id='&quot;c&quot; + data:comment.id'>
                <b:include cond='data:blog.enabledCommentProfileImages' name='commentAuthorAvatar'/>
                <div class='comment-block'>
                  <div class='comment-author'>
                    <b:if cond='data:comment.authorUrl'>
                      <b:message name='messages.authorSaidWithLink'>
                        <b:param expr:value='data:comment.author' name='authorName'/>
                        <b:param expr:value='data:comment.authorUrl' name='authorUrl'/>
                      </b:message>
                      <b:else/>
                      <b:message name='messages.authorSaid'>
                        <b:param expr:value='data:comment.author' name='authorName'/>
                      </b:message>
                    </b:if>
                  </div>
                  <div expr:class='&quot;comment-body&quot; + (data:comment.isDeleted ? &quot; deleted&quot; : &quot;&quot;)'>
                    <data:comment.body/>
                  </div>
                  <div class='comment-footer'>
                    <span class='comment-timestamp'>
                      <a expr:href='data:comment.url' title='comment permalink'>
                        <data:comment.timestamp/>
                      </a>
                      <b:include data='comment' name='commentDeleteIcon'/>
                    </span>
                  </div>
                </div>
              </div>
            </b:includable>
            <b:includable id='commentList' var='comments'>
              <div id='comments-block'>
                <b:loop values='data:comments' var='comment'>
                  <b:include data='comment' name='commentItem'/>
                </b:loop>
              </div>
            </b:includable>
            <b:includable id='commentPicker' var='post'>
              <b:if cond='data:post.commentSource == 1'>
                <b:include data='post' name='iframeComments'/>
                <b:elseif cond='data:post.showThreadedComments'/>
                <b:include data='post' name='threadedComments'/>
                <b:else/>
                <b:include data='post' name='comments'/>
              </b:if>
            </b:includable>
            <b:includable id='comments' var='post'>
              <section expr:class='&quot;comments&quot; + (data:post.embedCommentForm ? &quot; embed&quot; : &quot;&quot;)' expr:data-num-comments='data:post.numberOfComments' id='comments'>
                <b:class cond='data:post.numberOfComments == &quot;0&quot;' name='no-comments'/>
                <a name='comments'/>
                <b:if cond='data:post.allowComments'>
                  <b:include name='commentsTitle'/>
                  <div expr:id='data:widget.instanceId + &quot;_comments-block-wrapper&quot;'>
                    <b:include cond='data:post.comments' data='post.comments' name='commentList'/>
                  </div>
                  <b:if cond='data:post.commentPagingRequired'>
                    <div class='paging-control-container'>
                      <b:if cond='data:post.hasOlderLinks'>
                        <a expr:class='data:post.oldLinkClass' expr:href='data:post.oldestLinkUrl'>
                          <data:messages.oldest/>
                        </a>
                        <a expr:class='data:post.oldLinkClass' expr:href='data:post.olderLinkUrl'>
                          <data:messages.older/>
                        </a>
                      </b:if>
                      <span class='comment-range-text'>
                        <data:post.commentRangeText/>
                      </span>
                      <b:if cond='data:post.hasNewerLinks'>
                        <a expr:class='data:post.newLinkClass' expr:href='data:post.newerLinkUrl'>
                          <data:messages.newer/>
                        </a>
                        <a expr:class='data:post.newLinkClass' expr:href='data:post.newestLinkUrl'>
                          <data:messages.newest/>
                        </a>
                      </b:if>
                    </div>
                  </b:if>
                  <div class='footer'>
                    <b:if cond='data:post.embedCommentForm'>
                      <b:if cond='data:post.allowNewComments'>
                        <b:include data='post' name='commentForm'/>
                        <b:else/>
                        <data:post.noNewCommentsText/>
                      </b:if>
                      <b:else/>
                      <b:if cond='data:post.allowComments'>
                        <b:include data='post' name='addComments'/>
                      </b:if>
                    </b:if>
                  </div>
                </b:if>
                <b:if cond='data:showCmtPopup'>
                  <div id='comment-popup'>
                    <iframe allowtransparency='allowtransparency' frameborder='0' id='comment-actions' name='comment-actions' scrolling='no'>
                    </iframe>
                  </div>
                </b:if>
              </section>
            </b:includable>
            <b:includable id='commentsLink'>
  <a class='comment-link' expr:href='data:post.commentsUrl' expr:onclick='data:post.commentsUrlOnclick'>
    <b:if cond='data:post.numberOfComments &gt; 0'>
      <b:message name='messages.numberOfComments'>
        <b:param expr:value='data:post.numberOfComments' name='numComments'/>
      </b:message>
    <b:else/>
      <data:messages.postAComment/>
    </b:if>
  </a>
</b:includable>
            <b:includable id='commentsLinkIframe'>
  <!-- G+ comments, no longer available. The includable is retained for backwards-compatibility. -->
</b:includable>
            <b:includable id='commentsTitle'>
              <!-- Post Commments Title -->
              <b:if cond='data:post.numberOfComments == 0'>
                <div class='title-wrap comments-title'><h3 class='title' expr:count='data:post.numberOfComments' expr:message='data:messages.comments'><data:post.numberOfComments/>/<data:allBylineItems.comments.label/><b:class cond='data:this.messages.blogComment != &quot;&quot;' name='has-message'/></h3></div>
                <b:if cond='data:this.messages.blogComment != &quot;&quot;'>
                  <p class='comments-message'><data:this.messages.blogComment/></p>
                </b:if>
                <b:else/>
                <div class='title-wrap comments-title'><h3 class='title' expr:count='data:post.numberOfComments' expr:message='data:messages.comments'><data:post.numberOfComments/>/<data:allBylineItems.comments.label/><b:class cond='data:this.messages.blogComment != &quot;&quot;' name='has-message'/></h3></div>
                <b:if cond='data:this.messages.blogComment != &quot;&quot;'>
                  <p class='comments-message'><data:this.messages.blogComment/></p>
                </b:if>
              </b:if>
            </b:includable>
            <b:includable id='defaultAdUnit'>
  <ins class='adsbygoogle' data-ad-format='auto' expr:data-ad-client='data:adClientId ?: data:blog.adsenseClientId' expr:data-ad-host='data:blog.adsenseHostId' expr:data-analytics-uacct='data:blog.analyticsAccountNumber' expr:style='data:style ?: &quot;display: block;&quot;'/>
  <script>
   (adsbygoogle = window.adsbygoogle || []).push({});
  </script>
</b:includable>
            <b:includable id='emailPostIcon'>
  <span class='byline post-icons'>
    <!-- email post links -->
    <span class='item-action'>
      <a expr:href='data:post.emailPostUrl' expr:title='data:messages.emailPost'>
        <b:include data='{ iconClass: &quot;touch-icon sharing-icon&quot; }' name='emailIcon'/>
      </a>
    </span>
  </span>
</b:includable>
            <b:includable id='facebookShare'>
  <b:with value='&quot;window.open(this.href, \&quot;_blank\&quot;, \&quot;height=430,width=640\&quot;); return false;&quot;' var='onclick'>
    <b:include name='platformShare'/>
  </b:with>
</b:includable>
            <b:includable id='feedLinks'>
              <b:comment>Disabled.</b:comment>
            </b:includable>
            <b:includable id='feedLinksBody' var='links'>
              <b:comment>Disabled.</b:comment>
            </b:includable>
            <b:includable id='footerBylines'>
  <b:if cond='data:widgets.Blog.first.footerBylines'>
    <b:loop index='i' values='data:widgets.Blog.first.footerBylines' var='region'>
      <b:if cond='not data:region.items.empty'>
        <div expr:class='&quot;post-footer-line post-footer-line-&quot; + (data:i + 1)'>
          <b:with value='&quot;footer-&quot; + (data:i + 1)' var='regionName'>
            <b:include data='region.items' name='bylineRegion'/>
          </b:with>
        </div>
      </b:if>
    </b:loop>
  </b:if>
</b:includable>
            <b:includable id='googlePlusShare'>
  <div class='goog-inline-block google-plus-share-container'>
    <g:plusone annotation='inline' expr:href='data:originalUrl.canonical.http' size='medium' source='blogger:blog:plusone'/>
  </div>
</b:includable>
            <b:includable id='headerByline' var='post'>
              <!-- Post Header Meta -->
              <div class='entry-meta'>
                <b:include data='post' name='postAuthor'/>
                <b:include data='post' name='postTimestamp'/>
                <b:include cond='data:view.isSingleItem and data:post.allowComments' data='post' name='postReplyCount'/>
              </div>
            </b:includable>
            <b:includable id='homePageLink'>
              <b:comment>Disabled.</b:comment>
            </b:includable>
            <b:includable id='iframeComments' var='post'>
              <b:if cond='data:post.allowIframeComments'>
                <script expr:src='data:post.iframeCommentSrc' type='text/javascript'/>
                <div class='cmt_iframe_holder' expr:data-href='data:post.url.canonical' expr:data-viewtype='data:post.viewType'/>
                <b:if cond='!data:post.embedCommentForm'>
                  <b:include data='post' name='commentsLink'/>
                </b:if>
              </b:if>
            </b:includable>
            <b:includable id='indexPost' var='post'>
              <!-- Index Post Content -->
              <b:include data='post' name='postMeta'/>
              <b:include data='post' name='postFeaturedImage'/>
              <b:include data='post' name='postHeader'/>
            </b:includable>
            <b:includable id='inlineAd' var='post'>
              <b:if cond='!data:view.isPreview'>
                <b:if cond='data:i != 0'>
                  <b:if cond='data:post.includeAd and data:post.adNumber'>
                    <b:if cond='data:this.adCode or data:this.adClientId or data:blog.adsenseClientId'>
                      <div expr:class='&quot;index-post post-ad-type post-ad-&quot; + data:i'>
                        <div class='inline-ad-wrap'>
                          <div class='inline-ad'>
                            <b:if cond='data:this.adCode != &quot;&quot;'>
                              <data:this.adCode/>
                              <b:else/>
                              <b:if cond='data:this.adClientId or data:blog.adsenseClientId'>
                                <ins class='adsbygoogle' data-ad-format='fluid' data-ad-layout-key='-75+cz-2f-19+kd' expr:data-ad-client='data:adClientId ?: data:blog.adsenseClientId' expr:data-ad-host='data:blog.adsenseHostId' expr:data-analytics-uacct='data:blog.analyticsAccountNumber' expr:style='data:style ?: &quot;display: block;&quot;' style='display:inline-block'/>
                                <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
                              </b:if>
                            </b:if>
                          </div>
                        </div>
                      </div>
                    </b:if>
                  </b:if>
                </b:if>
              </b:if>
            </b:includable>
            <b:includable id='itemPost' var='post'>
              <!-- Item Post Content -->
              <b:include data='post' name='postMeta'/>
              <b:include cond='data:view.isPost' data='post' name='postBreadcrumbs'/>
              <b:if cond='data:view.isPost'>
                <div class='product-header'>
                  <div class='col-left'>
                    <div class='post-image-wrap item_image'>
                      <b:if cond='data:post.featuredImage'> 
                        <img class='post-thumb item_thumb' expr:alt='data:post.title' expr:src='data:post.featuredImage resizeImage 680'/>
                        <b:else/>
                        <img class='post-thumb item_thumb' expr:alt='data:post.title' src='https://4.bp.blogspot.com/-O3EpVMWcoKw/WxY6-6I4--I/AAAAAAAAB2s/KzC0FqUQtkMdw7VzT6oOR_8vbZO6EJc-ACK4BGAYYCw/w680/nth.png'/>
                      </b:if>
                      <span class='product_off'/>
                    </div>
                  </div>
                  <div class='col-right'>
                    <h1 class='post-title item_name'>
                     <data:post.title/>
                    </h1>
                    <div class='bk-left'><span itemprop='name'>Sinopse:<b/><b:eval expr='data:post.snippets.long snippet { length: 700 }'/></span></div>
                   <div class='kdm_product_item_price item_price'><b><data:allBylineItems.timestamp.label/></b><span class='kdm_product_price meta-price'/></div>
                  <div class='kdm-product-buy-buttons'>
                    <div class='bk-left'><span itemprop='name'><b>Data de Lançamento:</b><time class='published' expr:datetime='data:post.date.iso8601'><data:post.date/></time><span class='product_author'/></span>                     </div><b:include data='post' name='postLabels'/>
                    </div>
                  </div>
                
                 
            <span class='product_off'/>
                </div>
              </b:if>
              <b:if cond='data:view.isPage'>
                <h1 class='post-title'>
                  <data:post.title/>
                </h1>
              </b:if>
              <b:include data='post' name='postBody'/>
              <b:include cond='data:view.isPost' data='post' name='postFooter'/>
            </b:includable>
            <b:includable id='jsMessages'>
              <script type='text/javascript'>
                var messages = { 
                  postedBy: &quot;<data:allBylineItems.author.label/>&quot;,
                  postedOn: &quot;<data:allBylineItems.timestamp.label/>&quot;,
                  showMore: &quot;&quot;
                }
              </script>
            </b:includable>
            <b:includable id='linkShare'>
  <b:with value='&quot;window.prompt(\&quot;Copy to clipboard: Ctrl+C, Enter\&quot;, \&quot;&quot; + data:originalUrl + &quot;\&quot;); return false;&quot;' var='onclick'>
    <b:include name='platformShare'/>
  </b:with>
</b:includable>
            <b:includable id='nextPageLink'>
              <b:comment>Disabled.</b:comment>
            </b:includable>
            <b:includable id='otherSharingButton'>
  <span class='sharing-platform-button sharing-element-other' expr:aria-label='data:messages.shareToOtherApps.escaped' expr:data-url='data:originalUrl' expr:title='data:messages.shareToOtherApps.escaped' role='menuitem' tabindex='-1'>
    <b:with value='{key: &quot;sharingOther&quot;}' var='platform'>
      <b:include name='sharingPlatformIcon'/>
    </b:with>
    <span class='platform-sharing-text'><data:messages.shareOtherApps.escaped/></span>
  </span>
</b:includable>
            <b:includable id='platformShare'>
  <a expr:class='&quot;goog-inline-block sharing-&quot; + data:platform.key' expr:data-url='data:originalUrl' expr:href='data:shareUrl + &quot;&amp;target=&quot; + data:platform.target' expr:onclick='data:onclick ? data:onclick : &quot;&quot;' expr:title='data:platform.shareMessage' target='_blank'>
    <span class='share-button-link-text'>
      <data:platform.shareMessage/>
    </span>
  </a>
</b:includable>
            <b:includable id='post' var='post'>
              <!-- Post Index -->
              <b:if cond='data:view.isMultipleItems'>
                <b:include data='post' name='indexPost'/>
              </b:if>
              <!-- Post Item -->
              <b:if cond='data:view.isSingleItem'>
                <b:include data='post' name='itemPost'/>
              </b:if>
            </b:includable>
            <b:includable id='postAuthor' var='post'>
              <!-- Post Author -->
            </b:includable>
            <b:includable id='postBody' var='post'> 
              <!-- Ads before post content, if post page. -->
              <b:if cond='data:view.isPost'><div id='before-ad'/></b:if>
              <!-- Post Body Entry Content-->
              <div class='post-body entry-content' id='post-body'>
                <data:post.body/>
              </div>
              <!-- Ads after post content, if post page. -->
              <b:if cond='data:view.isPost'><div id='after-ad'/></b:if>
            </b:includable>
            <b:includable id='postBodySnippet' var='post'>
              <b:include data='post' name='postBody'/>
            </b:includable>
            <b:includable id='postBreadcrumbs' var='post'>
              <!-- Post Breadcrumbs -->
              <b:if cond='data:view.isPost'>
              <nav id='breadcrumb'><a expr:href='data:blog.homepageUrl'><data:messages.home/></a><b:if cond='data:post.labels'><em class='delimiter'/><a class='b-label' expr:href='data:post.labels.first.url'><data:post.labels.first.name/></a></b:if><em class='delimiter'/><span class='current'><data:post.title/></span></nav>
                <script type='application/ld+json'>{
                &quot;@context&quot;: &quot;http://schema.org&quot;,
                &quot;@type&quot;: &quot;BreadcrumbList&quot;,
                &quot;itemListElement&quot;: [{
                  &quot;@type&quot;: &quot;ListItem&quot;,
                  &quot;position&quot;: 1,
                  &quot;name&quot;: &quot;<data:messages.home/>&quot;,
                  &quot;item&quot;: &quot;<data:blog.homepageUrl.canonical/>&quot;
                },{
                  &quot;@type&quot;: &quot;ListItem&quot;,
                  &quot;position&quot;: 2,
                  &quot;name&quot;: &quot;<b:if cond='data:post.labels'><data:post.labels.first.name/></b:if>&quot;,
                  &quot;item&quot;: &quot;<data:post.labels.first.url.canonical/>&quot;
                },{
                  &quot;@type&quot;: &quot;ListItem&quot;,
                  &quot;position&quot;: 3,
                  &quot;name&quot;: &quot;<data:post.title/>&quot;,
                  &quot;item&quot;: &quot;<data:post.url.canonical/>&quot;
                }]
              }</script>
              </b:if>
              <b:if cond='data:view.isPage'>
                <script type='application/ld+json'>{
                &quot;@context&quot;: &quot;http://schema.org&quot;,
                &quot;@type&quot;: &quot;BreadcrumbList&quot;,
                &quot;itemListElement&quot;: [{
                  &quot;@type&quot;: &quot;ListItem&quot;,
                  &quot;position&quot;: 1,
                  &quot;name&quot;: &quot;<data:messages.home/>&quot;,
                  &quot;item&quot;: &quot;<data:blog.homepageUrl.canonical/>&quot;
                },{
                  &quot;@type&quot;: &quot;ListItem&quot;,
                  &quot;position&quot;: 2,
                  &quot;name&quot;: &quot;<data:post.title/>&quot;,
                  &quot;item&quot;: &quot;<data:post.url.canonical/>&quot;
                }]
              }</script>
              </b:if>
            </b:includable>
            <b:includable id='postCategory' var='post'>
              <!-- Post Label/Category -->
              <b:if cond='data:post.labels'>
                <span class='entry-category'><data:post.labels.first.name/></span>
              </b:if>
            </b:includable>
            <b:includable id='postCommentsAndAd' var='post'>
              <!-- Custom Inline AD -->
              <b:include cond='data:view.isHomepage' data='post' name='inlineAd'/>
              <!-- Post Content Index and Item -->
              <article class='blog-post hentry'>
                <b:class cond='data:view.isMultipleItems' expr:name='&quot;index-post post-&quot; + data:i'/>
                <b:class cond='data:view.isSingleItem' name='item-post'/>
                <b:include data='post' name='post'/>

              </article>
              <!-- Comments -->
              <b:if cond='data:view.isSingleItem and data:post.allowComments'>
                <div class='galaxymag-blog-post-comments'>
                  <b:include data='post' name='threadedCommentsDisqus'/>
                  <b:include data='post' name='commentPicker'/>
                </div>
              </b:if>
              <b:include cond='data:allBylineItems.reactions' name='postNavigation'/>
            </b:includable>
            <b:includable id='postCommentsLink'>
              <b:if cond='data:view.isMultipleItems'>
                <span class='byline post-comment-link container'>
                  <b:include cond='data:post.commentSource != 1' name='commentsLink'/>
                  <b:include cond='data:post.commentSource == 1' name='commentsLinkIframe'/>
                </span>
              </b:if>
            </b:includable>
            <b:includable id='postFeaturedImage' var='post'>
              <!-- Post Featured Image on Index -->
              <div class='entry-image'>
                <b:if cond='data:post.featuredImage'>
                  <b:if cond='data:post.featuredImage.isYouTube'>
                    <a class='entry-image-link' expr:href='data:post.url'>
                      <span class='entry-thumb' expr:data-image='data:post.featuredImage'/>
                    </a>
                    <b:else/>
                    <a class='entry-image-link' expr:href='data:post.url'>
                      <span class='entry-thumb' expr:data-image='resizeImage(data:post.featuredImage, 72, &quot;1:1&quot;)'/>
                    </a>
                  </b:if>
                  <b:else/>
                  <a class='entry-image-link' expr:href='data:post.url'>
                    <span class='entry-thumb' data-image='https://4.bp.blogspot.com/-eALXtf-Ljts/WrQYAbzcPUI/AAAAAAAABjY/vptx-N2H46oFbiCqbSe2JgVSlHhyl0MwQCK4BGAYYCw/s72-c/nth-ify.png'/>
                  </a>
                </b:if>
                <b:include data='post' name='postCategory'/>
                <span class='product_off'/>
              </div>
            </b:includable>
            <b:includable id='postFooter' var='post'>
              <!-- Post Footer Itens -->
              <div class='post-footer'>
                <b:include cond='data:allBylineItems.labels' data='post' name='postLabels'/>
                <b:include cond='data:allBylineItems.share' data='post' name='postShareButtons'/>
                <b:include cond='data:post.author.aboutMe' data='post' name='postFooterAuthorProfile'/>
                <b:include cond='data:allBylineItems.backlinks' data='post' name='relatedPosts'/>
              </div>
            </b:includable>
            <b:includable id='postFooterAuthorProfile' var='post'>
              <div class='about-author'>
                <b:class cond='not data:allBylineItems.share' name='no-share'/>
                <div class='avatar-container'>
                  <b:if cond='data:post.author.authorPhoto.image'>
                    <span class='author-avatar' expr:data-image='resizeImage(data:post.author.authorPhoto.image, 60, &quot;1:1&quot;)'/>
                  </b:if>
                </div>
                <h3 class='author-name'>
                  <span><data:messages.postedBy/> </span><a expr:alt='data:post.author.name' expr:href='data:post.author.profileUrl' target='_blank'><data:post.author.name/></a>
                </h3>
                <div class='author-description social'>                        
                  <span class='description-text excerpt'><data:post.author.aboutMe/></span>
                </div>
              </div>
            </b:includable>
            <b:includable id='postHeader' var='post'>
              <b:include cond='data:view.isSingleItem' data='post' name='postBreadcrumbs'/>
              <b:include data='post' name='postTitle'/>
              <b:include cond='!data:view.isPage' data='post' name='headerByline'/>
            </b:includable>
            <b:includable id='postJumpLink' var='post'>
              <b:comment>Disabled.</b:comment>
            </b:includable>
            <b:includable id='postLabels' var='post'>
              <b:if cond='data:post.labels'>
                <div class='entry-tags'>
                  <b:if cond='data:allBylineItems.labels.label != &quot;&quot;'><span class='title'><data:allBylineItems.labels.label/></span></b:if>
                  <b:loop values='data:post.labels' var='label'>
                    <a class='label-link' expr:href='data:label.url' rel='tag'><data:label.name/></a>
                  </b:loop>
                </div>
              </b:if>
            </b:includable>
            <b:includable id='postLocation'>
  <span class='byline post-location'>
    <data:byline.label/>
    <a expr:href='data:post.location.mapsUrl' target='_blank'><data:post.location.name/></a>
  </span>
</b:includable>
            <b:includable id='postMeta' var='post'>
              <script type='application/ld+json'>
                {
                  &quot;@context&quot;: &quot;https://schema.org&quot;,
                  &quot;@type&quot;: &quot;NewsArticle&quot;,
                  &quot;mainEntityOfPage&quot;: {
                    &quot;@type&quot;: &quot;WebPage&quot;,
                    &quot;@id&quot;: &quot;<data:post.url.canonical.jsonEscaped/>&quot;
                  },
                  &quot;headline&quot;: &quot;<data:post.title.jsonEscaped/>&quot;,
                  &quot;description&quot;: &quot;<data:view.description.jsonEscaped/>&quot;,
                  &quot;image&quot;: [
                    &quot;<data:post.featuredImage.jsonEscaped/>&quot;
                   ],
                  &quot;datePublished&quot;: &quot;<data:post.date.iso8601.jsonEscaped/>&quot;,
                  &quot;dateModified&quot;: &quot;<data:post.lastUpdated.iso8601.jsonEscaped/>&quot;,
                  &quot;author&quot;: {
                    &quot;@type&quot;: &quot;Person&quot;,
                    &quot;name&quot;: &quot;<data:post.author.name.jsonEscaped/>&quot;
                  },
                   &quot;publisher&quot;: {
                    &quot;@type&quot;: &quot;Organization&quot;,
                    &quot;name&quot;: &quot;Blogger&quot;,
                    &quot;logo&quot;: {
                      &quot;@type&quot;: &quot;ImageObject&quot;,
                      &quot;url&quot;: &quot;https://lh3.googleusercontent.com/ULB6iBuCeTVvSjjjU1A-O8e9ZpVba6uvyhtiWRti_rBAs9yMYOFBujxriJRZ-A=h60&quot;,
                      &quot;width&quot;: 206,
                      &quot;height&quot;: 60
                    }
                  }
                }
              </script>
            </b:includable>
            <b:includable id='postMetadataJSONImage'>
  &quot;image&quot;: {
    &quot;@type&quot;: &quot;ImageObject&quot;,
    <b:if cond='data:post.featuredImage.isResizable'>
    &quot;url&quot;: &quot;<b:eval expr='resizeImage(data:post.featuredImage, 1200, &quot;1200:630&quot;)'/>&quot;,
    &quot;height&quot;: 630,
    &quot;width&quot;: 1200
    <b:else/>
    &quot;url&quot;: &quot;https://lh3.googleusercontent.com/ULB6iBuCeTVvSjjjU1A-O8e9ZpVba6uvyhtiWRti_rBAs9yMYOFBujxriJRZ-A=w1200&quot;,
    &quot;height&quot;: 348,
    &quot;width&quot;: 1200
    </b:if>
  },
</b:includable>
            <b:includable id='postMetadataJSONPublisher'>
 &quot;publisher&quot;: {
    &quot;@type&quot;: &quot;Organization&quot;,
    &quot;name&quot;: &quot;Blogger&quot;,
    &quot;logo&quot;: {
      &quot;@type&quot;: &quot;ImageObject&quot;,
      &quot;url&quot;: &quot;https://lh3.googleusercontent.com/ULB6iBuCeTVvSjjjU1A-O8e9ZpVba6uvyhtiWRti_rBAs9yMYOFBujxriJRZ-A=h60&quot;,
      &quot;width&quot;: 206,
      &quot;height&quot;: 60
    }
  },
</b:includable>
            <b:includable id='postNavigation'>
              <b:if cond='data:view.isPost'>
                <div class='post-nav'>
                  <b:if cond='data:newerPageUrl'>
                    <a>
                      <b:include data='{ message: &quot;prevPost&quot; }' name='translate'/>
                    </a>
                    <b:else/>
                    <span>
                      <b:include data='{ message: &quot;prevPost&quot; }' name='translate'/>
                    </span>
                  </b:if>
                  <b:if cond='data:olderPageUrl'>
                    <a>
                      <b:include data='{ message: &quot;nextPost&quot; }' name='translate'/>
                    </a>
                    <b:else/>
                    <span>
                      <b:include data='{ message: &quot;nextPost&quot; }' name='translate'/>
                    </span>
                  </b:if>
                </div>
              </b:if>
            </b:includable>
            <b:includable id='postPagination'>
              <!-- Post Pagination Index -->
              <div class='blog-pager container' id='blog-pager'>
                <b:if cond='data:olderPageUrl'>
                  <span class='blog-pager-older-link load-more' expr:data-load='data:olderPageUrl' id='load-more-link'><b:include data='{ message: &quot;loadMorePosts&quot; }' name='translate'/></span>
                  <span class='loading'><span class='loader'/></span>
                  <span class='no-more load-more'><b:include data='{ message: &quot;noMorePosts&quot; }' name='translate'/></span>
                  <b:else/>
                  <span class='no-more load-more show'><b:include data='{ message: &quot;noMorePosts&quot; }' name='translate'/></span>
                </b:if>
              </div>
            </b:includable>
            <b:includable id='postReactions'>
  <span class='byline reactions'>
    <span class='reactions-label'>
      <data:byline.label/>
    </span>
    <iframe allowtransparency='true' class='reactions-iframe' expr:src='data:post.reactionsUrl' frameborder='0' name='reactions' scrolling='no'/>
  </span>
</b:includable>
            <b:includable id='postReplyCount' var='post'>
              <!-- Post Reply -->
              <span class='entry-comments-link'><data:post.numberOfComments/></span>
            </b:includable>
            <b:includable id='postShareButtons'>
  <div class='byline post-share-buttons goog-inline-block'>
    <b:with value='data:sharingId ?: ((data:widget.instanceId ?: &quot;sharing&quot;) + &quot;-&quot; + (data:regionName ?: &quot;byline&quot;) + &quot;-&quot; + data:post.id)' var='sharingId'>
      <!-- Note: 'sharingButtons' includable is from the default Sharing widget markup. -->
      <b:include data='{                                                sharingId: data:sharingId,                                                originalUrl: data:post.url,                                                platforms: data:this.sharing.platforms,                                                shareUrl: data:post.shareUrl,                                                shareTitle: data:post.title,                                              }' name='sharingButtons'/>
    </b:with>
  </div>
</b:includable>
            <b:includable id='postShortMeta'>
              <b:comment>Disabled.</b:comment>
            </b:includable>
            <b:includable id='postSummary' var='post'>
              <b:comment>Disabled.</b:comment>
            </b:includable>
            <b:includable id='postTimestamp' var='post'>
              <!-- Post Timestamp -->
              <span class='entry-time'><b:if cond='data:allBylineItems.timestamp.label != &quot;&quot;'><em><data:allBylineItems.timestamp.label/></em></b:if><time class='published' expr:datetime='data:post.date.iso8601'><data:post.date/></time></span>
            </b:includable>
            <b:includable id='postTitle' var='post'>
              <!-- Post Title Index and Item -->
              <b:if cond='data:view.isMultipleItems'>
                <h2 class='entry-title'>
                  <a class='entry-title-link' expr:href='data:post.url' rel='bookmark'><data:post.title/></a>
                </h2>
              </b:if>
              <b:if cond='data:view.isSingleItem'>
            <span class='product_off'/>
                <h1 class='entry-title'>
                  <data:post.title/>
                </h1>
              </b:if>
            </b:includable>
            <b:includable id='previousPageLink'>
              <b:comment>Disabled.</b:comment>
            </b:includable>
            <b:includable id='relatedPosts' var='post'>
              <!-- Related Posts -->
              <div id='related-wrap'>
                <div class='title-wrap related-title'>
                  <h3><data:allBylineItems.backlinks.label/></h3>
                  <a class='more' expr:href='&quot;/search/label/&quot; + data:post.labels.first.name'><data:messages.viewAll/></a>
                </div>
                <div class='galaxymag-related-content'>
                  <b:if cond='data:post.labels'>
                    <div class='related-tag' expr:data-label='data:post.labels.first.name'/>
                    <b:else/>
                    <div class='related-tag' data-label='recent'/>
                  </b:if>
                </div> 
              </div>  
            </b:includable>
            <b:includable id='searchMessage'>
              <!-- Search Message -->
              <b:if cond='data:view.search.query'>
                <div class='queryMessage'>
                  <b:if cond='data:posts.empty'>
                    <span class='query-info query-error'/><data:view.search.resultsMessageHtml/>
                    <b:else/>
                    <span class='query-info query-success'><data:view.search.resultsMessageHtml/></span>
                  </b:if>
                </div>
              </b:if>
              <b:if cond='data:view.search.label'>
                <div class='queryMessage'>
                  <b:if cond='data:posts.empty'>
                    <span class='query-info query-error'><data:view.search.resultsMessageHtml/></span>
                    <b:else/>
                    <span class='query-info query-success'><data:view.search.resultsMessageHtml/></span>
                  </b:if>
                </div>
              </b:if>
              <b:if cond='data:view.isArchive'>
                <div class='queryMessage'>
                  <b:if cond='data:posts.empty'>
                    <span class='query-info query-error'><data:view.archive.rangeMessage/></span>
                    <b:else/>
                    <span class='query-info query-success'><data:view.archive.rangeMessage/></span>
                  </b:if>
                </div>
              </b:if>
              <b:if cond='data:view.isError'>
                <div class='errorWrap'>
                  <h3>404</h3>
                  <h4><data:messages.theresNothingHere/></h4>
                  <p><data:navMessage/></p>
                  <a class='homepage' expr:href='data:blog.homepageUrl'><i class='fas fa-home'/> <data:messages.home/></a>
                </div>
              </b:if>
              <b:if cond='data:view.isMultipleItems and data:posts.empty'><div class='queryEmpty'><data:messages.noResultsFound/></div></b:if>
            </b:includable>
            <b:includable id='sharingButton'>
  <span expr:aria-label='data:platform.shareMessage' expr:class='&quot;sharing-platform-button sharing-element-&quot; + data:platform.key' expr:data-href='data:shareUrl + &quot;&amp;target=&quot; + data:platform.target' expr:data-url='data:originalUrl' expr:title='data:platform.shareMessage' role='menuitem' tabindex='-1'>
    <b:include name='sharingPlatformIcon'/>
    <span class='platform-sharing-text'><data:platform.name/></span>
  </span>
</b:includable>
            <b:includable id='sharingButtonContent'>
  <div class='flat-icon-button ripple'>
    <b:include name='shareIcon'/>
  </div>
</b:includable>
            <b:includable id='sharingButtons'>
  <div class='sharing' expr:aria-owns='&quot;sharing-popup-&quot; + data:sharingId' expr:data-title='data:shareTitle'>
    <button class='sharing-button touch-icon-button' expr:aria-controls='&quot;sharing-popup-&quot; + data:sharingId' expr:aria-label='data:messages.share.escaped' expr:id='&quot;sharing-button-&quot; + data:sharingId' role='button'>
      <b:include name='sharingButtonContent'/>
    </button>
    <b:include name='sharingButtonsMenu'/>
  </div>
</b:includable>
            <b:includable id='sharingButtonsMenu'>
  <div class='share-buttons-container'>
    <ul aria-hidden='true' class='share-buttons hidden' expr:aria-label='data:messages.share.escaped' expr:id='&quot;sharing-popup-&quot; + data:sharingId' role='menu'>
      <b:loop values='(data:platforms ?: data:blog.sharing.platforms) filter (p =&gt; p.key not in {&quot;blogThis&quot;})' var='platform'>
        <li>
          <b:include name='sharingButton'/>
        </li>
      </b:loop>
      <li aria-hidden='true' class='hidden'>
        <b:include name='otherSharingButton'/>
      </li>
    </ul>
  </div>
</b:includable>
            <b:includable id='sharingPlatformIcon'>
  <b:include data='{ iconClass: (&quot;touch-icon sharing-&quot; + data:platform.key) }' expr:name='data:platform.key + &quot;Icon&quot;'/>
</b:includable>
            <b:includable id='threadedCommentForm' var='post'>
              <div class='comment-form'>
                <a name='comment-form'/>
                <h4 id='comment-post-message'><data:messages.postAComment/></h4>
                <b:if cond='data:this.messages.blogComment != &quot;&quot;'>
                  <p><data:this.messages.blogComment/></p>
                </b:if>
                <b:include data='post' name='commentFormIframeSrc'/>
                <iframe allowtransparency='allowtransparency' class='blogger-iframe-colorize blogger-comment-from-post' expr:height='data:cmtIframeInitialHeight ?: &quot;90px&quot;' frameborder='0' id='comment-editor' name='comment-editor' src='' width='100%'/>
                <data:post.cmtfpIframe/>
                <script type='text/javascript'>
                  BLOG_CMT_createIframe(&#39;<data:post.appRpcRelayPath/>&#39;);
                </script>
              </div>
            </b:includable>
            <b:includable id='threadedCommentJs' var='post'>
              <script async='async' expr:src='data:post.commentSrc' type='text/javascript'/>
              <b:template-script inline='true' name='threaded_comments'/>
              <script type='text/javascript'>
                blogger.widgets.blog.initThreadedComments(
                  <data:post.commentJso/>,
                  <data:post.commentMsgs/>,
                  <data:post.commentConfig/>);
              </script>
            </b:includable>
            <b:includable id='threadedComments' var='post'>
              <section class='comments threaded' expr:data-embed='data:post.embedCommentForm' expr:data-num-comments='data:post.numberOfComments' id='comments'>
                <b:class cond='data:post.numberOfComments == &quot;0&quot;' name='no-comments'/>
                <a name='comments'/>
                <b:include name='commentsTitle'/>
                <div class='comments-content'>
                  <b:if cond='data:post.embedCommentForm'>
                    <b:include data='post' name='threadedCommentJs'/>
                  </b:if>
                  <div id='comment-holder'>
                    <data:post.commentHtml/>
                  </div>
                </div>
                <p class='comment-footer'>
                  <b:if cond='data:post.allowNewComments'>
                    <b:include data='post' name='threadedCommentForm'/>
                    <b:else/>
                    <b:if cond='data:post.noNewCommentsText != &quot;&quot;'><span><data:post.noNewCommentsText/></span></b:if>
                  </b:if>
                </p>
                <b:if cond='data:showCmtPopup'>
                  <div id='comment-popup'>
                    <iframe allowtransparency='allowtransparency' frameborder='0' id='comment-actions' name='comment-actions' scrolling='no'>
                    </iframe>
                  </div>
                </b:if>
              </section>
            </b:includable>
            <b:includable id='threadedCommentsDisqus' var='post'>
              <script type='text/javascript'>
                var disqus_shortname = disqusShortname;
                var disqus_blogger_current_url = &quot;<data:post.url.canonical/>&quot;;
                if (!disqus_blogger_current_url.length) {
                  disqus_blogger_current_url = &quot;<data:post.url.canonical/>&quot;;
                }
                var disqus_blogger_homepage_url = &quot;<data:blog.canonicalHomepageUrl/>&quot;;
                var disqus_blogger_canonical_homepage_url = &quot;<data:blog.canonicalHomepageUrl/>&quot;;
              </script>
              <script type='text/javascript'>
                //<![CDATA[
                if (commentsSystem == 'disqus') {
                  (function() {
                    var bloggerjs = document.createElement('script');
                    bloggerjs.type = 'text/javascript';
                    bloggerjs.async = true;
                    bloggerjs.src = '//' + disqus_shortname + '.disqus.com/blogger_item.js';
                    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(bloggerjs);
                  })();
                }
                //]]>
              </script>
            </b:includable>
          </b:widget>
        </b:section>
        <div class='clearfix'/>
        <div id='custom-ads'>
          <b:section cond='data:view.isPost' id='main-before-ad' maxwidgets='1' name='ADS 1' showaddelement='yes'/>
          <b:section cond='data:view.isPost' id='main-after-ad' maxwidgets='1' name='ADS 2' showaddelement='yes'/>
        </div>
        <b:if cond='data:view.isHomepage'> 
          <div class='clearfix'/>
          <!-- Block Posts 02 -->
          <b:section class='block-posts' id='block-posts-2' name='Block Posts 2' showaddelement='yes'>
            <b:widget id='HTML8' locked='false' title='Action Movies' type='HTML' visible='false'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results="15" label="QT" type="carousel"]]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
            <b:widget id='HTML3' locked='false' title='More' type='HTML' visible='false'>
              <b:widget-settings>
                <b:widget-setting name='content'><![CDATA[[getBlock results='6' label='US' type='videos']]]></b:widget-setting>
              </b:widget-settings>
              <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
            </b:widget>
          </b:section>
        </b:if>
      </main>

      <aside id='sidebar-wrapper'>
        <b:section class='sidebar galaxymag-widget-ready' id='sidebar1' name='Sidebar 1' showaddelement='yes'/>
        <b:section class='sidebar' id='social-counter' maxwidgets='1' name='Social Count' showaddelement='no'>
          <b:widget id='LinkList156' locked='true' title='Follow Us' type='LinkList' version='2' visible='false'>
            <b:widget-settings>
              <b:widget-setting name='link-5'>#$9.5k</b:widget-setting>
              <b:widget-setting name='link-3'>#$1.2k</b:widget-setting>
              <b:widget-setting name='link-4'>#$6.2k</b:widget-setting>
              <b:widget-setting name='text-1'>instagram</b:widget-setting>
              <b:widget-setting name='text-0'>facebook-f</b:widget-setting>
              <b:widget-setting name='text-3'>twitch</b:widget-setting>
              <b:widget-setting name='text-2'>youtube</b:widget-setting>
              <b:widget-setting name='text-5'>twitter</b:widget-setting>
              <b:widget-setting name='text-4'>linkedin</b:widget-setting>
              <b:widget-setting name='sorting'>NONE</b:widget-setting>
              <b:widget-setting name='link-1'>#$2.7k</b:widget-setting>
              <b:widget-setting name='link-2'>#$8.7k</b:widget-setting>
              <b:widget-setting name='link-0'>https://www.facebook.com/khmermovie.dubbed/#$1.5k</b:widget-setting>
            </b:widget-settings>
            <b:includable id='main'>
  <b:include name='widget-title'/>
  <b:include name='content'/>
</b:includable>
            <b:includable id='content'>
              <div class='widget-content'>
                <ul class='social-icons social social-color'>
                  <b:loop index='l' values='data:links' var='link'>
                    <li expr:class='data:link.name + &quot; link-&quot; + data:l'><a expr:class='data:link.name' expr:data-content='data:link.target' href='#' target='_blank'><span class='count'/></a></li>
                  </b:loop>
                </ul>
              </div>
            </b:includable>
          </b:widget>
        </b:section>
        <b:section class='sidebar galaxymag-widget-ready' id='sidebar2' name='Sidebar 2' showaddelement='yes'>
          <b:widget id='HTML35' locked='false' title='Disqus for https-filmex2024-blogspot-com' type='HTML' visible='true'>
            <b:widget-settings>
              <b:widget-setting name='content'><![CDATA[<!-- Disqus Widget -->]]></b:widget-setting>
            </b:widget-settings>
            <b:includable id='main'>
<script type='text/javascript'>
var disqus_shortname = &#39;https-filmex2024-blogspot-com&#39;;
var disqus_blogger_current_url = &quot;<data:blog.canonicalUrl/>&quot;;
if (!disqus_blogger_current_url.length) {
disqus_blogger_current_url = &quot;<data:blog.url/>&quot;;
}
var disqus_blogger_homepage_url = &quot;<data:blog.homepageUrl/>&quot;;
var disqus_blogger_canonical_homepage_url = &quot;<data:blog.canonicalHomepageUrl/>&quot;;
</script>
<b:if cond='data:blog.pageType == &quot;item&quot;'>
<style type='text/css'>
#comments {display:none;}
</style>
<script type='text/javascript'>
(function() {
    var bloggerjs = document.createElement(&#39;script&#39;);
    bloggerjs.type = &#39;text/javascript&#39;;
    bloggerjs.async = true;
    bloggerjs.src = &#39;//&#39; + disqus_shortname + &#39;.disqus.com/blogger_item.js&#39;;
    (document.getElementsByTagName(&#39;head&#39;)[0] || document.getElementsByTagName(&#39;body&#39;)[0]).appendChild(bloggerjs);
})();
</script>
</b:if>
<style type='text/css'>
.post-comment-link { visibility: hidden; }
</style>
<script type='text/javascript'>
(function() {
var bloggerjs = document.createElement(&#39;script&#39;);
bloggerjs.type = &#39;text/javascript&#39;;
bloggerjs.async = true;
bloggerjs.src = &#39;//&#39; + disqus_shortname + &#39;.disqus.com/blogger_index.js&#39;;
(document.getElementsByTagName(&#39;head&#39;)[0] || document.getElementsByTagName(&#39;body&#39;)[0]).appendChild(bloggerjs);
})();
</script>
</b:includable>
          </b:widget>
          <b:widget id='HTML10' locked='false' title='Disqus for cine-livre' type='HTML' version='2' visible='true'>
            <b:widget-settings>
              <b:widget-setting name='content'><![CDATA[<!-- Disqus Widget -->]]></b:widget-setting>
            </b:widget-settings>
            <b:includable id='main'>
<script type='text/javascript'>
var disqus_shortname = &#39;cine-livre&#39;;
var disqus_blogger_current_url = &quot;<data:blog.canonicalUrl/>&quot;;
if (!disqus_blogger_current_url.length) {
disqus_blogger_current_url = &quot;<data:blog.url/>&quot;;
}
var disqus_blogger_homepage_url = &quot;<data:blog.homepageUrl/>&quot;;
var disqus_blogger_canonical_homepage_url = &quot;<data:blog.canonicalHomepageUrl/>&quot;;
</script>
<b:if cond='data:blog.pageType == &quot;item&quot;'>
<style type='text/css'>
#comments {display:none;}
</style>
<script type='text/javascript'>
(function() {
    var bloggerjs = document.createElement(&#39;script&#39;);
    bloggerjs.type = &#39;text/javascript&#39;;
    bloggerjs.async = true;
    bloggerjs.src = &#39;//&#39; + disqus_shortname + &#39;.disqus.com/blogger_item.js&#39;;
    (document.getElementsByTagName(&#39;head&#39;)[0] || document.getElementsByTagName(&#39;body&#39;)[0]).appendChild(bloggerjs);
})();
</script>
</b:if>
<style type='text/css'>
.post-comment-link { visibility: hidden; }
</style>
<script type='text/javascript'>
(function() {
var bloggerjs = document.createElement(&#39;script&#39;);
bloggerjs.type = &#39;text/javascript&#39;;
bloggerjs.async = true;
bloggerjs.src = &#39;//&#39; + disqus_shortname + &#39;.disqus.com/blogger_index.js&#39;;
(document.getElementsByTagName(&#39;head&#39;)[0] || document.getElementsByTagName(&#39;body&#39;)[0]).appendChild(bloggerjs);
})();
</script>
</b:includable>
          </b:widget>
        </b:section>
        <b:section class='sidebar sidebar-tabs galaxymag-widget-ready' id='sidebar-tabs' maxwidgets='4' name='Sidebar Tabs' showaddelement='yes'>
          <b:widget id='Label2' locked='false' title='Diretor' type='Label' visible='true'>
            <b:widget-settings>
              <b:widget-setting name='sorting'>ALPHA</b:widget-setting>
              <b:widget-setting name='display'>LIST</b:widget-setting>
              <b:widget-setting name='selectedLabelsList'>Dave BorthWick,Emma Tammi,Frank Passingham,Jean Duval,Martin Campbell,Maurício Eça,Takashi Miike,Todd Holland</b:widget-setting>
              <b:widget-setting name='showType'>USER_SELECTED</b:widget-setting>
              <b:widget-setting name='showFreqNumbers'>false</b:widget-setting>
            </b:widget-settings>
            <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <b:include name='content'/>
    </b:includable>
            <b:includable id='cloud'>
      <ul>
        <b:loop values='data:labels' var='label'>
          <li>
            <a class='label-name' expr:href='data:label.url'>
              <data:label.name/>
            </a>
          </li>
        </b:loop>
      </ul>
    </b:includable>
            <b:includable id='content'>
      <div class='widget-content'>
        <b:class expr:name='data:this.display + &quot;-label&quot;'/>
        <b:include cond='data:this.display == &quot;list&quot;' name='list'/>
        <b:include cond='data:this.display == &quot;cloud&quot;' name='cloud'/>
      </div>
    </b:includable>
            <b:includable id='list'>
      <ul>
        <b:loop values='data:labels' var='label'>
          <li>
            <a class='label-name' expr:href='data:label.url'>
              <data:label.name/><b:if cond='data:this.showFreqNumbers'><span class='label-count'>(<data:label.count/>)</span></b:if>
            </a>
          </li>
        </b:loop>
      </ul>
    </b:includable>
          </b:widget>
          <b:widget id='PopularPosts1' locked='false' title='Destaques' type='PopularPosts' version='2' visible='true'>
            <b:widget-settings>
              <b:widget-setting name='numItemsToShow'>5</b:widget-setting>
              <b:widget-setting name='showThumbnails'>true</b:widget-setting>
              <b:widget-setting name='showSnippets'>true</b:widget-setting>
              <b:widget-setting name='timeRange'>LAST_YEAR</b:widget-setting>
            </b:widget-settings>
            <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <div class='widget-content'>
        <b:loop index='i' values='data:posts' var='post'>
            <b:include data='post' name='content'/>
        </b:loop>
      </div>
    </b:includable>
            <b:includable id='blogThisShare'>
  <b:with value='&quot;window.open(this.href, \&quot;_blank\&quot;, \&quot;height=270,width=475\&quot;); return false;&quot;' var='onclick'>
    <b:include name='platformShare'/>
  </b:with>
</b:includable>
            <b:includable id='bylineByName' var='byline'>
  <b:switch var='data:byline.name'>
  <b:case value='share'/>
   
  <b:case value='comments'/>
    <b:include cond='data:post.allowComments' name='postCommentsLink'/>
  <b:case value='location'/>
    <b:include cond='data:post.location' name='postLocation'/>
  <b:case value='timestamp'/>
    <b:include cond='not data:view.isPage' name='postTimestamp'/>
  <b:case value='author'/>
    <b:include name='postAuthor'/>
  <b:case value='labels'/>
    <b:include cond='data:post.labels' name='postLabels'/>
  <b:case value='icons'/>
    <b:include cond='data:post.emailPostUrl' name='emailPostIcon'/>
  <b:case value='reactions'/>
    <b:include cond='data:post.reactionsUrl' name='postReactions'/>
  </b:switch>
</b:includable>
            <b:includable id='bylineRegion' var='regionItems'>
  <b:loop values='data:regionItems' var='byline'>
    <b:include data='byline' name='bylineByName'/>
  </b:loop>
</b:includable>
            <b:includable id='commentsLink'>
  <a class='comment-link' expr:href='data:post.commentsUrl' expr:onclick='data:post.commentsUrlOnclick'>
    <b:if cond='data:post.numberOfComments &gt; 0'>
      <b:message name='messages.numberOfComments'>
        <b:param expr:value='data:post.numberOfComments' name='numComments'/>
      </b:message>
    <b:else/>
      <data:messages.postAComment/>
    </b:if>
  </a>
</b:includable>
            <b:includable id='commentsLinkIframe'>
  <!-- G+ comments, no longer available. The includable is retained for backwards-compatibility. -->
</b:includable>
            <b:includable id='content' var='post'>
      <b:include data='post' name='defaultPost'/>
    </b:includable>
            <b:includable id='defaultPost' var='post'>
      <article class='popular-post post'>
        <b:class expr:name='&quot;item-&quot;+data:i'/>
        <b:if cond='data:post.featuredImage'>
          <b:if cond='data:post.featuredImage.isYouTube'>
            <a class='entry-image-link' expr:href='data:post.url'>
              <span class='entry-thumb' expr:data-image='data:post.featuredImage'/>
            </a>
            <b:else/>
            <a class='entry-image-link' expr:href='data:post.url'>
              <span class='entry-thumb' expr:data-image='resizeImage(data:post.featuredImage, 72, &quot;1:1&quot;)'/>
            </a>
          </b:if>
          <b:else/>
          <a class='entry-image-link' expr:href='data:post.url'>
            <span class='entry-thumb' data-image='https://4.bp.blogspot.com/-eALXtf-Ljts/WrQYAbzcPUI/AAAAAAAABjY/vptx-N2H46oFbiCqbSe2JgVSlHhyl0MwQCK4BGAYYCw/s72-c/nth-ify.png'/>
          </a>
            <span class='product_off'/>
        </b:if>
        <div class='entry-header'>
          <h2 class='entry-title'>
            <a expr:href='data:post.url'><data:post.title/></a>
          </h2>
          <div class='entry-meta'>
            <span class='entry-time'><time class='published' expr:datetime='data:post.date.iso8601'><data:post.date/></time></span>
          </div>
        </div>
      </article>
    </b:includable>
            <b:includable id='emailPostIcon'>
  <span class='byline post-icons'>
    <!-- email post links -->
    <span class='item-action'>
      <a expr:href='data:post.emailPostUrl' expr:title='data:messages.emailPost'>
        <b:include data='{ iconClass: &quot;touch-icon sharing-icon&quot; }' name='emailIcon'/>
      </a>
    </span>
  </span>
</b:includable>
            <b:includable id='facebookShare'>
  <b:with value='&quot;window.open(this.href, \&quot;_blank\&quot;, \&quot;height=430,width=640\&quot;); return false;&quot;' var='onclick'>
    <b:include name='platformShare'/>
  </b:with>
</b:includable>
            <b:includable id='footerBylines'>
  <b:if cond='data:widgets.Blog.first.footerBylines'>
    <b:loop index='i' values='data:widgets.Blog.first.footerBylines' var='region'>
      <b:if cond='not data:region.items.empty'>
        <div expr:class='&quot;post-footer-line post-footer-line-&quot; + (data:i + 1)'>
          <b:with value='&quot;footer-&quot; + (data:i + 1)' var='regionName'>
            <b:include data='region.items' name='bylineRegion'/>
          </b:with>
        </div>
      </b:if>
    </b:loop>
  </b:if>
</b:includable>
            <b:includable id='googlePlusShare'>
  <div class='goog-inline-block google-plus-share-container'>
    <g:plusone annotation='inline' expr:href='data:originalUrl.canonical.http' size='medium' source='blogger:blog:plusone'/>
  </div>
</b:includable>
            <b:includable id='headerByline'>
  <b:if cond='data:widgets.Blog.first.headerByline'>
    <div class='post-header'>
      <div class='post-header-line-1'>
        <b:with value='&quot;header-1&quot;' var='regionName'>
          <b:include data='data:widgets.Blog.first.headerByline.items' name='bylineRegion'/>
        </b:with>
      </div>
    </div>
  </b:if>
</b:includable>
            <b:includable id='linkShare'>
  <b:with value='&quot;window.prompt(\&quot;Copy to clipboard: Ctrl+C, Enter\&quot;, \&quot;&quot; + data:originalUrl + &quot;\&quot;); return false;&quot;' var='onclick'>
    <b:include name='platformShare'/>
  </b:with>
</b:includable>
            <b:includable id='otherSharingButton'>
  <span class='sharing-platform-button sharing-element-other' expr:aria-label='data:messages.shareToOtherApps.escaped' expr:data-url='data:originalUrl' expr:title='data:messages.shareToOtherApps.escaped' role='menuitem' tabindex='-1'>
    <b:with value='{key: &quot;sharingOther&quot;}' var='platform'>
      <b:include name='sharingPlatformIcon'/>
    </b:with>
    <span class='platform-sharing-text'><data:messages.shareOtherApps.escaped/></span>
  </span>
</b:includable>
            <b:includable id='platformShare'>
  <a expr:class='&quot;goog-inline-block sharing-&quot; + data:platform.key' expr:data-url='data:originalUrl' expr:href='data:shareUrl + &quot;&amp;target=&quot; + data:platform.target' expr:onclick='data:onclick ? data:onclick : &quot;&quot;' expr:title='data:platform.shareMessage' target='_blank'>
    <span class='share-button-link-text'>
      <data:platform.shareMessage/>
    </span>
  </a>
</b:includable>
            <b:includable id='postAuthor'>
  <span class='byline post-author vcard'>
    <span class='post-author-label'>
      <data:byline.label/>
    </span>
    <span class='fn'>
      <b:if cond='data:post.author.profileUrl'>
        <meta expr:content='data:post.author.profileUrl'/>
        <a class='g-profile' expr:href='data:post.author.profileUrl' rel='author' title='author profile'>
          <span><data:post.author.name/></span>
        </a>
      <b:else/>
        <span><data:post.author.name/></span>
      </b:if>
    </span>
  </span>
</b:includable>
            <b:includable id='postCommentsLink'>
  <span class='byline post-comment-link container'>
    <b:include cond='data:post.commentSource != 1' name='commentsLink'/>
  </span>
</b:includable>
            <b:includable id='postJumpLink' var='post'>
  <div class='jump-link flat-button'>
    <a expr:href='data:post.url fragment &quot;more&quot;' expr:title='data:post.title'>
      <b:eval expr='data:blog.jumpLinkMessage'/>
    </a>
  </div>
</b:includable>
            <b:includable id='postLabels'>
  <span class='byline post-labels'>
    <span class='byline-label'><data:byline.label/></span>
    <b:loop index='i' values='data:post.labels' var='label'>
      <a expr:href='data:label.url' rel='tag'>
        <data:label.name/>
      </a>
    </b:loop>
  </span>
</b:includable>
            <b:includable id='postLocation'>
  <span class='byline post-location'>
    <data:byline.label/>
    <a expr:href='data:post.location.mapsUrl' target='_blank'><data:post.location.name/></a>
  </span>
</b:includable>
            <b:includable id='postReactions'>
  <span class='byline reactions'>
    <span class='reactions-label'>
      <data:byline.label/>
    </span>
    <iframe allowtransparency='true' class='reactions-iframe' expr:src='data:post.reactionsUrl' frameborder='0' name='reactions' scrolling='no'/>
  </span>
</b:includable>
            <b:includable id='postShareButtons'>
  <div class='byline post-share-buttons goog-inline-block'>
    <b:with value='data:sharingId ?: ((data:widget.instanceId ?: &quot;sharing&quot;) + &quot;-&quot; + (data:regionName ?: &quot;byline&quot;) + &quot;-&quot; + data:post.id)' var='sharingId'>
      <!-- Note: 'sharingButtons' includable is from the default Sharing widget markup. -->
      <b:include data='{                                                sharingId: data:sharingId,                                                originalUrl: data:post.url,                                                platforms: data:this.sharing.platforms,                                                shareUrl: data:post.shareUrl,                                                shareTitle: data:post.title,                                              }' name='sharingButtons'/>
    </b:with>
  </div>
</b:includable>
            <b:includable id='postTimestamp'>
  <span class='byline post-timestamp'>
    <data:byline.label/>
    <b:if cond='data:post.url'>
      <meta expr:content='data:post.url.canonical'/>
      <a class='timestamp-link' expr:href='data:post.url' rel='bookmark' title='permanent link'>
        <time class='published' expr:datetime='data:post.date.iso8601' expr:title='data:post.date.iso8601'>
          <data:post.date/>
        </time>
      </a>
    </b:if>
  </span>
</b:includable>
            <b:includable id='sharingButton'>
  <span expr:aria-label='data:platform.shareMessage' expr:class='&quot;sharing-platform-button sharing-element-&quot; + data:platform.key' expr:data-href='data:shareUrl + &quot;&amp;target=&quot; + data:platform.target' expr:data-url='data:originalUrl' expr:title='data:platform.shareMessage' role='menuitem' tabindex='-1'>
    <b:include name='sharingPlatformIcon'/>
    <span class='platform-sharing-text'><data:platform.name/></span>
  </span>
</b:includable>
            <b:includable id='sharingButtonContent'>
  <div class='flat-icon-button ripple'>
    <b:include name='shareIcon'/>
  </div>
</b:includable>
            <b:includable id='sharingButtons'>
  <div class='sharing' expr:aria-owns='&quot;sharing-popup-&quot; + data:sharingId' expr:data-title='data:shareTitle'>
    <button class='sharing-button touch-icon-button' expr:aria-controls='&quot;sharing-popup-&quot; + data:sharingId' expr:aria-label='data:messages.share.escaped' expr:id='&quot;sharing-button-&quot; + data:sharingId' role='button'>
      <b:include name='sharingButtonContent'/>
    </button>
    <b:include name='sharingButtonsMenu'/>
  </div>
</b:includable>
            <b:includable id='sharingButtonsMenu'>
  <div class='share-buttons-container'>
    <ul aria-hidden='true' class='share-buttons hidden' expr:aria-label='data:messages.share.escaped' expr:id='&quot;sharing-popup-&quot; + data:sharingId' role='menu'>
      <b:loop values='(data:platforms ?: data:blog.sharing.platforms) filter (p =&gt; p.key not in {&quot;blogThis&quot;})' var='platform'>
        <li>
          <b:include name='sharingButton'/>
        </li>
      </b:loop>
      <li aria-hidden='true' class='hidden'>
        <b:include name='otherSharingButton'/>
      </li>
    </ul>
  </div>
</b:includable>
            <b:includable id='sharingPlatformIcon'>
  <b:include data='{ iconClass: (&quot;touch-icon sharing-&quot; + data:platform.key) }' expr:name='data:platform.key + &quot;Icon&quot;'/>
</b:includable>
            <b:includable id='snippetedPostByline'>
  <b:with value='(data:widgets first (w =&gt; w.type == &quot;Blog&quot;)).allBylineItems' var='blogBylines'>
    <div class='item-byline'>
      <b:with value='data:blogBylines first (i =&gt; i.name == &quot;author&quot;)' var='byline'>
        <b:include cond='data:byline and data:this.postDisplay.showAuthor' data='post' name='postAuthor'/>
      </b:with>
      <b:with value='data:blogBylines first (i =&gt; i.name == &quot;timestamp&quot;)' var='byline'>
        <b:include cond='data:byline and data:this.postDisplay.showDate' data='post' name='postTimestamp'/>
      </b:with>
    </div>
  </b:with>
</b:includable>
            <b:includable id='snippetedPostContent'>
  <div class='post-content'>
    <b:include cond='data:this.postDisplay.showTitle' name='snippetedPostTitle'/>
    <b:include cond='data:this.postDisplay.showDate or data:this.postDisplay.showAuthor' name='snippetedPostByline'/>
    <b:include cond='data:this.postDisplay.showSnippet' data='post' name='postSnippet'/>
    <b:include cond='data:this.postDisplay.showFeaturedImage and data:post.featuredImage' name='snippetedPostThumbnail'/>
  </div>
</b:includable>
            <b:includable id='snippetedPostThumbnail'>
  <div class='item-thumbnail'>
    <a expr:href='data:post.url'>
      <b:include data='{                         image: data:post.featuredImage,                         imageSizes: [72, 144],                         imageRatio: &quot;1:1&quot;,                         sourceSizes: &quot;72px&quot;                        }' name='responsiveImage'/>
    </a>
  </div>
</b:includable>
            <b:includable id='snippetedPostTitle'>
  <b:if cond='data:post.title != &quot;&quot;'>
    <h3 class='post-title'><a expr:href='data:post.url'><data:post.title/></a></h3>
  </b:if>
</b:includable>
            <b:includable id='snippetedPosts'>
  <div role='feed'>
    <!-- Don't render the post that we're currently already looking at. -->
    <b:loop values='data:posts filter (p =&gt; p.id != data:view.postId)' var='post'>
      <article class='post' role='article'>
        <b:include name='snippetedPostContent'/>
      </article>
    </b:loop>
  </div>
</b:includable>
          </b:widget>
          <b:widget id='Label4' locked='false' title='Categorias' type='Label' visible='true'>
            <b:widget-settings>
              <b:widget-setting name='sorting'>ALPHA</b:widget-setting>
              <b:widget-setting name='display'>LIST</b:widget-setting>
              <b:widget-setting name='selectedLabelsList'>Animação,Aventura,Ação,Comédia,Crime,Drama,Família,Fantasia,Ficção Científica,Guerra,Mistério,Romance,Terror,Thriller</b:widget-setting>
              <b:widget-setting name='showType'>USER_SELECTED</b:widget-setting>
              <b:widget-setting name='showFreqNumbers'>true</b:widget-setting>
            </b:widget-settings>
            <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <b:include name='content'/>
    </b:includable>
            <b:includable id='cloud'>
      <ul>
        <b:loop values='data:labels' var='label'>
          <li>
            <a class='label-name' expr:href='data:label.url'>
              <data:label.name/>
            </a>
          </li>
        </b:loop>
      </ul>
    </b:includable>
            <b:includable id='content'>
      <div class='widget-content'>
        <b:class expr:name='data:this.display + &quot;-label&quot;'/>
        <b:include cond='data:this.display == &quot;list&quot;' name='list'/>
        <b:include cond='data:this.display == &quot;cloud&quot;' name='cloud'/>
      </div>
    </b:includable>
            <b:includable id='list'>
      <ul>
        <b:loop values='data:labels' var='label'>
          <li>
            <a class='label-name' expr:href='data:label.url'>
              <data:label.name/><b:if cond='data:this.showFreqNumbers'><span class='label-count'>(<data:label.count/>)</span></b:if>
            </a>
          </li>
        </b:loop>
      </ul>
    </b:includable>
          </b:widget>
          <b:widget id='Label1' locked='false' title='Ano' type='Label' visible='true'>
            <b:widget-settings>
              <b:widget-setting name='sorting'>ALPHA</b:widget-setting>
              <b:widget-setting name='display'>LIST</b:widget-setting>
              <b:widget-setting name='selectedLabelsList'>1989,2003,2007,2022,2023</b:widget-setting>
              <b:widget-setting name='showType'>USER_SELECTED</b:widget-setting>
              <b:widget-setting name='showFreqNumbers'>true</b:widget-setting>
            </b:widget-settings>
            <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <b:include name='content'/>
    </b:includable>
            <b:includable id='cloud'>
      <ul>
        <b:loop values='data:labels' var='label'>
          <li>
            <a class='label-name' expr:href='data:label.url'>
              <data:label.name/>
            </a>
          </li>
        </b:loop>
      </ul>
    </b:includable>
            <b:includable id='content'>
      <div class='widget-content'>
        <b:class expr:name='data:this.display + &quot;-label&quot;'/>
        <b:include cond='data:this.display == &quot;list&quot;' name='list'/>
        <b:include cond='data:this.display == &quot;cloud&quot;' name='cloud'/>
      </div>
    </b:includable>
            <b:includable id='list'>
      <ul>
        <b:loop values='data:labels' var='label'>
          <li>
            <a class='label-name' expr:href='data:label.url'>
              <data:label.name/><b:if cond='data:this.showFreqNumbers'><span class='label-count'>(<data:label.count/>)</span></b:if>
            </a>
          </li>
        </b:loop>
      </ul>
    </b:includable>
          </b:widget>
        </b:section>
        <b:section class='sidebar galaxymag-widget-ready' id='sidebar3' name='Sidebar 3' showaddelement='yes'>
          <b:widget id='HTML7' locked='false' title='Facebook Page' type='HTML' visible='false'>
            <b:widget-settings>
              <b:widget-setting name='content'><![CDATA[<center><div class="fb-page" data-href="https://www.facebook.com/khmermovie.dubbed/" data-width="210" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div></center>]]></b:widget-setting>
            </b:widget-settings>
            <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
          </b:widget>
        </b:section>
      </aside>

    </div>
  </div>

  <div class='clearfix'/>

  <!-- Footer Wrapper -->
  <footer id='footer-wrapper'> 
    <div class='container row-x1'>
      <div class='footer-widgets-wrap'>
        <b:section class='footer galaxymag-widget-ready' id='footer-sec1' maxwidgets='4' name='Footer 1' showaddelement='yes'>
          <b:widget id='Label3' locked='false' title='Ano de Lançamento' type='Label' visible='true'>
            <b:widget-settings>
              <b:widget-setting name='sorting'>ALPHA</b:widget-setting>
              <b:widget-setting name='display'>LIST</b:widget-setting>
              <b:widget-setting name='selectedLabelsList'>1989,2003,2007,2022,2023</b:widget-setting>
              <b:widget-setting name='showType'>USER_SELECTED</b:widget-setting>
              <b:widget-setting name='showFreqNumbers'>true</b:widget-setting>
            </b:widget-settings>
            <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <b:include name='content'/>
    </b:includable>
            <b:includable id='cloud'>
      <ul>
        <b:loop values='data:labels' var='label'>
          <li>
            <a class='label-name' expr:href='data:label.url'>
              <data:label.name/>
            </a>
          </li>
        </b:loop>
      </ul>
    </b:includable>
            <b:includable id='content'>
      <div class='widget-content'>
        <b:class expr:name='data:this.display + &quot;-label&quot;'/>
        <b:include cond='data:this.display == &quot;list&quot;' name='list'/>
        <b:include cond='data:this.display == &quot;cloud&quot;' name='cloud'/>
      </div>
    </b:includable>
            <b:includable id='list'>
      <ul>
        <b:loop values='data:labels' var='label'>
          <li>
            <a class='label-name' expr:href='data:label.url'>
              <data:label.name/><b:if cond='data:this.showFreqNumbers'><span class='label-count'>(<data:label.count/>)</span></b:if>
            </a>
          </li>
        </b:loop>
      </ul>
    </b:includable>
          </b:widget>
        </b:section>
        <b:section class='footer galaxymag-widget-ready' id='footer-sec2' maxwidgets='4' name='Footer 2' showaddelement='yes'>
          <b:widget id='PopularPosts2' locked='false' title='Top da semana' type='PopularPosts' version='2' visible='true'>
            <b:widget-settings>
              <b:widget-setting name='numItemsToShow'>4</b:widget-setting>
              <b:widget-setting name='showThumbnails'>true</b:widget-setting>
              <b:widget-setting name='showSnippets'>true</b:widget-setting>
              <b:widget-setting name='timeRange'>LAST_YEAR</b:widget-setting>
            </b:widget-settings>
            <b:includable id='main' var='this'>
      <b:include name='widget-title'/>
      <div class='widget-content'>
        <b:loop index='i' values='data:posts' var='post'>
            <b:include data='post' name='content'/>
        </b:loop>
      </div>
    </b:includable>
            <b:includable id='blogThisShare'>
  <b:with value='&quot;window.open(this.href, \&quot;_blank\&quot;, \&quot;height=270,width=475\&quot;); return false;&quot;' var='onclick'>
    <b:include name='platformShare'/>
  </b:with>
</b:includable>
            <b:includable id='bylineByName' var='byline'>
  <b:switch var='data:byline.name'>
  <b:case value='share'/>
    <b:include cond='data:post.shareUrl' name='postShareButtons'/>
  <b:case value='comments'/>
    <b:include cond='data:post.allowComments' name='postCommentsLink'/>
  <b:case value='location'/>
    <b:include cond='data:post.location' name='postLocation'/>
  <b:case value='timestamp'/>
    <b:include cond='not data:view.isPage' name='postTimestamp'/>
  <b:case value='author'/>
    <b:include name='postAuthor'/>
  <b:case value='labels'/>
    <b:include cond='data:post.labels' name='postLabels'/>
  <b:case value='icons'/>
    <b:include cond='data:post.emailPostUrl' name='emailPostIcon'/>
  <b:case value='reactions'/>
    <b:include cond='data:post.reactionsUrl' name='postReactions'/>
  </b:switch>
</b:includable>
            <b:includable id='bylineRegion' var='regionItems'>
  <b:loop values='data:regionItems' var='byline'>
    <b:include data='byline' name='bylineByName'/>
  </b:loop>
</b:includable>
            <b:includable id='commentsLink'>
  <a class='comment-link' expr:href='data:post.commentsUrl' expr:onclick='data:post.commentsUrlOnclick'>
    <b:if cond='data:post.numberOfComments &gt; 0'>
      <b:message name='messages.numberOfComments'>
        <b:param expr:value='data:post.numberOfComments' name='numComments'/>
      </b:message>
    <b:else/>
      <data:messages.postAComment/>
    </b:if>
  </a>
</b:includable>
            <b:includable id='commentsLinkIframe'>
  <!-- G+ comments, no longer available. The includable is retained for backwards-compatibility. -->
</b:includable>
            <b:includable id='content' var='post'>
      <b:include data='post' name='defaultPost'/>
    </b:includable>
            <b:includable id='defaultPost' var='post'>
      <article class='popular-post post'>
        <b:class expr:name='&quot;item-&quot;+data:i'/>
        <b:if cond='data:post.featuredImage'>
          <b:if cond='data:post.featuredImage.isYouTube'>
            <a class='entry-image-link' expr:href='data:post.url'>
              <span class='entry-thumb' expr:data-image='data:post.featuredImage'/>
            </a>
            <b:else/>
            <a class='entry-image-link' expr:href='data:post.url'>
              <span class='entry-thumb' expr:data-image='resizeImage(data:post.featuredImage, 72, &quot;1:1&quot;)'/>
            </a>
          </b:if>
          <b:else/>
          <a class='entry-image-link' expr:href='data:post.url'>
            <span class='entry-thumb' data-image='https://4.bp.blogspot.com/-eALXtf-Ljts/WrQYAbzcPUI/AAAAAAAABjY/vptx-N2H46oFbiCqbSe2JgVSlHhyl0MwQCK4BGAYYCw/s72-c/nth-ify.png'/>
            </a>
            <span class='product_off'/>
          </b:if>
        <div class='entry-header'>
          <h2 class='entry-title'>
            <a expr:href='data:post.url'><data:post.title/></a>
          </h2>
          <div class='entry-meta'>
            <span class='entry-time'><time class='published' expr:datetime='data:post.date.iso8601'><data:post.date/></time></span>
          </div>
        </div>
      </article>
    </b:includable>
            <b:includable id='emailPostIcon'>
  <span class='byline post-icons'>
    <!-- email post links -->
    <span class='item-action'>
      <a expr:href='data:post.emailPostUrl' expr:title='data:messages.emailPost'>
        <b:include data='{ iconClass: &quot;touch-icon sharing-icon&quot; }' name='emailIcon'/>
      </a>
    </span>
  </span>
</b:includable>
            <b:includable id='facebookShare'>
  <b:with value='&quot;window.open(this.href, \&quot;_blank\&quot;, \&quot;height=430,width=640\&quot;); return false;&quot;' var='onclick'>
    <b:include name='platformShare'/>
  </b:with>
</b:includable>
            <b:includable id='footerBylines'>
  <b:if cond='data:widgets.Blog.first.footerBylines'>
    <b:loop index='i' values='data:widgets.Blog.first.footerBylines' var='region'>
      <b:if cond='not data:region.items.empty'>
        <div expr:class='&quot;post-footer-line post-footer-line-&quot; + (data:i + 1)'>
          <b:with value='&quot;footer-&quot; + (data:i + 1)' var='regionName'>
            <b:include data='region.items' name='bylineRegion'/>
          </b:with>
        </div>
      </b:if>
    </b:loop>
  </b:if>
</b:includable>
            <b:includable id='googlePlusShare'>
  <div class='goog-inline-block google-plus-share-container'>
    <g:plusone annotation='inline' expr:href='data:originalUrl.canonical.http' size='medium' source='blogger:blog:plusone'/>
  </div>
</b:includable>
            <b:includable id='headerByline'>
  <b:if cond='data:widgets.Blog.first.headerByline'>
    <div class='post-header'>
      <div class='post-header-line-1'>
        <b:with value='&quot;header-1&quot;' var='regionName'>
          <b:include data='data:widgets.Blog.first.headerByline.items' name='bylineRegion'/>
        </b:with>
      </div>
    </div>
  </b:if>
</b:includable>
            <b:includable id='linkShare'>
  <b:with value='&quot;window.prompt(\&quot;Copy to clipboard: Ctrl+C, Enter\&quot;, \&quot;&quot; + data:originalUrl + &quot;\&quot;); return false;&quot;' var='onclick'>
    <b:include name='platformShare'/>
  </b:with>
</b:includable>
            <b:includable id='otherSharingButton'>
  <span class='sharing-platform-button sharing-element-other' expr:aria-label='data:messages.shareToOtherApps.escaped' expr:data-url='data:originalUrl' expr:title='data:messages.shareToOtherApps.escaped' role='menuitem' tabindex='-1'>
    <b:with value='{key: &quot;sharingOther&quot;}' var='platform'>
      <b:include name='sharingPlatformIcon'/>
    </b:with>
    <span class='platform-sharing-text'><data:messages.shareOtherApps.escaped/></span>
  </span>
</b:includable>
            <b:includable id='platformShare'>
  <a expr:class='&quot;goog-inline-block sharing-&quot; + data:platform.key' expr:data-url='data:originalUrl' expr:href='data:shareUrl + &quot;&amp;target=&quot; + data:platform.target' expr:onclick='data:onclick ? data:onclick : &quot;&quot;' expr:title='data:platform.shareMessage' target='_blank'>
    <span class='share-button-link-text'>
      <data:platform.shareMessage/>
    </span>
  </a>
</b:includable>
            <b:includable id='postAuthor'>
  <span class='byline post-author vcard'>
    <span class='post-author-label'>
      <data:byline.label/>
    </span>
    <span class='fn'>
      <b:if cond='data:post.author.profileUrl'>
        <meta expr:content='data:post.author.profileUrl'/>
        <a class='g-profile' expr:href='data:post.author.profileUrl' rel='author' title='author profile'>
          <span><data:post.author.name/></span>
        </a>
      <b:else/>
        <span><data:post.author.name/></span>
      </b:if>
    </span>
  </span>
</b:includable>
            <b:includable id='postCommentsLink'>
  <span class='byline post-comment-link container'>
    <b:include cond='data:post.commentSource != 1' name='commentsLink'/>
  </span>
</b:includable>
            <b:includable id='postJumpLink' var='post'>
  <div class='jump-link flat-button'>
    <a expr:href='data:post.url fragment &quot;more&quot;' expr:title='data:post.title'>
      <b:eval expr='data:blog.jumpLinkMessage'/>
    </a>
  </div>
</b:includable>
            <b:includable id='postLabels'>
  <span class='byline post-labels'>
    <span class='byline-label'><data:byline.label/></span>
    <b:loop index='i' values='data:post.labels' var='label'>
      <a expr:href='data:label.url' rel='tag'>
        <data:label.name/>
      </a>
    </b:loop>
  </span>
</b:includable>
            <b:includable id='postLocation'>
  <span class='byline post-location'>
    <data:byline.label/>
    <a expr:href='data:post.location.mapsUrl' target='_blank'><data:post.location.name/></a>
  </span>
</b:includable>
            <b:includable id='postReactions'>
  <span class='byline reactions'>
    <span class='reactions-label'>
      <data:byline.label/>
    </span>
    <iframe allowtransparency='true' class='reactions-iframe' expr:src='data:post.reactionsUrl' frameborder='0' name='reactions' scrolling='no'/>
  </span>
</b:includable>
            <b:includable id='postShareButtons'>
  <div class='byline post-share-buttons goog-inline-block'>
    <b:with value='data:sharingId ?: ((data:widget.instanceId ?: &quot;sharing&quot;) + &quot;-&quot; + (data:regionName ?: &quot;byline&quot;) + &quot;-&quot; + data:post.id)' var='sharingId'>
      <!-- Note: 'sharingButtons' includable is from the default Sharing widget markup. -->
      <b:include data='{                                                sharingId: data:sharingId,                                                originalUrl: data:post.url,                                                platforms: data:this.sharing.platforms,                                                shareUrl: data:post.shareUrl,                                                shareTitle: data:post.title,                                              }' name='sharingButtons'/>
    </b:with>
  </div>
</b:includable>
            <b:includable id='postTimestamp'>
  <span class='byline post-timestamp'>
    <data:byline.label/>
    <b:if cond='data:post.url'>
      <meta expr:content='data:post.url.canonical'/>
      <a class='timestamp-link' expr:href='data:post.url' rel='bookmark' title='permanent link'>
        <time class='published' expr:datetime='data:post.date.iso8601' expr:title='data:post.date.iso8601'>
          <data:post.date/>
        </time>
      </a>
    </b:if>
  </span>
</b:includable>
            <b:includable id='sharingButton'>
  <span expr:aria-label='data:platform.shareMessage' expr:class='&quot;sharing-platform-button sharing-element-&quot; + data:platform.key' expr:data-href='data:shareUrl + &quot;&amp;target=&quot; + data:platform.target' expr:data-url='data:originalUrl' expr:title='data:platform.shareMessage' role='menuitem' tabindex='-1'>
    <b:include name='sharingPlatformIcon'/>
    <span class='platform-sharing-text'><data:platform.name/></span>
  </span>
</b:includable>
            <b:includable id='sharingButtonContent'>
  <div class='flat-icon-button ripple'>
    <b:include name='shareIcon'/>
  </div>
</b:includable>
            <b:includable id='sharingButtons'>
  <div class='sharing' expr:aria-owns='&quot;sharing-popup-&quot; + data:sharingId' expr:data-title='data:shareTitle'>
    <button class='sharing-button touch-icon-button' expr:aria-controls='&quot;sharing-popup-&quot; + data:sharingId' expr:aria-label='data:messages.share.escaped' expr:id='&quot;sharing-button-&quot; + data:sharingId' role='button'>
      <b:include name='sharingButtonContent'/>
    </button>
    <b:include name='sharingButtonsMenu'/>
  </div>
</b:includable>
            <b:includable id='sharingButtonsMenu'>
  <div class='share-buttons-container'>
    <ul aria-hidden='true' class='share-buttons hidden' expr:aria-label='data:messages.share.escaped' expr:id='&quot;sharing-popup-&quot; + data:sharingId' role='menu'>
      <b:loop values='(data:platforms ?: data:blog.sharing.platforms) filter (p =&gt; p.key not in {&quot;blogThis&quot;})' var='platform'>
        <li>
          <b:include name='sharingButton'/>
        </li>
      </b:loop>
      <li aria-hidden='true' class='hidden'>
        <b:include name='otherSharingButton'/>
      </li>
    </ul>
  </div>
</b:includable>
            <b:includable id='sharingPlatformIcon'>
  <b:include data='{ iconClass: (&quot;touch-icon sharing-&quot; + data:platform.key) }' expr:name='data:platform.key + &quot;Icon&quot;'/>
</b:includable>
            <b:includable id='snippetedPostByline'>
  <b:with value='(data:widgets first (w =&gt; w.type == &quot;Blog&quot;)).allBylineItems' var='blogBylines'>
    <div class='item-byline'>
      <b:with value='data:blogBylines first (i =&gt; i.name == &quot;author&quot;)' var='byline'>
        <b:include cond='data:byline and data:this.postDisplay.showAuthor' data='post' name='postAuthor'/>
      </b:with>
      <b:with value='data:blogBylines first (i =&gt; i.name == &quot;timestamp&quot;)' var='byline'>
        <b:include cond='data:byline and data:this.postDisplay.showDate' data='post' name='postTimestamp'/>
      </b:with>
    </div>
  </b:with>
</b:includable>
            <b:includable id='snippetedPostContent'>
  <div class='post-content'>
    <b:include cond='data:this.postDisplay.showTitle' name='snippetedPostTitle'/>
    <b:include cond='data:this.postDisplay.showDate or data:this.postDisplay.showAuthor' name='snippetedPostByline'/>
    <b:include cond='data:this.postDisplay.showSnippet' data='post' name='postSnippet'/>
    <b:include cond='data:this.postDisplay.showFeaturedImage and data:post.featuredImage' name='snippetedPostThumbnail'/>
  </div>
</b:includable>
            <b:includable id='snippetedPostThumbnail'>
  <div class='item-thumbnail'>
    <a expr:href='data:post.url'>
      <b:include data='{                         image: data:post.featuredImage,                         imageSizes: [72, 144],                         imageRatio: &quot;1:1&quot;,                         sourceSizes: &quot;72px&quot;                        }' name='responsiveImage'/>
    </a>
  </div>
</b:includable>
            <b:includable id='snippetedPostTitle'>
  <b:if cond='data:post.title != &quot;&quot;'>
    <h3 class='post-title'><a expr:href='data:post.url'><data:post.title/></a></h3>
  </b:if>
</b:includable>
            <b:includable id='snippetedPosts'>
  <div role='feed'>
    <!-- Don't render the post that we're currently already looking at. -->
    <b:loop values='data:posts filter (p =&gt; p.id != data:view.postId)' var='post'>
      <article class='post' role='article'>
        <b:include name='snippetedPostContent'/>
      </article>
    </b:loop>
  </div>
</b:includable>
          </b:widget>
        </b:section>
        <b:section class='footer galaxymag-widget-ready' id='footer-sec3' maxwidgets='4' name='Footer 3' showaddelement='yes'/>
      </div>
      <b:section class='about-section' id='about-section' maxwidgets='2' name='About Section' showaddelement='yes'>
        <b:widget id='Image150' locked='true' title='Giant Templates' type='Image' version='2' visible='false'>
          <b:widget-settings>
            <b:widget-setting name='displayUrl'>http://4.bp.blogspot.com/-1pTv_JF90nA/Xwp7SEQXC4I/AAAAAAAAAJg/G3q7VB3L5IwPaWo3O8_MM1_-z5fNrSVRgCK4BGAYYCw/s1600/28e71718d77800866c7294bd8b665b09.png</b:widget-setting>
            <b:widget-setting name='displayHeight'>80</b:widget-setting>
            <b:widget-setting name='sectionWidth'>150</b:widget-setting>
            <b:widget-setting name='shrinkToFit'>false</b:widget-setting>
            <b:widget-setting name='displayWidth'>300</b:widget-setting>
            <b:widget-setting name='link'/>
            <b:widget-setting name='caption'>Disclaimer: This site is Absolutely Legal and contain only links to other sites on the internet: (netu.tv, openload.co, rapidvideo.com). We do not host or upload any video, films, media files. We are not responsible for the accuracy, compliance, copyright, legality, decency or any other aspect of the content of other linked sites.</b:widget-setting>
          </b:widget-settings>
          <b:includable id='main' var='this'>
            <b:include name='content'/>
          </b:includable>
          <b:includable id='content'>
            <div class='widget-content'>
              <b:if cond='data:link == &quot;hide-image&quot;'>
                <b:class name='no-image'/>
              </b:if>
              <b:if cond='data:link != &quot;hide-image&quot;'>
              <div class='footer-logo custom-image'>
                <a expr:href='data:blog.homepageUrl'>
                  <img expr:alt='data:blog.title' expr:id='data:widget.instanceId + &quot;_img&quot;' expr:src='data:sourceUrl'/>
                </a>
              </div>
              </b:if>
              <div class='about-content'>
                <b:include name='widget-title'/>
                <b:if cond='data:caption'>
                  <span class='image-caption excerpt'><data:caption/></span>
                </b:if>
              </div>
            </div>
          </b:includable>
        </b:widget>
        <b:widget id='LinkList157' locked='true' title='Follow Us' type='LinkList' version='2' visible='false'>
          <b:widget-settings>
            <b:widget-setting name='link-3'>http://</b:widget-setting>
            <b:widget-setting name='sorting'>NONE</b:widget-setting>
            <b:widget-setting name='text-1'>twitch</b:widget-setting>
            <b:widget-setting name='link-1'>http://</b:widget-setting>
            <b:widget-setting name='text-0'>facebook-f</b:widget-setting>
            <b:widget-setting name='link-2'>http://</b:widget-setting>
            <b:widget-setting name='text-3'>instagram</b:widget-setting>
            <b:widget-setting name='link-0'>http://</b:widget-setting>
            <b:widget-setting name='text-2'>youtube</b:widget-setting>
          </b:widget-settings>
          <b:includable id='main'>
            <b:include name='content'/>
          </b:includable>
          <b:includable id='content'>
            <div class='widget-content'>
              <ul class='social-footer social social-color'>
                <b:loop values='data:links' var='link'>
                  <li expr:class='data:link.name'><a expr:class='data:link.name' expr:href='data:link.target' target='_blank'/></li>
                </b:loop>
              </ul>
            </div>
          </b:includable>
        </b:widget>
      </b:section>
    </div>
    <div id='sub-footer-wrapper'>
      <div class='container row-x1'>
        <b:section class='footer-copyright' id='footer-copyright' maxwidgets='1' name='Footer Copyright' showaddelement='yes'>
          <b:widget id='Text150' locked='true' title='Credits' type='Text' version='2' visible='true'>
            <b:widget-settings>
              <b:widget-setting name='content'><![CDATA[<div class='copy-right'> <div id="credits"> @2023 Todos Direitos Reservados a <a id="creditlink" 'https://filmex2024.blogspot.com/'>Filmex 2024</a></div></div>]]></b:widget-setting>
            </b:widget-settings>
            <b:includable id='main'>
              <span class='copyright-text'><data:content/></span>
            </b:includable>
          </b:widget>
        </b:section>
        <b:section class='footer-menu' id='footer-menu' maxwidgets='1' name='Footer Menu' showaddelement='yes'>
          <b:widget id='LinkList158' locked='true' title='Link List' type='LinkList' version='2' visible='true'>
            <b:widget-settings>
              <b:widget-setting name='sorting'>NONE</b:widget-setting>
              <b:widget-setting name='text-1'>DMCA</b:widget-setting>
              <b:widget-setting name='link-1'>https://filmex2024.blogspot.com/p/dmca.html</b:widget-setting>
              <b:widget-setting name='text-0'>Início</b:widget-setting>
              <b:widget-setting name='link-2'>https://filmex2024.blogspot.com/p/termos-e-condicoes.html</b:widget-setting>
              <b:widget-setting name='link-0'>/</b:widget-setting>
              <b:widget-setting name='text-2'>Termos e condições</b:widget-setting>
            </b:widget-settings>
            <b:includable id='main'>
              <b:include name='content'/>
            </b:includable>
            <b:includable id='content'>
              <div class='widget-content'>
                <ul>
                  <b:loop values='data:links' var='link'>
                    <li><a expr:href='data:link.target'><data:link.name/></a></li>
                  </b:loop>
                </ul>
              </div>
            </b:includable>
          </b:widget>
        </b:section>
      </div>
    </div>
  </footer>

<!-- Hidden Widgets -->
  <div class='hidden-widgets' style='display:none'>
    <b:section class='hidden-widgets' deleted='true' id='hidden-widgets' maxwidgets='1' showaddelement='no'>
      <b:widget id='ContactForm1' locked='true' title='Formulário de contato' type='ContactForm' version='2' visible='true'>
        <b:includable id='main'>
          <b:include name='widget-title'/>
          <b:include name='content'/>
        </b:includable>
        <b:includable id='content'>
          <div class='contact-form-widget'>
            <div class='form'>
              <form name='contact-form'>
                <input class='contact-form-name' expr:id='data:widget.instanceId + &quot;_contact-form-name&quot;' expr:placeholder='data:contactFormNameMsg' name='name' size='30' type='text' value=''/>
                <input class='contact-form-email' expr:id='data:widget.instanceId + &quot;_contact-form-email&quot;' expr:placeholder='data:contactFormEmailMsg + &quot;*&quot;' name='email' size='30' type='text' value=''/>
                <textarea class='contact-form-email-message' cols='25' expr:id='data:widget.instanceId + &quot;_contact-form-email-message&quot;' expr:placeholder='data:contactFormMessageMsg + &quot;*&quot;' name='email-message' rows='5'/>
                <input class='contact-form-button contact-form-button-submit' expr:id='data:widget.instanceId + &quot;_contact-form-submit&quot;' expr:value='data:contactFormSendMsg' type='button'/>
                <p class='contact-form-error-message' expr:id='data:widget.instanceId + &quot;_contact-form-error-message&quot;'/>
                <p class='contact-form-success-message' expr:id='data:widget.instanceId + &quot;_contact-form-success-message&quot;'/>
              </form>
            </div>
          </div>
        </b:includable>
      </b:widget>
    </b:section>
  </div>
  </div>

<!-- Hosted Plugins -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js'/>
<script src='https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.0.0-beta.2.4/owl.carousel.min.js'/>
<!-- Templateify Plugins -->
<script type='text/javascript'>
//<![CDATA[
/*! jquery-simplecart | License MIT */
(function(p,f){var s="string",k=function(e,f){return typeof e===f},e=function(e){return k(e,"undefined")},h=function(e){return k(e,"function")},y=function(e){return"object"===typeof HTMLElement?e instanceof HTMLElement:"object"===typeof e&&1===e.nodeType&&"string"===typeof e.nodeName},C=function(q){function E(a){return b.extend({attr:"",label:"",view:"attr",text:"",className:"",hide:!1},a||{})}function F(){if(!b.isReady){try{f.documentElement.doScroll("left")}catch(a){setTimeout(F,1);return}b.init()}}
var t={MooTools:"$$",Prototype:"$$",jQuery:"*"},n=0,r={},x=q||"simpleCart",z={};q={};q={};var v=p.localStorage,l=p.console||{msgs:[],log:function(a){l.msgs.push(a)}},D={USD:{code:"USD",symbol:"&#36;",name:"US Dollar"},AUD:{code:"AUD",symbol:"&#36;",name:"Australian Dollar"},BRL:{code:"BRL",symbol:"R&#36;",name:"Brazilian Real"},CAD:{code:"CAD",symbol:"&#36;",name:"Canadian Dollar"},CZK:{code:"CZK",symbol:"&nbsp;&#75;&#269;",name:"Czech Koruna",after:!0},DKK:{code:"DKK",symbol:"DKK&nbsp;",name:"Danish Krone"},
EUR:{code:"EUR",symbol:"&euro;",name:"Euro"},HKD:{code:"HKD",symbol:"&#36;",name:"Hong Kong Dollar"},HUF:{code:"HUF",symbol:"&#70;&#116;",name:"Hungarian Forint"},ILS:{code:"ILS",symbol:"&#8362;",name:"Israeli New Sheqel"},JPY:{code:"JPY",symbol:"&yen;",name:"Japanese Yen",accuracy:0},MXN:{code:"MXN",symbol:"&#36;",name:"Mexican Peso"},NOK:{code:"NOK",symbol:"NOK&nbsp;",name:"Norwegian Krone"},NZD:{code:"NZD",symbol:"&#36;",name:"New Zealand Dollar"},PLN:{code:"PLN",symbol:"PLN&nbsp;",name:"Polish Zloty"},
GBP:{code:"GBP",symbol:"&pound;",name:"Pound Sterling"},SGD:{code:"SGD",symbol:"&#36;",name:"Singapore Dollar"},SEK:{code:"SEK",symbol:"SEK&nbsp;",name:"Swedish Krona"},CHF:{code:"CHF",symbol:"CHF&nbsp;",name:"Swiss Franc"},THB:{code:"THB",symbol:"&#3647;",name:"Thai Baht"},BTC:{code:"BTC",symbol:" BTC",name:"Bitcoin",accuracy:4,after:!0}},m={checkout:{type:"PayPal",email:"you@yours.com"},currency:"USD",language:"english-us",cartStyle:"div",cartColumns:[{attr:"name",label:"Name"},{attr:"price",label:"Price",
view:"currency"},{view:"decrement",label:!1},{attr:"quantity",label:"Qty"},{view:"increment",label:!1},{attr:"total",label:"SubTotal",view:"currency"},{view:"remove",text:"Remove",label:!1}],excludeFromCheckout:["thumb"],shippingFlatRate:0,shippingQuantityRate:0,shippingTotalRate:0,shippingCustom:null,taxRate:0,taxShipping:!1,data:{}},b=function(a){if(h(a))return b.ready(a);if(k(a,"object"))return b.extend(m,a)},A,B;b.extend=function(a,d){var c;e(d)&&(d=a,a=b);for(c in d)Object.prototype.hasOwnProperty.call(d,
c)&&(a[c]=d[c]);return a};b.extend({copy:function(a){a=C(a);a.init();return a}});b.extend({isReady:!1,add:function(a,d){var c=new b.Item(a||{}),g=!0,u=!0===d?d:!1;if(!u&&(g=b.trigger("beforeAdd",[c]),!1===g))return!1;(g=b.has(c))?(g.increment(c.quantity()),c=g):r[c.id()]=c;b.update();u||b.trigger("afterAdd",[c,e(g)]);return c},each:function(a,d){var c,g=0,u,e,w;if(h(a))e=a,w=r;else if(h(d))e=d,w=a;else return;for(c in w)if(Object.prototype.hasOwnProperty.call(w,c)){u=e.call(b,w[c],g,c);if(!1===u)break;
g+=1}},find:function(a){var d=[];if(k(r[a],"object"))return r[a];if(k(a,"object"))return b.each(function(c){var g=!0;b.each(a,function(a,b,d){k(a,s)?a.match(/<=.*/)?(a=parseFloat(a.replace("<=","")),c.get(d)&&parseFloat(c.get(d))<=a||(g=!1)):a.match(/</)?(a=parseFloat(a.replace("<","")),c.get(d)&&parseFloat(c.get(d))<a||(g=!1)):a.match(/>=/)?(a=parseFloat(a.replace(">=","")),c.get(d)&&parseFloat(c.get(d))>=a||(g=!1)):a.match(/>/)?(a=parseFloat(a.replace(">","")),c.get(d)&&parseFloat(c.get(d))>a||
(g=!1)):c.get(d)&&c.get(d)===a||(g=!1):c.get(d)&&c.get(d)===a||(g=!1);return g});g&&d.push(c)}),d;e(a)&&b.each(function(a){d.push(a)});return d},items:function(){return this.find()},has:function(a){var d=!1;b.each(function(b){b.equals(a)&&(d=b)});return d},empty:function(){var a={};b.each(function(b){!1===b.remove(!0)&&(a[b.id()]=b)});r=a;b.update()},quantity:function(){var a=0;b.each(function(b){a+=b.quantity()});return a},total:function(){var a=0;b.each(function(b){a+=b.total()});return a},grandTotal:function(){return b.total()+
b.tax()+b.shipping()},update:function(){b.save();b.trigger("update")},init:function(){b.load();b.update();b.ready()},$:function(a){return new b.ELEMENT(a)},$create:function(a){return b.$(f.createElement(a))},setupViewTool:function(){var a,d=p,c;for(c in t)if(Object.prototype.hasOwnProperty.call(t,c)&&p[c]&&(a=t[c].replace("*",c).split("."),(a=a.shift())&&(d=d[a]),"function"===typeof d)){A=d;b.extend(b.ELEMENT._,z[c]);break}},ids:function(){var a=[];b.each(function(b){a.push(b.id())});return a},save:function(){b.trigger("beforeSave");
var a={};b.each(function(d){a[d.id()]=b.extend(d.fields(),d.options())});v.setItem(x+"_items",JSON.stringify(a));b.trigger("afterSave")},load:function(){r={};var a=v.getItem(x+"_items");if(a){try{b.each(JSON.parse(a),function(a){b.add(a,!0)})}catch(d){b.error("Error Loading data: "+d)}b.trigger("load")}},ready:function(a){h(a)?b.isReady?a.call(b):b.bind("ready",a):e(a)&&!b.isReady&&(b.trigger("ready"),b.isReady=!0)},error:function(a){var d="";k(a,s)?d=a:k(a,"object")&&k(a.message,s)&&(d=a.message);
try{l.log("simpleCart(js) Error: "+d)}catch(c){}b.trigger("error",a)}});b.extend({tax:function(){var a=m.taxShipping?b.total()+b.shipping():b.total(),d=b.taxRate()*a;b.each(function(a){a.get("tax")?d+=a.get("tax"):a.get("taxRate")&&(d+=a.get("taxRate")*a.total())});return parseFloat(d)},taxRate:function(){return m.taxRate||0},shipping:function(a){if(h(a))b({shippingCustom:a});else{var d=m.shippingQuantityRate*b.quantity()+m.shippingTotalRate*b.total()+m.shippingFlatRate;h(m.shippingCustom)&&(d+=m.shippingCustom.call(b));
b.each(function(a){d+=parseFloat(a.get("shipping")||0)});return parseFloat(d)}}});B={attr:function(a,b){return a.get(b.attr)||""},currency:function(a,d){return b.toCurrency(a.get(d.attr)||0)},link:function(a,b){return"<a href='"+a.get(b.attr)+"'>"+b.text+"</a>"},decrement:function(a,b){return"<a href='javascript:;' class='"+x+"_decrement'>"+(b.text||"-")+"</a>"},increment:function(a,b){return"<a href='javascript:;' class='"+x+"_increment'>"+(b.text||"+")+"</a>"},image:function(a,b){return"<img src='"+
a.get(b.attr)+"'/>"},input:function(a,b){return"<input type='text' value='"+a.get(b.attr)+"' class='"+x+"_input'/>"},remove:function(a,b){return"<a href='javascript:;' class='"+x+"_remove'>"+(b.text||"X")+"</a>"}};b.extend({writeCart:function(a){var d=m.cartStyle.toLowerCase(),c="table"===d,g=c?"tr":"div",u=c?"th":"div",e=c?"td":"div",w=b.$create(d),d=b.$create(g).addClass("headerRow"),f,h;b.$(a).html(" ").append(w);w.append(d);c=0;for(h=m.cartColumns.length;c<h;c+=1)f=E(m.cartColumns[c]),a="item-"+
(f.attr||f.view||f.label||f.text||"cell")+" "+f.className,f=f.label||"",d.append(b.$create(u).addClass(a).html(f));b.each(function(a,d){b.createCartRow(a,d,g,e,w)});return w},createCartRow:function(a,d,c,g,u){d=b.$create(c).addClass("itemRow row-"+d+" "+(d%2?"even":"odd")).attr("id","cartItem_"+a.id());var e,f,l;u.append(d);u=0;for(c=m.cartColumns.length;u<c;u+=1)e=E(m.cartColumns[u]),f="item-"+(e.attr||(k(e.view,s)?e.view:e.label||e.text||"cell"))+" "+e.className,l=a,l=(h(e.view)?e.view:k(e.view,
s)&&h(B[e.view])?B[e.view]:B.attr).call(b,l,e),f=b.$create(g).addClass(f).html(l),d.append(f);return d}});b.Item=function(a){function d(){k(c.price,s)&&(c.price=parseFloat(c.price.replace(b.currency().decimal,".").replace(/[^0-9\.]+/ig,"")));isNaN(c.price)&&(c.price=0);0>c.price&&(c.price=0);k(c.quantity,s)&&(c.quantity=parseInt(c.quantity.replace(b.currency().delimiter,""),10));isNaN(c.quantity)&&(c.quantity=1);0>=c.quantity&&g.remove()}var c={},g=this;k(a,"object")&&b.extend(c,a);n+=1;for(c.id=
c.id||"SCI-"+n;!e(r[c.id]);)n+=1,c.id="SCI-"+n;g.get=function(a,b){var d=!b;return e(a)?a:h(c[a])?c[a].call(g):e(c[a])?h(g[a])&&d?g[a].call(g):!e(g[a])&&d?g[a]:c[a]:c[a]};g.set=function(a,b){e(a)||(c[a.toLowerCase()]=b,"price"!==a.toLowerCase()&&"quantity"!==a.toLowerCase()||d());return g};g.equals=function(a){for(var b in c)if(Object.prototype.hasOwnProperty.call(c,b)&&"quantity"!==b&&"id"!==b&&a.get(b)!==c[b])return!1;return!0};g.options=function(){var a={};b.each(c,function(d,c,e){var f=!0;b.each(g.reservedFields(),
function(a){a===e&&(f=!1);return f});f&&(a[e]=g.get(e))});return a};d()};b.Item._=b.Item.prototype={increment:function(a){a=parseInt(a||1,10);this.quantity(this.quantity()+a);return 1>this.quantity()?(this.remove(),null):this},decrement:function(a){return this.increment(-parseInt(a||1,10))},remove:function(a){if(!1===b.trigger("beforeRemove",[r[this.id()]]))return!1;delete r[this.id()];a||b.update();return null},reservedFields:function(){return"quantity id item_number price name shipping tax taxRate".split(" ")},
fields:function(){var a={},d=this;b.each(d.reservedFields(),function(b){d.get(b)&&(a[b]=d.get(b))});return a},quantity:function(a){return e(a)?parseInt(this.get("quantity",!0)||1,10):this.set("quantity",a)},price:function(a){return e(a)?parseFloat(this.get("price",!0).toString().replace(b.currency().symbol,"").replace(b.currency().delimiter,"")||1):this.set("price",parseFloat(a.toString().replace(b.currency().symbol,"").replace(b.currency().delimiter,"")))},id:function(){return this.get("id",!1)},
total:function(){return this.quantity()*this.price()}};b.extend({checkout:function(){if("custom"===m.checkout.type.toLowerCase()&&h(m.checkout.fn))m.checkout.fn.call(b,m.checkout);else if(h(b.checkout[m.checkout.type])){var a=b.checkout[m.checkout.type].call(b,m.checkout);a.data&&a.action&&a.method&&!1!==b.trigger("beforeCheckout",[a.data])&&b.generateAndSendForm(a)}else b.error("No Valid Checkout Method Specified")},extendCheckout:function(a){return b.extend(b.checkout,a)},generateAndSendForm:function(a){var d=
b.$create("form");d.attr("style","display:none;");d.attr("action",a.action);d.attr("method",a.method);b.each(a.data,function(a,g,e){d.append(b.$create("input").attr("type","hidden").attr("name",e).val(a))});b.$("body").append(d);d.el.submit();d.remove()}});b.extendCheckout({PayPal:function(a){if(!a.email)return b.error("No email provided for PayPal checkout");var d={cmd:"_cart",upload:"1",currency_code:b.currency().code,business:a.email,rm:"GET"===a.method?"0":"2",tax_cart:(1*b.tax()).toFixed(2),
handling_cart:(1*b.shipping()).toFixed(2),charset:"utf-8"},c=a.sandbox?"https://www.sandbox.paypal.com/cgi-bin/webscr":"https://www.paypal.com/cgi-bin/webscr",g="GET"===a.method?"GET":"POST";a.success&&(d["return"]=a.success);a.cancel&&(d.cancel_return=a.cancel);a.notify&&(d.notify_url=a.notify);b.each(function(a,c){var g=c+1,e=a.options(),f=0,h;d["item_name_"+g]=a.get("name");d["quantity_"+g]=a.quantity();d["amount_"+g]=(1*a.price()).toFixed(2);d["item_number_"+g]=a.get("item_number")||g;b.each(e,
function(a,c,e){10>c&&(h=!0,b.each(m.excludeFromCheckout,function(a){a===e&&(h=!1)}),h&&(f+=1,d["on"+c+"_"+g]=e,d["os"+c+"_"+g]=a))});d["option_index_"+c]=Math.min(10,f)});return{action:c,method:g,data:d}},GoogleCheckout:function(a){if(!a.merchantID)return b.error("No merchant id provided for GoogleCheckout");if("USD"!==b.currency().code&&"GBP"!==b.currency().code)return b.error("Google Checkout only accepts USD and GBP");var d={ship_method_name_1:"Shipping",ship_method_price_1:b.shipping(),ship_method_currency_1:b.currency().code,
_charset_:""},c="https://checkout.google.com/api/checkout/v2/checkoutForm/Merchant/"+a.merchantID;a="GET"===a.method?"GET":"POST";b.each(function(a,c){var e=c+1,f=[],h;d["item_name_"+e]=a.get("name");d["item_quantity_"+e]=a.quantity();d["item_price_"+e]=a.price();d["item_currency_ "+e]=b.currency().code;d["item_tax_rate"+e]=a.get("taxRate")||b.taxRate();b.each(a.options(),function(a,d,c){h=!0;b.each(m.excludeFromCheckout,function(a){a===c&&(h=!1)});h&&f.push(c+": "+a)});d["item_description_"+e]=f.join(", ")});
return{action:c,method:a,data:d}},AmazonPayments:function(a){if(!a.merchant_signature)return b.error("No merchant signature provided for Amazon Payments");if(!a.merchant_id)return b.error("No merchant id provided for Amazon Payments");if(!a.aws_access_key_id)return b.error("No AWS access key id provided for Amazon Payments");var d={aws_access_key_id:a.aws_access_key_id,merchant_signature:a.merchant_signature,currency_code:b.currency().code,tax_rate:b.taxRate(),weight_unit:a.weight_unit||"lb"},c="https://payments"+
(a.sandbox?"-sandbox":"")+".amazon.com/checkout/"+a.merchant_id,g="GET"===a.method?"GET":"POST";b.each(function(c,g){var e=g+1,f=[];d["item_title_"+e]=c.get("name");d["item_quantity_"+e]=c.quantity();d["item_price_"+e]=c.price();d["item_sku_ "+e]=c.get("sku")||c.id();d["item_merchant_id_"+e]=a.merchant_id;c.get("weight")&&(d["item_weight_"+e]=c.get("weight"));m.shippingQuantityRate&&(d["shipping_method_price_per_unit_rate_"+e]=m.shippingQuantityRate);b.each(c.options(),function(a,d,c){var g=!0;b.each(m.excludeFromCheckout,
function(a){a===c&&(g=!1)});g&&"weight"!==c&&"tax"!==c&&f.push(c+": "+a)});d["item_description_"+e]=f.join(", ")});return{action:c,method:g,data:d}},SendForm:function(a){if(!a.url)return b.error("URL required for SendForm Checkout");var d={currency:b.currency().code,shipping:b.shipping(),tax:b.tax(),taxRate:b.taxRate(),itemCount:b.find({}).length},c=a.url,g="GET"===a.method?"GET":"POST";b.each(function(a,c){var g=c+1,e=[],f;d["item_name_"+g]=a.get("name");d["item_quantity_"+g]=a.quantity();d["item_price_"+
g]=a.price();b.each(a.options(),function(a,d,c){f=!0;b.each(m.excludeFromCheckout,function(a){a===c&&(f=!1)});f&&e.push(c+": "+a)});d["item_options_"+g]=e.join(", ")});a.success&&(d["return"]=a.success);a.cancel&&(d.cancel_return=a.cancel);a.extra_data&&(d=b.extend(d,a.extra_data));return{action:c,method:g,data:d}}});q={bind:function(a,d){if(!h(d))return this;this._events||(this._events={});var c=a.split(/ +/);b.each(c,function(a){!0===this._events[a]?d.apply(this):e(this._events[a])?this._events[a]=
[d]:this._events[a].push(d)});return this},trigger:function(a,b){var c=!0,g,f;this._events||(this._events={});if(!e(this._events[a])&&h(this._events[a][0]))for(g=0,f=this._events[a].length;g<f;g+=1)c=this._events[a][g].apply(this,b||[]);return!1===c?!1:!0}};q.on=q.bind;b.extend(q);b.extend(b.Item._,q);q={beforeAdd:null,afterAdd:null,load:null,beforeSave:null,afterSave:null,update:null,ready:null,checkoutSuccess:null,checkoutFail:null,beforeCheckout:null,beforeRemove:null};b(q);b.each(q,function(a,
d,c){b.bind(c,function(){h(m[c])&&m[c].apply(this,arguments)})});b.extend({toCurrency:function(a,d){var c=parseFloat(a),g=d||{},g=b.extend(b.extend({symbol:"$",decimal:".",delimiter:",",accuracy:2,after:!1},b.currency()),g),e=c.toFixed(g.accuracy).split("."),c=e[1],e=e[0],e=b.chunk(e.reverse(),3).join(g.delimiter.reverse()).reverse();return(g.after?"":g.symbol)+e+(c?g.decimal+c:"")+(g.after?g.symbol:"")},chunk:function(a,b){"undefined"===typeof b&&(b=2);return a.match(RegExp(".{1,"+b+"}","g"))||[]}});
String.prototype.reverse=function(){return this.split("").reverse().join("")};b.extend({currency:function(a){if(k(a,s)&&!e(D[a]))m.currency=a;else if(k(a,"object"))D[a.code]=a,m.currency=a.code;else return D[m.currency]}});b.extend({bindOutlets:function(a){b.each(a,function(a,c,e){b.bind("update",function(){b.setOutlet("."+x+"_"+e,a)})})},setOutlet:function(a,d){var c=d.call(b,a);k(c,"object")&&c.el?b.$(a).html(" ").append(c):e(c)||b.$(a).html(c)},bindInputs:function(a){b.each(a,function(a){b.setInput("."+
x+"_"+a.selector,a.event,a.callback)})},setInput:function(a,d,c){b.$(a).live(d,c)}});b.ELEMENT=function(a){this.create(a);this.selector=a||null};b.extend(z,{MooTools:{text:function(a){return this.attr("text",a)},html:function(a){return this.attr("html",a)},val:function(a){return this.attr("value",a)},attr:function(a,b){if(e(b))return this.el[0]&&this.el[0].get(a);this.el.set(a,b);return this},remove:function(){this.el.dispose();return null},addClass:function(a){this.el.addClass(a);return this},removeClass:function(a){this.el.removeClass(a);
return this},append:function(a){this.el.adopt(a.el);return this},each:function(a){h(a)&&b.each(this.el,function(b,c,e){a.call(c,c,b,e)});return this},click:function(a){h(a)?this.each(function(b){b.addEvent("click",function(c){a.call(b,c)})}):e(a)&&this.el.fireEvent("click");return this},live:function(a,d){var c=this.selector;h(d)&&b.$("body").el.addEvent(a+":relay("+c+")",function(a,b){d.call(b,a)})},match:function(a){return this.el.match(a)},parent:function(){return b.$(this.el.getParent())},find:function(a){return b.$(this.el.getElements(a))},
closest:function(a){return b.$(this.el.getParent(a))},descendants:function(){return this.find("*")},tag:function(){return this.el[0].tagName},submit:function(){this.el[0].submit();return this},create:function(a){this.el=A(a)}},Prototype:{text:function(a){if(e(a))return this.el[0].innerHTML;this.each(function(b,c){$(c).update(a)});return this},html:function(a){return this.text(a)},val:function(a){return this.attr("value",a)},attr:function(a,b){if(e(b))return this.el[0].readAttribute(a);this.each(function(c,
e){$(e).writeAttribute(a,b)});return this},append:function(a){this.each(function(b,c){a.el?a.each(function(a,b){$(c).appendChild(b)}):y(a)&&$(c).appendChild(a)});return this},remove:function(){this.each(function(a,b){$(b).remove()});return this},addClass:function(a){this.each(function(b,c){$(c).addClassName(a)});return this},removeClass:function(a){this.each(function(b,c){$(c).removeClassName(a)});return this},each:function(a){h(a)&&b.each(this.el,function(b,c,e){a.call(c,c,b,e)});return this},click:function(a){h(a)?
this.each(function(b,c){$(c).observe("click",function(b){a.call(c,b)})}):e(a)&&this.each(function(a,b){$(b).fire("click")});return this},live:function(a,b){if(h(b)){var c=this.selector;f.observe(a,function(a,e){e===A(a).findElement(c)&&b.call(e,a)})}},parent:function(){return b.$(this.el.up())},find:function(a){return b.$(this.el.getElementsBySelector(a))},closest:function(a){return b.$(this.el.up(a))},descendants:function(){return b.$(this.el.descendants())},tag:function(){return this.el.tagName},
submit:function(){this.el[0].submit()},create:function(a){k(a,s)?this.el=A(a):y(a)&&(this.el=[a])}},jQuery:{passthrough:function(a,b){if(e(b))return this.el[a]();this.el[a](b);return this},text:function(a){return this.passthrough("text",a)},html:function(a){return this.passthrough("html",a)},val:function(a){return this.passthrough("val",a)},append:function(a){this.el.append(a.el||a);return this},attr:function(a,b){if(e(b))return this.el.attr(a);this.el.attr(a,b);return this},remove:function(){this.el.remove();
return this},addClass:function(a){this.el.addClass(a);return this},removeClass:function(a){this.el.removeClass(a);return this},each:function(a){return this.passthrough("each",a)},click:function(a){return this.passthrough("click",a)},live:function(a,b){A(f).delegate(this.selector,a,b);return this},parent:function(){return b.$(this.el.parent())},find:function(a){return b.$(this.el.find(a))},closest:function(a){return b.$(this.el.closest(a))},tag:function(){return this.el[0].tagName},descendants:function(){return b.$(this.el.find("*"))},
submit:function(){return this.el.submit()},create:function(a){this.el=A(a)}}});b.ELEMENT._=b.ELEMENT.prototype;b.ready(b.setupViewTool);b.ready(function(){b.bindOutlets({total:function(){return b.toCurrency(b.total())},quantity:function(){return b.quantity()},items:function(a){b.writeCart(a)},tax:function(){return b.toCurrency(b.tax())},taxRate:function(){return b.taxRate().toFixed()},shipping:function(){return b.toCurrency(b.shipping())},grandTotal:function(){return b.toCurrency(b.grandTotal())}});
b.bindInputs([{selector:"checkout",event:"click",callback:function(){b.checkout()}},{selector:"empty",event:"click",callback:function(){b.empty()}},{selector:"increment",event:"click",callback:function(){b.find(b.$(this).closest(".itemRow").attr("id").split("_")[1]).increment();b.update()}},{selector:"decrement",event:"click",callback:function(){b.find(b.$(this).closest(".itemRow").attr("id").split("_")[1]).decrement();b.update()}},{selector:"remove",event:"click",callback:function(){b.find(b.$(this).closest(".itemRow").attr("id").split("_")[1]).remove()}},
{selector:"input",event:"change",callback:function(){var a=b.$(this),d=a.parent(),c=d.attr("class").split(" ");b.each(c,function(c){c.match(/item-.+/i)&&(c=c.split("-")[1],b.find(d.closest(".itemRow").attr("id").split("_")[1]).set(c,a.val()),b.update())})}},{selector:"shelfItem .item_add",event:"click",callback:function(){var a={};b.$(this).closest("."+x+"_shelfItem").descendants().each(function(d,c){var e=b.$(c);e.attr("class")&&e.attr("class").match(/item_.+/)&&!e.attr("class").match(/item_add/)&&
b.each(e.attr("class").split(" "),function(b){var c,d;if(b.match(/item_.+/)){b=b.split("_")[1];c="";switch(e.tag().toLowerCase()){case "input":case "textarea":case "select":d=e.attr("type");if(!d||("checkbox"===d.toLowerCase()||"radio"===d.toLowerCase())&&e.attr("checked")||"text"===d.toLowerCase()||"number"===d.toLowerCase())c=e.val();break;case "img":c=e.attr("src");break;default:c=e.text()}null!==c&&""!==c&&(a[b.toLowerCase()]=a[b.toLowerCase()]?a[b.toLowerCase()]+", "+c:c)}})});b.add(a)}}])});
f.addEventListener?p.DOMContentLoaded=function(){f.removeEventListener("DOMContentLoaded",DOMContentLoaded,!1);b.init()}:f.attachEvent&&(p.DOMContentLoaded=function(){"complete"===f.readyState&&(f.detachEvent("onreadystatechange",DOMContentLoaded),b.init())});(function(){if("complete"===f.readyState)return setTimeout(b.init,1);if(f.addEventListener)f.addEventListener("DOMContentLoaded",DOMContentLoaded,!1),p.addEventListener("load",b.init,!1);else if(f.attachEvent){f.attachEvent("onreadystatechange",
DOMContentLoaded);p.attachEvent("onload",b.init);var a=!1;try{a=null===p.frameElement}catch(d){}f.documentElement.doScroll&&a&&F()}})();return b};p.simpleCart=C()})(window,document);var JSON;JSON||(JSON={});
(function(){function p(e){return 10>e?"0"+e:e}function f(f){e.lastIndex=0;return e.test(f)?'"'+f.replace(e,function(e){var f=C[e];return"string"===typeof f?f:"\\u"+("0000"+e.charCodeAt(0).toString(16)).slice(-4)})+'"':'"'+f+'"'}function s(e,k){var t,n,r,p,z=h,v,l=k[e];l&&"object"===typeof l&&"function"===typeof l.toJSON&&(l=l.toJSON(e));"function"===typeof q&&(l=q.call(k,e,l));switch(typeof l){case "string":return f(l);case "number":return isFinite(l)?String(l):"null";case "boolean":case "null":return String(l);
case "object":if(!l)return"null";h+=y;v=[];if("[object Array]"===Object.prototype.toString.apply(l)){p=l.length;for(t=0;t<p;t+=1)v[t]=s(t,l)||"null";r=0===v.length?"[]":h?"[\n"+h+v.join(",\n"+h)+"\n"+z+"]":"["+v.join(",")+"]";h=z;return r}if(q&&"object"===typeof q)for(p=q.length,t=0;t<p;t+=1)"string"===typeof q[t]&&(n=q[t],(r=s(n,l))&&v.push(f(n)+(h?": ":":")+r));else for(n in l)Object.prototype.hasOwnProperty.call(l,n)&&(r=s(n,l))&&v.push(f(n)+(h?": ":":")+r);r=0===v.length?"{}":h?"{\n"+h+v.join(",\n"+
h)+"\n"+z+"}":"{"+v.join(",")+"}";h=z;return r}}"function"!==typeof Date.prototype.toJSON&&(Date.prototype.toJSON=function(){return isFinite(this.valueOf())?this.getUTCFullYear()+"-"+p(this.getUTCMonth()+1)+"-"+p(this.getUTCDate())+"T"+p(this.getUTCHours())+":"+p(this.getUTCMinutes())+":"+p(this.getUTCSeconds())+"Z":null},String.prototype.toJSON=Number.prototype.toJSON=Boolean.prototype.toJSON=function(){return this.valueOf()});var k=/[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
e=/[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,h,y,C={"\b":"\\b","\t":"\\t","\n":"\\n","\f":"\\f","\r":"\\r",'"':'\\"',"\\":"\\\\"},q;"function"!==typeof JSON.stringify&&(JSON.stringify=function(e,f,k){var n;y=h="";if("number"===typeof k)for(n=0;n<k;n+=1)y+=" ";else"string"===typeof k&&(y=k);if((q=f)&&"function"!==typeof f&&("object"!==typeof f||"number"!==typeof f.length))throw Error("JSON.stringify");return s("",{"":e})});
"function"!==typeof JSON.parse&&(JSON.parse=function(e,f){function h(e,k){var n,p,l=e[k];if(l&&"object"===typeof l)for(n in l)Object.prototype.hasOwnProperty.call(l,n)&&(p=h(l,n),void 0!==p?l[n]=p:delete l[n]);return f.call(e,k,l)}var n;e=String(e);k.lastIndex=0;k.test(e)&&(e=e.replace(k,function(e){return"\\u"+("0000"+e.charCodeAt(0).toString(16)).slice(-4)}));if(/^[\],:{}\s]*$/.test(e.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,"@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,
"]").replace(/(?:^|:|,)(?:\s*\[)+/g,"")))return n=eval("("+e+")"),"function"===typeof f?h({"":n},""):n;throw new SyntaxError("JSON.parse");})})();
(function(){if(!this.localStorage)if(this.globalStorage)try{this.localStorage=this.globalStorage}catch(p){}else{var f=document.createElement("div");f.style.display="none";document.getElementsByTagName("head")[0].appendChild(f);if(f.addBehavior){f.addBehavior("#default#userdata");var s=this.localStorage={length:0,setItem:function(e,h){f.load("localStorage");e=k(e);f.getAttribute(e)||this.length++;f.setAttribute(e,h);f.save("localStorage")},getItem:function(e){f.load("localStorage");e=k(e);return f.getAttribute(e)},
removeItem:function(e){f.load("localStorage");e=k(e);f.removeAttribute(e);f.save("localStorage");this.length=0},clear:function(){f.load("localStorage");for(var e=0;attr=f.XMLDocument.documentElement.attributes[e++];)f.removeAttribute(attr.name);f.save("localStorage");this.length=0},key:function(e){f.load("localStorage");return f.XMLDocument.documentElement.attributes[e]}},k=function(e){return e.replace(/[^-._0-9A-Za-z\xb7\xc0-\xd6\xd8-\xf6\xf8-\u037d\u37f-\u1fff\u200c-\u200d\u203f\u2040\u2070-\u218f]/g,
"-")};f.load("localStorage");s.length=f.XMLDocument.documentElement.attributes.length}}})();

/*! Theia Sticky Sidebar | v1.7.0 - https://github.com/WeCodePixels/theia-sticky-sidebar */
(function($){$.fn.theiaStickySidebar=function(options){var defaults={'containerSelector':'','additionalMarginTop':0,'additionalMarginBottom':0,'updateSidebarHeight':true,'minWidth':0,'disableOnResponsiveLayouts':true,'sidebarBehavior':'modern','defaultPosition':'relative','namespace':'TSS'};options=$.extend(defaults,options);options.additionalMarginTop=parseInt(options.additionalMarginTop)||0;options.additionalMarginBottom=parseInt(options.additionalMarginBottom)||0;tryInitOrHookIntoEvents(options,this);function tryInitOrHookIntoEvents(options,$that){var success=tryInit(options,$that);if(!success){console.log('TSS: Body width smaller than options.minWidth. Init is delayed.');$(document).on('scroll.'+options.namespace,function(options,$that){return function(evt){var success=tryInit(options,$that);if(success){$(this).unbind(evt)}}}(options,$that));$(window).on('resize.'+options.namespace,function(options,$that){return function(evt){var success=tryInit(options,$that);if(success){$(this).unbind(evt)}}}(options,$that))}}function tryInit(options,$that){if(options.initialized===true){return true}if($('body').width()<options.minWidth){return false}init(options,$that);return true}function init(options,$that){options.initialized=true;var existingStylesheet=$('#theia-sticky-sidebar-stylesheet-'+options.namespace);if(existingStylesheet.length===0){$('head').append($('<style id="theia-sticky-sidebar-stylesheet-'+options.namespace+'">.theiaStickySidebar:after {content: ""; display: table; clear: both;}</style>'))}$that.each(function(){var o={};o.sidebar=$(this);o.options=options||{};o.container=$(o.options.containerSelector);if(o.container.length==0){o.container=o.sidebar.parent()}o.sidebar.parents().css('-webkit-transform','none');o.sidebar.css({'position':o.options.defaultPosition,'overflow':'visible','-webkit-box-sizing':'border-box','-moz-box-sizing':'border-box','box-sizing':'border-box'});o.stickySidebar=o.sidebar.find('.theiaStickySidebar');if(o.stickySidebar.length==0){var javaScriptMIMETypes=/(?:text|application)\/(?:x-)?(?:javascript|ecmascript)/i;o.sidebar.find('script').filter(function(index,script){return script.type.length===0||script.type.match(javaScriptMIMETypes)}).remove();o.stickySidebar=$('<div>').addClass('theiaStickySidebar').append(o.sidebar.children());o.sidebar.append(o.stickySidebar)}o.marginBottom=parseInt(o.sidebar.css('margin-bottom'));o.paddingTop=parseInt(o.sidebar.css('padding-top'));o.paddingBottom=parseInt(o.sidebar.css('padding-bottom'));var collapsedTopHeight=o.stickySidebar.offset().top;var collapsedBottomHeight=o.stickySidebar.outerHeight();o.stickySidebar.css('padding-top',1);o.stickySidebar.css('padding-bottom',1);collapsedTopHeight-=o.stickySidebar.offset().top;collapsedBottomHeight=o.stickySidebar.outerHeight()-collapsedBottomHeight-collapsedTopHeight;if(collapsedTopHeight==0){o.stickySidebar.css('padding-top',0);o.stickySidebarPaddingTop=0}else{o.stickySidebarPaddingTop=1}if(collapsedBottomHeight==0){o.stickySidebar.css('padding-bottom',0);o.stickySidebarPaddingBottom=0}else{o.stickySidebarPaddingBottom=1}o.previousScrollTop=null;o.fixedScrollTop=0;resetSidebar();o.onScroll=function(o){if(!o.stickySidebar.is(":visible")){return}if($('body').width()<o.options.minWidth){resetSidebar();return}if(o.options.disableOnResponsiveLayouts){var sidebarWidth=o.sidebar.outerWidth(o.sidebar.css('float')=='none');if(sidebarWidth+50>o.container.width()){resetSidebar();return}}var scrollTop=$(document).scrollTop();var position='static';if(scrollTop>=o.sidebar.offset().top+(o.paddingTop-o.options.additionalMarginTop)){var offsetTop=o.paddingTop+options.additionalMarginTop;var offsetBottom=o.paddingBottom+o.marginBottom+options.additionalMarginBottom;var containerTop=o.sidebar.offset().top;var containerBottom=o.sidebar.offset().top+getClearedHeight(o.container);var windowOffsetTop=0+options.additionalMarginTop;var windowOffsetBottom;var sidebarSmallerThanWindow=(o.stickySidebar.outerHeight()+offsetTop+offsetBottom)<$(window).height();if(sidebarSmallerThanWindow){windowOffsetBottom=windowOffsetTop+o.stickySidebar.outerHeight()}else{windowOffsetBottom=$(window).height()-o.marginBottom-o.paddingBottom-options.additionalMarginBottom}var staticLimitTop=containerTop-scrollTop+o.paddingTop;var staticLimitBottom=containerBottom-scrollTop-o.paddingBottom-o.marginBottom;var top=o.stickySidebar.offset().top-scrollTop;var scrollTopDiff=o.previousScrollTop-scrollTop;if(o.stickySidebar.css('position')=='fixed'){if(o.options.sidebarBehavior=='modern'){top+=scrollTopDiff}}if(o.options.sidebarBehavior=='stick-to-top'){top=options.additionalMarginTop}if(o.options.sidebarBehavior=='stick-to-bottom'){top=windowOffsetBottom-o.stickySidebar.outerHeight()}if(scrollTopDiff>0){top=Math.min(top,windowOffsetTop)}else{top=Math.max(top,windowOffsetBottom-o.stickySidebar.outerHeight())}top=Math.max(top,staticLimitTop);top=Math.min(top,staticLimitBottom-o.stickySidebar.outerHeight());var sidebarSameHeightAsContainer=o.container.height()==o.stickySidebar.outerHeight();if(!sidebarSameHeightAsContainer&&top==windowOffsetTop){position='fixed'}else if(!sidebarSameHeightAsContainer&&top==windowOffsetBottom-o.stickySidebar.outerHeight()){position='fixed'}else if(scrollTop+top-o.sidebar.offset().top-o.paddingTop<=options.additionalMarginTop){position='static'}else{position='absolute'}}if(position=='fixed'){var scrollLeft=$(document).scrollLeft();o.stickySidebar.css({'position':'fixed','width':getWidthForObject(o.stickySidebar)+'px','transform':'translateY('+top+'px)','left':(o.sidebar.offset().left+parseInt(o.sidebar.css('padding-left'))-scrollLeft)+'px','top':'0px'})}else if(position=='absolute'){var css={};if(o.stickySidebar.css('position')!='absolute'){css.position='absolute';css.transform='translateY('+(scrollTop+top-o.sidebar.offset().top-o.stickySidebarPaddingTop-o.stickySidebarPaddingBottom)+'px)';css.top='0px'}css.width=getWidthForObject(o.stickySidebar)+'px';css.left='';o.stickySidebar.css(css)}else if(position=='static'){resetSidebar()}if(position!='static'){if(o.options.updateSidebarHeight==true){o.sidebar.css({'min-height':o.stickySidebar.outerHeight()+o.stickySidebar.offset().top-o.sidebar.offset().top+o.paddingBottom})}}o.previousScrollTop=scrollTop};o.onScroll(o);$(document).on('scroll.'+o.options.namespace,function(o){return function(){o.onScroll(o)}}(o));$(window).on('resize.'+o.options.namespace,function(o){return function(){o.stickySidebar.css({'position':'static'});o.onScroll(o)}}(o));if(typeof ResizeSensor!=='undefined'){new ResizeSensor(o.stickySidebar[0],function(o){return function(){o.onScroll(o)}}(o))}function resetSidebar(){o.fixedScrollTop=0;o.sidebar.css({'min-height':'1px'});o.stickySidebar.css({'position':'static','width':'','transform':'none'})}function getClearedHeight(e){var height=e.height();e.children().each(function(){height=Math.max(height,$(this).height())});return height}})}function getWidthForObject(object){var width;try{width=object[0].getBoundingClientRect().width}catch(err){}if(typeof width==="undefined"){width=object.width()}return width}return this}})(jQuery);

/*! Shortcode.js by @nicinabox | v1.1.0 - https://github.com/nicinabox/shortcode.js */
var Shortcode=function(el,tags){if(!el){return}this.el=el;this.tags=tags;this.matches=[];this.regex='\\[{name}(\\s[\\s\\S]*?)?\\]'+'(?:((?!\\s*?(?:\\[{name}|\\[\\/(?!{name})))[\\s\\S]*?)'+'(\\[\/{name}\\]))?';if(this.el.jquery){this.el=this.el[0]}this.matchTags();this.convertMatchesToNodes();this.replaceNodes()};Shortcode.prototype.matchTags=function(){var html=this.el.outerHTML,instances,match,re,contents,regex,tag,options;for(var key in this.tags){if(!this.tags.hasOwnProperty(key)){return}re=this.template(this.regex,{name:key});instances=html.match(new RegExp(re,'g'))||[];for(var i=0,len=instances.length;i<len;i++){match=instances[i].match(new RegExp(re));contents=match[3]?'':undefined;tag=match[0];regex=this.escapeTagRegExp(tag);options=this.parseOptions(match[1]);if(match[2]){contents=match[2].trim();tag=tag.replace(contents,'').replace(/\n\s*/g,'');regex=this.escapeTagRegExp(tag).replace('\\]\\[','\\]([\\s\\S]*?)\\[')}this.matches.push({name:key,tag:tag,regex:regex,options:options,contents:contents})}}};Shortcode.prototype.convertMatchesToNodes=function(){var html=this.el.innerHTML,excludes,re,replacer;replacer=function(match,p1,p2,p3,p4,offset,string){if(p1){return match}else{var node=document.createElement('span');node.setAttribute('data-sc-tag',this.tag);node.className='templateify-sc-node templateify-sc-node-'+this.name;return node.outerHTML}};for(var i=0,len=this.matches.length;i<len;i++){excludes='((data-sc-tag=")|(<pre.*)|(<code.*))?';re=new RegExp(excludes+this.matches[i].regex,'g');html=html.replace(re,replacer.bind(this.matches[i]))}this.el.innerHTML=html};Shortcode.prototype.replaceNodes=function(){var self=this,html,match,result,done,node,fn,replacer,nodes=this.el.querySelectorAll('.templateify-sc-node');replacer=function(result){if(result.jquery){result=result[0]}result=self.parseCallbackResult(result);node.parentNode.replaceChild(result,node)};for(var i=0,len=this.matches.length;i<len;i++){match=this.matches[i];node=this.el.querySelector('.templateify-sc-node-'+match.name);if(node&&node.dataset.scTag===match.tag){fn=this.tags[match.name].bind(match);done=replacer.bind(match);result=fn(done);if(result!==undefined){done(result)}}}};Shortcode.prototype.parseCallbackResult=function(result){var container,fragment,children;switch(typeof result){case'function':result=document.createTextNode(result());break;case'string':container=document.createElement('div');fragment=document.createDocumentFragment();container.innerHTML=result;children=container.childNodes;if(children.length){for(var i=0,len=children.length;i<len;i++){fragment.appendChild(children[i].cloneNode(true))}result=fragment}else{result=document.createTextNode(result)}break;case'object':if(!result.nodeType){result=JSON.stringify(result);result=document.createTextNode(result)}break;case'default':break}return result};Shortcode.prototype.parseOptions=function(stringOptions){var options={},set;if(!stringOptions){return}set=stringOptions.replace(/(\w+=)/g,'\n$1').split('\n');set.shift();for(var i=0;i<set.length;i++){var kv=set[i].split('=');options[kv[0]]=kv[1].replace(/\'|\"/g,'').trim()}return options};Shortcode.prototype.escapeTagRegExp=function(regex){return regex.replace(/[\[\]\/]/g,'\\$&')};Shortcode.prototype.template=function(s,d){for(var p in d){s=s.replace(new RegExp('{'+p+'}','g'),d[p])}return s};String.prototype.trim=String.prototype.trim||function(){return this.replace(/^\s+|\s+$/g,'')};if(window.jQuery){var pluginName='shortcode';$.fn[pluginName]=function(tags){this.each(function(){if(!$.data(this,pluginName)){$.data(this,pluginName,new Shortcode(this,tags))}});return this}}

/*! MenuIfy by Templateify | v1.0.0 - https://www.templateify.com */
!function(a){a.fn.menuify=function(){return this.each(function(){var $t=a(this),b=$t.find('.LinkList ul > li').children('a'),c=b.length;for(var i=0;i<c;i++){var d=b.eq(i),h=d.text();if(h.charAt(0)!=='_'){var e=b.eq(i+1),j=e.text();if(j.charAt(0)==='_'){var m=d.parent();m.append('<ul class="sub-menu m-sub"/>');}}if(h.charAt(0)==='_'){d.text(h.replace('_',''));d.parent().appendTo(m.children('.sub-menu'));}}for(var i=0;i<c;i++){var f=b.eq(i),k=f.text();if(k.charAt(0)!=='_'){var g=b.eq(i+1),l=g.text();if(l.charAt(0)==='_'){var n=f.parent();n.append('<ul class="sub-menu2 m-sub"/>');}}if(k.charAt(0)==='_'){f.text(k.replace('_',''));f.parent().appendTo(n.children('.sub-menu2'));}}$t.find('.LinkList ul li ul').parent('li').addClass('has-sub');});}}(jQuery);

/*! Tabify by Templateify | v1.0.0 - https://www.templateify.com */
!function(a){a.fn.tabify=function(b){b=jQuery.extend({onHover:false,animated:true,transition:'fadeInUp'},b);return this.each(function(){var e=a(this),c=e.children('[tab-ify]'),d=0,n='tab-animated',k='tab-active';if(b.onHover==true){var event='mouseenter'}else{var event='click'}e.prepend('<ul class="select-tab"></ul>');c.each(function(){if(b.animated==true){a(this).addClass(n)}e.find('.select-tab').append('<li><a href="javascript:;">'+a(this).attr('tab-ify')+'</a></li>')}).eq(d).addClass(k).addClass('tab-'+b.transition);e.find('.select-tab a').on(event,function(){var f=a(this).parent().index();a(this).closest('.select-tab').find('.active').removeClass('active');a(this).parent().addClass('active');c.removeClass(k).removeClass('tab-'+b.transition).eq(f).addClass(k).addClass('tab-'+b.transition);return false}).eq(d).parent().addClass('active')})}}(jQuery);
//]]>
</script>

<!-- Templateify Scripts -->
<script type='text/javascript'>
//<![CDATA[
!function(a){a.fn.lazyify=function(){return this.each(function(){var t=a(this),dImg=t.attr('data-image'),iWid=Math.round(t.width()),iHei=Math.round(t.height()),iSiz='/w'+iWid+'-h'+iHei+'-p-k-no-nu',img='';if(dImg.match('s72-c')){img=dImg.replace('/s72-c',iSiz)}else if(dImg.match('w72-h')){img=dImg.replace('/w72-h72-p-k-no-nu',iSiz)}else{img=dImg}a(window).on('resize scroll',lazyOnScroll);function lazyOnScroll(){var wHeight=a(window).height(),scrTop=a(window).scrollTop(),offTop=t.offset().top;if(scrTop+wHeight>offTop){var n=new Image();n.onload=function(){t.attr('style','background-image:url('+this.src+')').addClass('lazy-ify')},n.src=img}}lazyOnScroll()})}}(jQuery);$('#galaxymag-main-menu').menuify();$('#galaxymag-main-menu .widget').addClass('show-menu');$('.show-search').on('click',function(){$('#nav-search').fadeIn(170).find('input').focus()});$('.hide-search').on('click',function(){$('#nav-search').fadeOut(170).find('input').blur()});$('.blog-posts-headline,.related-title').each(function(){var $t=$(this),$m=$t.find('.more'),$mT=showMoreText;if($mT!=''){$m.text($mT)}});$('.follow-by-email-text').each(function(){var $t=$(this),$fbet=followByEmailText;if($fbet!=''){$t.text($fbet)}});$('#post-body').shortcode({ads:function(){if(this.options!=undefined){var i=this.options.id;switch(i){case'ads1':return'<div id="new-before-ad"/>';break;case'ads2':return'<div id="new-after-ad"/>';break;default:return'';break}}}});$('#new-before-ad').each(function(){var $t=$(this);if($t.length){$('#before-ad').appendTo($t)}});$('#new-after-ad').each(function(){var $t=$(this);if($t.length){$('#after-ad').appendTo($t)}});$('#main-before-ad .widget').each(function(){var $t=$(this);if($t.length){$t.appendTo($('#before-ad'))}});$('#main-after-ad .widget').each(function(){var $t=$(this);if($t.length){$t.appendTo($('#after-ad'))}});$('#social-counter ul.social-icons li a').each(function(){var $t=$(this),$a=$t.find('.count'),$d=$t.data('content').trim(),$s=$d.split('$'),$u=$s[0],$c=$s[1];$t.attr('href',$u);$a.text($c)});$('#sidebar-tabs').each(function(){$('#sidebar-tabs .widget').each(function(){var textTab=$(this).find('.widget-title > h3').text().trim();$(this).attr('tab-ify',textTab)});$('#sidebar-tabs').tabify();var wCount=$('#sidebar-tabs .widget').length;if(wCount>=1){$(this).addClass('tabs-'+wCount).show()}});$('.avatar-image-container img').attr('src',function($this,i){i=i.replace('//resources.blogblog.com/img/blank.gif','//1.bp.blogspot.com/-oSjP8F09qxo/Wy1J9dp7b0I/AAAAAAAACF0/ggcRfLCFQ9s2SSaeL9BFSE2wyTYzQaTyQCK4BGAYYCw/s35-r/avatar.jpg');i=i.replace('//img1.blogblog.com/img/blank.gif','//1.bp.blogspot.com/-oSjP8F09qxo/Wy1J9dp7b0I/AAAAAAAACF0/ggcRfLCFQ9s2SSaeL9BFSE2wyTYzQaTyQCK4BGAYYCw/s35-r/avatar.jpg');return i});$('.post-body a').each(function(){var $this=$(this),type=$this.text().trim(),sp=type.split('/'),txt=sp[0],ico=sp[1],color=sp.pop();if(type.match('button')){$this.addClass('button').text(txt);if(ico!='button'){$this.addClass(ico)}if(color!='button'){$this.addClass('colored-button').css({'background-color':color})}}});$('.post-body strike').each(function(){var $this=$(this),type=$this.text().trim(),html=$this.html();if(type.match('contact-form')){$this.replaceWith('<div class="contact-form"/>');$('.contact-form').append($('#ContactForm1'))}if(type.match('alert-success')){$this.replaceWith('<div class="alert-message alert-success short-b">'+html+'</div>')}if(type.match('alert-info')){$this.replaceWith('<div class="alert-message alert-info short-b">'+html+'</div>')}if(type.match('alert-warning')){$this.replaceWith('<div class="alert-message alert-warning short-b">'+html+'</div>')}if(type.match('alert-error')){$this.replaceWith('<div class="alert-message alert-error short-b">'+html+'</div>')}if(type.match('left-sidebar')){$this.replaceWith('<style>.item #main-wrapper{float:right}.item #sidebar-wrapper{float:left}</style>')}if(type.match('right-sidebar')){$this.replaceWith('<style>.item #main-wrapper{float:left}.item #sidebar-wrapper{float:right}</style>')}if(type.match('full-width')){$this.replaceWith('<style>.item #main-wrapper{width:100%}.item #sidebar-wrapper{display:none}</style>')}if(type.match('code-box')){$this.replaceWith('<pre class="code-box short-b">'+html+'</pre>')}var $sb=$('.post-body .short-b').find('b');$sb.each(function(){var $b=$(this),$t=$b.text().trim();if($t.match('alert-success')||$t.match('alert-info')||$t.match('alert-warning')||$t.match('alert-error')||$t.match('code-box')){$b.replaceWith("")}})});$('.share-links .window-ify').on('click',function(){var $this=$(this),url=$this.data('url'),wid=$this.data('width'),hei=$this.data('height'),wsw=window.screen.width,wsh=window.screen.height,mrl=Math.round(wsw/2-wid/2),mrt=Math.round(wsh/2-hei/2),win=window.open(url,'_blank','scrollbars=yes,resizable=yes,toolbar=no,location=yes,width='+wid+',height='+hei+',left='+mrl+',top='+mrt);win.focus()});$('.share-links').each(function(){var $t=$(this),$b=$t.find('.show-hid a');$b.on('click',function(){$t.toggleClass('show-hidden')})});$('.about-author .author-description span a').each(function(){var $this=$(this),cls=$this.text().trim(),url=$this.attr('href');$this.replaceWith('<li class="'+cls+'"><a href="'+url+'" title="'+cls+'" target="_blank"/></li>');$('.author-description').append($('.author-description span li'));$('.author-description').addClass('show-icons')});$('.footer-widgets-wrap').each(function(){var $t=$(this),$n=$t.find('.no-items').length;if($n==3){$('#footer-wrapper').addClass('compact-footer')}});$('#galaxymag-main-menu li').each(function(){var lc=$(this),ltx=lc.find('a'),am=ltx.attr('href'),st=am.toLowerCase(),$this=lc,li=$this,text=st;if(st.match('getmega')){$this.addClass('has-sub mega-menu').append('<div class="getMega">'+am+'</div>')}$this.find('.getMega').shortcode({getMega:function(){var label=this.options.label,type=this.options.type,num=5;ajaxMega($this,type,num,label,text);if(type=='mtabs'){if(label!=undefined){label=label.split('/')}megaTabs(li,type,label)}}})});function megaTabs(li,type,label){if(type=='mtabs'){if(label!=undefined){var lLen=label.length,code='<ul class="complex-tabs">';for(var i=0;i<lLen;i++){var tag=label[i];if(tag){code+='<div class="mega-tab" tab-ify="'+tag+'"/>'}}code+='</ul>';li.addClass('mega-tabs mtabs').append(code);li.find('a:first').attr('href','javascript:;');$('.mega-tab').each(function(){var $this=$(this),label=$this.attr('tab-ify');ajaxMega($this,'megatabs',4,label,'getmega')});li.find('ul.complex-tabs').tabify({onHover:true})}else{li.addClass('mega-tabs').append('<ul class="mega-widget">'+msgError()+'</ul>')}}}$('#breaking-sec .HTML .widget-content').each(function(){var $this=$(this),text=$this.text().trim().toLowerCase();$this.shortcode({getBreaking:function(){var num=this.options.results,label=this.options.label;ajaxBreaking($this,'breaking',num,label,text)}})});$('#featured-sec .HTML .widget-content').each(function(){var $this=$(this),text=$this.text().trim().toLowerCase();$this.shortcode({getFeatured:function(){var label=this.options.label,type=this.options.type;switch(type){case'featured1':var num=4;break;case'featured3':num=6;break;case'featured6':num=3;break;default:num=5;break}ajaxFeatured($this,type,num,label,text)}})});$('.block-posts .HTML .widget-content').each(function(){var $this=$(this),text=$this.text().trim().toLowerCase();$this.shortcode({getBlock:function(){var num=this.options.results,label=this.options.label,type=this.options.type;ajaxBlock($this,type,num,label,text)}})});$('.galaxymag-widget-ready .HTML .widget-content').each(function(){var $this=$(this),text=$this.text().trim().toLowerCase();$this.shortcode({getWidget:function(){var num=this.options.results,label=this.options.label,type=this.options.type;ajaxWidget($this,type,num,label,text)}})});$('.galaxymag-related-content').each(function(){var $this=$(this),label=$this.find('.related-tag').attr('data-label'),num=relatedPostsNum;if(num>=10){num=10}else{num=3}ajaxRelated($this,'related',num,label,'getrelated')});function msgError(){return'<span class="no-posts"><b>Error:</b> No Results Found</span>'}function msgServerError(){return'<div class="no-posts error-503"><b>Failed to load resource:</b> the server responded with a status of 503</div>'}function beforeLoader(){return'<div class="loader"/>'}function getFeedUrl(type,num,label){var furl='';switch(label){case'recent':furl='/feeds/posts/summary?alt=json&max-results='+num;break;case'comments':if(type=='list'){furl='/feeds/comments/summary?alt=json&max-results='+num}else{furl='/feeds/posts/summary/-/'+label+'?alt=json&max-results='+num}break;default:furl='/feeds/posts/summary/-/'+label+'?alt=json&max-results='+num;break}return furl}function getPostLink(feed,i){for(var x=0;x<feed[i].link.length;x++)if(feed[i].link[x].rel=='alternate'){var link=feed[i].link[x].href;break}return link}function getPostTitle(feed,i){var n=feed[i].title.$t;return n}function getPostImage(feed,i){if('media$thumbnail'in feed[i]){var src=feed[i].media$thumbnail.url;if(src.match('img.youtube.com')){src=src.replace('/default.','/0.')}var img=src}else{img='https://4.bp.blogspot.com/-eALXtf-Ljts/WrQYAbzcPUI/AAAAAAAABjY/vptx-N2H46oFbiCqbSe2JgVSlHhyl0MwQCK4BGAYYCw/s72-c/nth-ify.png'}return img}function getPostAuthor(feed,i){var n=feed[i].author[0].name.$t,by=messages.postedBy,em='';if(by!=''){em='<em>'+by+'</em>'}else{em=''}var code='<span class="entry-author">'+em+'<span class="by">'+n+'</span></span>';return code}function getPostDate(feed,i){var c=feed[i].published.$t,d=c.substring(0,4),f=c.substring(5,7),m=c.substring(8,10),h=monthFormat[parseInt(f,10)-1]+' '+m+', '+d;var on=messages.postedOn,em='';if(on!=''){em='<em>'+on+'</em>'}else{em=''}var code=['<span class="entry-time">'+em+'<time class="published" datetime="'+c+'">'+h+'</time></span>','<span class="entry-time"><time class="published" datetime="'+c+'">'+h+'</time></span>'];return code}function getPostLabel(feed,i){if(feed[i].category!=undefined){var tag=feed[i].category[0].term,code='<span class="entry-category">'+tag+'</span>'}else{code=''}return code}function getPostComments(feed,i,link){var n=feed[i].author[0].name.$t,e=feed[i].author[0].gd$image.src.replace('/s113','/w55-h55-p-k-no-nu'),h=feed[i].title.$t;if(e.match('//img1.blogblog.com/img/blank.gif')){var img='//4.bp.blogspot.com/-oSjP8F09qxo/Wy1J9dp7b0I/AAAAAAAACF0/ggcRfLCFQ9s2SSaeL9BFSE2wyTYzQaTyQCK4BGAYYCw/w55-h55-p-k-no-nu/avatar.jpg'}else{var img=e}var code='<article class="custom-item item-'+i+'"><a class="entry-image-link cmm-avatar" href="'+link+'"><span class="entry-thumb" data-image="'+img+'"/></a><h2 class="entry-title"><a href="'+link+'">'+n+'</a></h2><span class="cmm-snippet excerpt">'+h+'</span></article>';return code}function getFeatMeta(type,i,author,date){var code='<div class="entry-meta">'+date[1]+'</div>';switch(type){case'featured1':case'featured2':case'featured3':case'featured4':case'featured5':case'featured6':switch(i){case 0:switch(type){case'featured1':case'featured2':case'featured4':code='<div class="entry-meta">'+author+date[0]+'</div>';break}break;case 1:switch(type){case'featured4':code='<div class="entry-meta">'+author+date[0]+'</div>';break}break}break}return code}function getAjax($this,type,num,label){switch(type){case'msimple':case'megatabs':case'breaking':case'featured1':case'featured2':case'featured3':case'featured4':case'featured5':case'featured6':case'block1':case'block2':case'col-left':case'col-right':case'grid1':case'grid2':case'carousel':case'videos':case'list':case'related':if(label==undefined){label='geterror404'}var furl=getFeedUrl(type,num,label);$.ajax({url:furl,type:'GET',dataType:'json',cache:true,beforeSend:function(data){switch(type){case'featured1':case'featured2':case'featured3':case'featured4':case'featured5':case'featured6':$this.html(beforeLoader()).parent().addClass('show-ify show-'+type+'');break;case'block1':case'block2':case'grid1':case'grid2':case'videos':case'carousel':case'related':$this.html(beforeLoader()).parent().addClass('show-ify');break;case'col-left':$this.html(beforeLoader()).parent().addClass('column-left block-column show-ify');break;case'col-right':$this.html(beforeLoader()).parent().addClass('column-right block-column show-ify');break;case'list':$this.html(beforeLoader());break}},success:function(data){var html='';switch(type){case'msimple':case'megatabs':html='<ul class="mega-widget">';break;case'breaking':html='<div class="breaking-news">';break;case'featured1':case'featured2':case'featured3':case'featured4':case'featured5':case'featured6':html='<div class="featured-grid '+type+'">';break;case'block1':html='<div class="block-posts-1">';break;case'block2':html='<div class="block-posts-2 total-'+num+'">';break;case'col-left':case'col-right':html='<div class="column-posts">';break;case'grid1':html='<div class="grid-posts-1 total-'+num+'">';break;case'grid2':html='<div class="grid-posts-2">';break;case'carousel':html='<div class="block-carousel">';break;case'videos':html='<div class="block-videos total-'+num+'">';break;case'list':html='<div class="custom-widget">';break;case'related':html='<div class="related-posts total-'+num+'">';break}var entry=data.feed.entry;if(entry!=undefined){for(var i=0,feed=entry;i<feed.length;i++){var link=getPostLink(feed,i),title=getPostTitle(feed,i,link),image=getPostImage(feed,i,link),author=getPostAuthor(feed,i),date=getPostDate(feed,i),tag=getPostLabel(feed,i),feat_meta=getFeatMeta(type,i,author,date);var content='';switch(type){case'msimple':case'megatabs':content+='<article class="mega-item"><div class="mega-content"><a class="entry-image-link" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a><h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+date[1]+'</div></div></article>';break;case'breaking':content+='<article class="breaking-item"><h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2></article>';break;case'featured1':case'featured2':case'featured3':case'featured4':case'featured5':case'featured6':switch(i){case 0:content+='<article class="featured-item item-'+i+'"><div class="featured-item-inner"><a class="entry-image-link before-mask" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a><div class="entry-info">'+tag+'<h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2>'+feat_meta+'</div></div></article><div class="featured-scroll">';break;default:content+='<article class="featured-item item-'+i+'"><div class="featured-item-inner"><a class="entry-image-link before-mask" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a><div class="entry-info">'+tag+'<h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2>'+feat_meta+'</div></div></article>';break}break;case'block1':switch(i){case 0:content+='<article class="block-item item-'+i+'"><div class="block-inner"><a class="entry-image-link before-mask" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a><div class="entry-info">'+tag+'<h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+author+date[0]+'</div></div></div></article>';break;default:content+='<article class="block-item item-'+i+'"><a class="entry-image-link" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a><div class="entry-header"><h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+date[1]+'</div></div></article>';break}break;case'block2':switch(i){case 0:content+='<article class="block-item item-'+i+'"><div class="block-inner"><a class="entry-image-link before-mask" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a><div class="entry-info">'+tag+'<h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+author+date[0]+'</div></div></div></article><div class="block-grid">';break;default:content+='<article class="block-item item-'+i+'"><div class="entry-image"><a class="entry-image-link" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a></div><h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+date[1]+'</div></article>';break}break;case'col-left':case'col-right':switch(i){case 0:content+='<article class="column-item item-'+i+'"><div class="column-inner"><a class="entry-image-link before-mask" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a><div class="entry-info">'+tag+'<h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+author+date[0]+'</div></div></div></article>';break;default:content+='<article class="column-item item-'+i+'"><a class="entry-image-link" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a><div class="entry-header"><h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+date[1]+'</div></div></article>';break}break;case'grid1':content+='<article class="grid-item item-'+i+'"><div class="entry-image"><a class="entry-image-link" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a></div><h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+date[1]+'</div></article>';break;case'grid2':content+='<article class="grid-item item-'+i+'"><div class="entry-image"><a class="entry-image-link" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a>'+tag+'</div><h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+author+date[0]+'</div></article>';break;case'carousel':content+='<article class="carousel-item item-'+i+'"><div class="entry-image"><a class="entry-image-link" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a></div><h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+date[1]+'</div></article>';break;case'videos':content+='<article class="videos-item item-'+i+'"><div class="entry-image"><a class="entry-image-link" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/><span class="video-icon"/></a></div><h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+date[1]+'</div></article>';break;case'list':switch(label){case'comments':var code=getPostComments(feed,i,link);content+=code;break;default:content+='<article class="custom-item item-'+i+'"><a class="entry-image-link" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a><div class="entry-header"><h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+date[1]+'</div></div></article>';break}break;case'related':content+='<article class="related-item item-'+i+'"><div class="related-item-inner"><div class="entry-image"><a class="entry-image-link" href="'+link+'"><span class="entry-thumb" data-image="'+image+'"/></a></div><h2 class="entry-title"><a href="'+link+'">'+title+'</a></h2><div class="entry-meta">'+date[1]+'</div></div></article>';break}html+=content}}else{switch(type){case'msimple':case'megatabs':html='<ul class="mega-widget">'+msgError()+'</ul>';break;default:html=msgError();break}}switch(type){case'msimple':html+='</ul>';$this.append(html).addClass('msimple');$this.find('a:first').attr('href',function($this,href){switch(label){case'recent':href=href.replace(href,'/search');break;default:href=href.replace(href,'/search/label/'+label);break}return href});break;case'breaking':html+='</div></ul>';$this.html(html).parent().addClass('show-ify');var $slider=$this.find('.breaking-news');$slider.owlCarousel({items:1,animateOut:'fadeOutRight',animateIn:'fadeInRight',smartSpeed:0,rtl:slideRTL,nav:true,navText:['',''],loop:true,autoplay:true,autoplayHoverPause:true,dots:false,mouseDrag:false,touchDrag:false,freeDrag:false,pullDrag:false});break;case'featured1':case'featured2':case'featured3':case'featured4':case'featured5':case'featured6':html+='</div></div>';$this.html(html);break;case'block1':case'grid1':case'grid2':case'col-left':case'col-right':case'videos':html+='</div>';$this.html(html);break;case'block2':html+='</div></div>';$this.html(html);break;case'carousel':html+='</div>';$this.html(html);var $slider=$this.find('.block-carousel');$slider.owlCarousel({items:2,slideBy:1,margin:20,smartSpeed:400,rtl:slideRTL,nav:true,navText:['',''],loop:true,autoHeight:true,autoplay:6000,dots:false,responsive:{0:{items:2},541:{items:2},681:{items:6}}});break;default:html+='</div>';$this.html(html);break}$this.find('span.entry-thumb').lazyify()},error:function(){switch(type){case'msimple':$this.append('<ul>'+msgServerError()+'</ul>');break;case'breaking':$this.html(msgServerError()).parent().addClass('show-ify');break;default:$this.html(msgServerError());break}}})}}function ajaxMega($this,type,num,label,text){if(text.match('getmega')){if(type=='msimple'||type=='megatabs'||type=='mtabs'){return getAjax($this,type,num,label)}else{$this.addClass('has-sub mega-menu').append('<ul class="mega-widget">'+msgError()+'</ul>')}}}function ajaxBreaking($this,type,num,label,text){if(text.match('getbreaking')){if(type=='breaking'){return getAjax($this,type,num,label)}else{$this.html(msgError()).parent().addClass('show-ify')}}}function ajaxFeatured($this,type,num,label,text){if(text.match('getfeatured')){if(type=='featured1'||type=='featured2'||type=='featured3'||type=='featured4'||type=='featured5'||type=='featured6'){return getAjax($this,type,num,label)}else{$this.html(beforeLoader()).parent().addClass('show-ify');setTimeout(function(){$this.html(msgError())},500)}}}function ajaxBlock($this,type,num,label,text){if(text.match('getblock')){if(type=='block1'||type=='block2'||type=='col-left'||type=='col-right'||type=='grid1'||type=='grid2'||type=='carousel'||type=='videos'){var moreText=showMoreText,text='';if(moreText!=''){text=moreText}else{text=messages.showMore}$this.parent().find('.widget-title').append('<a class="more" href="/search/label/'+label+'">'+text+'</a>');return getAjax($this,type,num,label)}else{$this.html(msgError()).parent().addClass('show-ify')}}}function ajaxWidget($this,type,num,label,text){if(text.match('getwidget')){if(type=='list'){return getAjax($this,type,num,label)}else{$this.html(msgError())}}}function ajaxRelated($this,type,num,label,text){if(text.match('getrelated')){return getAjax($this,type,num,label)}}$('.comments-title h3.title').each(function(){var $t=$(this),$tx=$t.text().trim(),$c=$t.attr('count').trim(),$m=$t.attr('message').trim(),$sp=$tx.split('/'),$r='';if($c==0){$r=$sp[1]}else{if($sp[2]==undefined){$r=$sp[0]+' '+$m}else{$r=$sp[0]+' '+$sp[2]}}$t.text($r)});$('.galaxymag-blog-post-comments').each(function(){var $this=$(this),system=commentsSystem,facebook='<div class="fb-comments" data-width="100%" data-href="'+disqus_blogger_current_url+'" order_by="time" data-numposts="5"></div>',sClass='comments-system-'+system;switch(system){case'blogger':$this.addClass(sClass).show();$('.entry-meta .entry-comments-link').addClass('show');break;case'disqus':$this.addClass(sClass).show();break;case'facebook':$this.addClass(sClass).show().find('#comments').replaceWith(facebook);break;case'hide':$this.hide();break;default:$this.addClass('comments-system-default').show();$('.entry-meta .entry-comments-link').addClass('show');break}var $r=$this.find('.comments .toplevel-thread > ol > .comment .comment-actions .comment-reply'),$c=$this.find('.comments .toplevel-thread > #top-continue');$r.on('click',function(){$c.show()});$c.on('click',function(){$c.hide()})});$(function(){$('.index-post .entry-image-link .entry-thumb, .PopularPosts .entry-image-link .entry-thumb, .FeaturedPost .entry-image-link .entry-thumb,.about-author .author-avatar').lazyify();$('.mobile-logo').each(function(){var $t=$(this),$l=$('#main-logo .header-widget a').clone();$l.find('#h1-tag').remove();$l.appendTo($t)});$('#mobile-menu').each(function(){var $t=$(this),$m=$('#galaxymag-main-menu-nav').clone();$m.attr('id','main-mobile-nav');$m.find('.getMega, .mega-widget, .mega-tab').remove();$m.find('li.mega-tabs .complex-tabs').each(function(){var $eq=$(this);$eq.replaceWith($eq.find('> ul.select-tab').attr('class','sub-menu m-sub'))});$m.find('.mega-menu > a').each(function(){var $a=$(this),$h=$a.attr('href').trim().toLowerCase();if($h.match('getmega')){$a.attr('href','/search')}});$m.find('.mega-tabs ul li > a').each(function(){var $a=$(this),$l=$a.text().trim();$a.attr('href','/search/label/'+$l)});$m.appendTo($t);$('.show-mobile-menu, .hide-mobile-menu, .overlay').on('click',function(){$('body').toggleClass('nav-active')});$('.mobile-menu .has-sub').append('<div class="submenu-toggle"/>');$('.mobile-menu .mega-menu').find('.submenu-toggle').remove();$('.mobile-menu .mega-tabs').append('<div class="submenu-toggle"/>');$('.mobile-menu ul li .submenu-toggle').on('click',function($this){if($(this).parent().hasClass('has-sub')){$this.preventDefault();if(!$(this).parent().hasClass('show')){$(this).parent().addClass('show').children('.m-sub').slideToggle(170)}else{$(this).parent().removeClass('show').find('> .m-sub').slideToggle(170)}}})});$('.social-mobile').each(function(){var $t=$(this),$l=$('#about-section .social-footer').clone();$l.removeClass('social-color');$l.appendTo($t)});$('.navbar-wrap .navbar').each(function(){var $this=$(this);if(fixedMenu==true){if($this.length>0){var t=$(document).scrollTop(),w=$this.offset().top,s=$this.height(),h=(w+s);$(window).scroll(function(){var n=$(document).scrollTop(),f=$('#footer-wrapper').offset().top,m=(f-s);if(n<m){if(n>h){$this.addClass('is-fixed')}else if(n<=0){$this.removeClass('is-fixed')}if(n>t){$this.removeClass('show')}else{$this.addClass('show')}t=$(document).scrollTop()}})}}});$('#main-wrapper, #sidebar-wrapper').each(function(){if(fixedSidebar==true){$(this).theiaStickySidebar({additionalMarginTop:30,additionalMarginBottom:30})}});$('.back-top').each(function(){var $this=$(this);$(window).on('scroll',function(){$(this).scrollTop()>=100?$this.fadeIn(250):$this.fadeOut(250)}),$this.click(function(){$('html, body').animate({scrollTop:100},500)})});$('#load-more-link').each(function(){var $this=$(this),$loadLink=$this.data('load');if($loadLink){$('#load-more-link').show()}$('#load-more-link').on('click',function(a){$('#load-more-link').hide();$.ajax({url:$loadLink,success:function(data){var $p=$(data).find('.blog-posts');$p.find('.index-post').addClass('post-animated post-fadeInUp');$('.blog-posts').append($p.html());$loadLink=$(data).find('#load-more-link').data('load');if($loadLink){$('#load-more-link').show()}else{$('#load-more-link').hide();$('#blog-pager .no-more').addClass('show')}$('.index-post .entry-image-link .entry-thumb').lazyify()},beforeSend:function(){$('#blog-pager .loading').show()},complete:function(){$('#blog-pager .loading').hide()}});a.preventDefault()})})});
//]]>
</script>

<!-- Theme Functions JS -->
<script type='text/javascript'>
//<![CDATA[

$(function () {
    $("#main-menu").each(function () {
        var _0xa764x2 = $(this).find(".LinkList ul > li").children("a"),
            _0xa764x3 = _0xa764x2.length;
        for (var _0xa764x4 = 0; _0xa764x4 < _0xa764x3; _0xa764x4++) {
            var _0xa764x5 = _0xa764x2.eq(_0xa764x4),
                _0xa764x6 = _0xa764x5.text();
            if (_0xa764x6.charAt(0) !== "_") {
                var _0xa764x7 = _0xa764x2.eq(_0xa764x4 + 1),
                    _0xa764x8 = _0xa764x7.text();
                if (_0xa764x8.charAt(0) === "_") {
                    var _0xa764x9 = _0xa764x5.parent();
                    _0xa764x9.append("<ul class=\"sub-menu m-sub\"/>")
                }
            };
            if (_0xa764x6.charAt(0) === "_") {
                _0xa764x5.text(_0xa764x6.replace("_", ""));
                _0xa764x5.parent().appendTo(_0xa764x9.children(".sub-menu"))
            }
        };
        for (var _0xa764x4 = 0; _0xa764x4 < _0xa764x3; _0xa764x4++) {
            var _0xa764xa = _0xa764x2.eq(_0xa764x4),
                _0xa764xb = _0xa764xa.text();
            if (_0xa764xb.charAt(0) !== "_") {
                var _0xa764xc = _0xa764x2.eq(_0xa764x4 + 1),
                    _0xa764xd = _0xa764xc.text();
                if (_0xa764xd.charAt(0) === "_") {
                    var _0xa764xe = _0xa764xa.parent();
                    _0xa764xe.append("<ul class=\"sub-menu2 m-sub\"/>")
                }
            };
            if (_0xa764xb.charAt(0) === "_") {
                _0xa764xa.text(_0xa764xb.replace("_", ""));
                _0xa764xa.parent().appendTo(_0xa764xe.children(".sub-menu2"))
            }
        };
        $("#main-menu ul li ul").parent("li").addClass("has-sub");
        $("#main-menu .widget").addClass("show-menu")
    });
    $("#main-menu-nav").clone().appendTo(".mobile-menu");
    $(".mobile-menu .has-sub").append("<div class=\"submenu-toggle\"/>");
    $(".mobile-menu ul > li a").each(function () {
        var _0xa764xf = $(this),
            _0xa764x10 = _0xa764xf.attr("href").trim(),
            _0xa764x11 = _0xa764x10.toLowerCase(),
            _0xa764x12 = _0xa764x10.split("/"),
            _0xa764x13 = _0xa764x12[0];
        if (_0xa764x11.match("mega-menu")) {
            _0xa764xf.attr("href", "/search/label/" + _0xa764x13 + "?&max-results=" + postPerPage)
        }
    });
    $(".slide-menu-toggle").on("click", function () {
        $("body").toggleClass("nav-active")
    });
    $(".mobile-menu ul li .submenu-toggle").on("click", function (_0xa764xf) {
        if ($(this).parent().hasClass("has-sub")) {
            _0xa764xf.preventDefault();
            if (!$(this).parent().hasClass("show")) {
                $(this).parent().addClass("show").children(".m-sub").slideToggle(170)
            } else {
                $(this).parent().removeClass("show").find("> .m-sub").slideToggle(170)
            }
        }
    });
    $(".show-search").on("click", function () {
        $("#nav-search").fadeIn(250).find("input").focus()
    });
    $(".hide-search").on("click", function () {
        $("#nav-search").fadeOut(250).find("input").blur()
    });
    $(".post-shop-info").each(function () {
        var _0xa764xf = $(this),
            _0xa764x14 = _0xa764xf.data("id");
        $.ajax({
            url: "/feeds/posts/default/" + _0xa764x14 + "?alt=json",
            type: "get",
            dataType: "jsonp",
            success: function (_0xa764x15) {
                var _0xa764x16 = _0xa764x15.entry.content.$t,
                    _0xa764x17 = $("<div>").html(_0xa764x16),
                    _0xa764x18 = _0xa764x17.find("strike:contains(\"price/\")"),
                    _0xa764x19 = _0xa764x17.find("strike:contains(\"off/\")");
                if (_0xa764x18.length > 0) {
                    var _0xa764x1a = _0xa764x18.text(),
                        _0xa764x1b = _0xa764x1a.split("/"),
                        _0xa764x1c = _0xa764x1b[1];
                    _0xa764xf.find(".meta-price").text(_0xa764x1c).parent().addClass("show")
                };
                if (_0xa764x19.length > 0) {
                    var _0xa764x1a = _0xa764x19.text(),
                        _0xa764x1b = _0xa764x1a.split("/"),
                        _0xa764x1d = _0xa764x1b[1];
                    _0xa764xf.find(".product_off").text(_0xa764x1d).addClass("show")
                }
            }
        })
    });
    $(".product-post .post-body").each(function () {
        var _0xa764xf = $(this),
            _0xa764x18 = _0xa764xf.find("strike:contains(\"price/\")"),
            _0xa764x19 = _0xa764xf.find("strike:contains(\"off/\")");
        if (_0xa764x18.length > 0) {
            var _0xa764x1a = _0xa764x18.text(),
                _0xa764x1b = _0xa764x1a.split("/"),
                _0xa764x1c = _0xa764x1b[1];
            $(".product-header").find(".meta-price").text(_0xa764x1c).parent().addClass("show");
            _0xa764x18.hide()
        };
        if (_0xa764x19.length > 0) {
            var _0xa764x1a = _0xa764x19.text(),
                _0xa764x1b = _0xa764x1a.split("/"),
                _0xa764x1d = _0xa764x1b[1];
            $(".product-header").find(".product_off").text(_0xa764x1d).addClass("show");
            _0xa764x19.hide()
        }
    });
    $(".item_add").click(function () {
        var _0xa764xf = $(this);
        _0xa764xf.toggleClass("productad")
    });
    $(".product-post .post-body").each(function () {
        $(this).find("img:first").remove();
        $(this).find("img").show()
    });
    $(".Label a, a.b-label").attr("href", function (_0xa764xf, _0xa764x1e) {
        return _0xa764x1e.replace(_0xa764x1e, _0xa764x1e + "?&max-results=" + postPerPage)
    });
    $(".avatar-image-container img").attr("src", function (_0xa764xf, _0xa764x4) {
        _0xa764x4 = _0xa764x4.replace("/s35-c/", "/s45-c/");
        _0xa764x4 = _0xa764x4.replace("//img1.blogblog.com/img/blank.gif", "//4.bp.blogspot.com/-uCjYgVFIh70/VuOLn-mL7PI/AAAAAAAADUs/Kcu9wJbv790hIo83rI_s7lLW3zkLY01EA/s55-r/avatar.png");
        return _0xa764x4
    });
    $(".author-description a").each(function () {
        $(this).attr("target", "_blank")
    });
    $(".post-nav").each(function () {
        var _0xa764x1f = $("a.prev-post-link").attr("href"),
            _0xa764x20 = $("a.next-post-link").attr("href");
        $.ajax({
            url: _0xa764x1f,
            type: "get",
            success: function (_0xa764x21) {
                var _0xa764x22 = $(_0xa764x21).find(".blog-post h1.post-title").text();
                $(".post-prev a .post-nav-inner p").text(_0xa764x22)
            }
        });
        $.ajax({
            url: _0xa764x20,
            type: "get",
            success: function (_0xa764x23) {
                var _0xa764x22 = $(_0xa764x23).find(".blog-post h1.post-title").text();
                $(".post-next a .post-nav-inner p").text(_0xa764x22)
            }
        })
    });
    $(".post-body strike").each(function () {
        var _0xa764xf = $(this),
            _0xa764x11 = _0xa764xf.text();
        if (_0xa764x11.match("left-sidebar")) {
            _0xa764xf.replaceWith("<style>.item #main-wrapper{float:right}.item #sidebar-wrapper{float:left}</style>")
        };
        if (_0xa764x11.match("right-sidebar")) {
            _0xa764xf.replaceWith("<style>.item #main-wrapper{float:left}.item #sidebar-wrapper{float:right}</style>")
        };
        if (_0xa764x11.match("full-width")) {
            _0xa764xf.replaceWith("<style>.item #main-wrapper{width:100%}.item #sidebar-wrapper{display:none}</style>")
        }
    });
    $("#main-wrapper, #sidebar-wrapper").each(function () {
        if (fixedSidebar == true) {
            $(this).theiaStickySidebar({
                additionalMarginTop: 30,
                additionalMarginBottom: 30
            })
        }
    });
    $(".back-top").each(function () {
        var _0xa764xf = $(this);
        $(window).on("scroll", function () {
            $(this).scrollTop() >= 100 ? _0xa764xf.fadeIn(250) : _0xa764xf.fadeOut(250)
        }), _0xa764xf.click(function () {
            $("html, body").animate({
                scrollTop: 0
            }, 500)
        })
    });
    $("#main-menu #main-menu-nav li").each(function () {
        var _0xa764x24 = $(this),
            _0xa764x10 = _0xa764x24.find("a").attr("href").trim(),
            _0xa764xf = _0xa764x24,
            _0xa764x11 = _0xa764x10.toLowerCase(),
            _0xa764x12 = _0xa764x10.split("/"),
            _0xa764x13 = _0xa764x12[0];
        _0xa764x37(_0xa764xf, _0xa764x11, 5, _0xa764x13)
    });
    $("#hot-section .widget-content").each(function () {
        var _0xa764xf = $(this),
            _0xa764x10 = _0xa764xf.text().trim(),
            _0xa764x11 = _0xa764x10.toLowerCase(),
            _0xa764x12 = _0xa764x10.split("/"),
            _0xa764x13 = _0xa764x12[0];
        _0xa764x37(_0xa764xf, _0xa764x11, 4, _0xa764x13)
    });
    $(".common-widget .widget-content").each(function () {
        var _0xa764xf = $(this),
            _0xa764x10 = _0xa764xf.text().trim(),
            _0xa764x11 = _0xa764x10.toLowerCase(),
            _0xa764x12 = _0xa764x10.split("/"),
            _0xa764x25 = _0xa764x12[0],
            _0xa764x13 = _0xa764x12[1];
        _0xa764x37(_0xa764xf, _0xa764x11, _0xa764x25, _0xa764x13)
    });
    $(".related-ready").each(function () {
        var _0xa764xf = $(this),
            _0xa764x13 = _0xa764xf.find(".related-tag").data("label");
        _0xa764x37(_0xa764xf, "related", 3, _0xa764x13)
    });
    function _0xa764x26(_0xa764x27, _0xa764x4) {
        for (var _0xa764x28 = 0; _0xa764x28 < _0xa764x27[_0xa764x4].link.length; _0xa764x28++) {
            if (_0xa764x27[_0xa764x4].link[_0xa764x28].rel == "alternate") {
                var _0xa764x29 = _0xa764x27[_0xa764x4].link[_0xa764x28].href;
                break
            }
        };
        return _0xa764x29
    }
    function _0xa764x2a(_0xa764x27, _0xa764x4, _0xa764x29) {
        var _0xa764x2b = _0xa764x27[_0xa764x4].title.$t,
            _0xa764x2c = "<a href=\"" + _0xa764x29 + "\">" + _0xa764x2b + "</a>";
        return _0xa764x2c
    }
    function _0xa764x2d(_0xa764x27, _0xa764x4) {
        var _0xa764x2b = _0xa764x27[_0xa764x4].title.$t,
            _0xa764x2e = _0xa764x27[_0xa764x4].content.$t,
            _0xa764x2f = $("<div>").html(_0xa764x2e);
        if ("media$thumbnail" in _0xa764x27[_0xa764x4]) {
            var _0xa764x30 = _0xa764x27[_0xa764x4].media$thumbnail.url,
                _0xa764x31 = _0xa764x30.replace("/s72-c", "/w680");
            if (_0xa764x2e.indexOf("youtube.com/embed") > -1) {
                _0xa764x31 = _0xa764x30.replace("/default.", "/hqdefault.")
            }
        } else {
            if (_0xa764x2e.indexOf("<img") > -1) {
                _0xa764x31 = _0xa764x2f.find("img:first").attr("src")
            } else {
                _0xa764x31 = noThumbnail
            }
        };
        var _0xa764x2c = "<img class=\"post-thumb\" alt=\"" + _0xa764x2b + "\" src=\"" + _0xa764x31 + "\"/>";
        return _0xa764x2c
    }
    function _0xa764x32(_0xa764x27, _0xa764x4) {
        var _0xa764x2e = _0xa764x27[_0xa764x4].content.$t,
            _0xa764x2f = $("<div>").html(_0xa764x2e),
            _0xa764x33 = _0xa764x2f.find("strike:contains(\"price/\")"),
            _0xa764x34 = _0xa764x2f.find("strike:contains(\"off/\")");
        if (_0xa764x33.length > 0) {
            var _0xa764x1a = _0xa764x33.text(),
                _0xa764x1b = _0xa764x1a.split("/"),
                _0xa764x1c = _0xa764x1b[1]
        };
        if (_0xa764x34.length > 0) {
            var _0xa764x1a = _0xa764x34.text(),
                _0xa764x1b = _0xa764x1a.split("/"),
                _0xa764x1d = _0xa764x1b[1]
        };
        if (_0xa764x1c != undefined) {
            var _0xa764x35 = "<span class=\"meta-price\">" + _0xa764x1c + "</span>"
        } else {
            _0xa764x35 = ""
        };
        if (_0xa764x1d != undefined) {
            var _0xa764x36 = "<span class=\"product_off show\">" + _0xa764x1d + "</span>"
        } else {
            _0xa764x36 = ""
        };
        var _0xa764x2c = [_0xa764x35, _0xa764x36];
        return _0xa764x2c
    }
    function _0xa764x37(_0xa764xf, _0xa764x11, _0xa764x25, _0xa764x13) {
        if (_0xa764x11.match("mega-menu") || _0xa764x11.match("hot-posts") || _0xa764x11.match("featured") || _0xa764x11.match("post-list") || _0xa764x11.match("related")) {
            var _0xa764x38 = "";
            if (_0xa764x13 == "recent") {
                _0xa764x38 = "/feeds/posts/default?alt=json-in-script&max-results=" + _0xa764x25
            } else {
                if (_0xa764x13 == "random") {
                    var _0xa764x39 = Math.floor(Math.random() * _0xa764x25) + 1;
                    _0xa764x38 = "/feeds/posts/default?max-results=" + _0xa764x25 + "&start-index=" + _0xa764x39 + "&alt=json-in-script"
                } else {
                    _0xa764x38 = "/feeds/posts/default/-/" + _0xa764x13 + "?alt=json-in-script&max-results=" + _0xa764x25
                }
            };
            $.ajax({
                url: _0xa764x38,
                type: "get",
                dataType: "jsonp",
                beforeSend: function () {
                    if (_0xa764x11.match("hot-posts")) {
                        _0xa764xf.html("<div class=\"hot-loader\"/>").parent().addClass("show-hot")
                    }
                },
                success: function (_0xa764x3a) {
                    if (_0xa764x11.match("mega-menu")) {
                        var _0xa764x3b = "<ul class=\"mega-menu-inner\">"
                    } else {
                        if (_0xa764x11.match("hot-posts")) {
                            var _0xa764x3b = "<ul class=\"hot-posts\">"
                        } else {
                            if (_0xa764x11.match("post-list")) {
                                var _0xa764x3b = "<ul class=\"custom-widget\">"
                            } else {
                                if (_0xa764x11.match("related")) {
                                    var _0xa764x3b = "<ul class=\"related-posts\">"
                                }
                            }
                        }
                    };
                    var _0xa764x3c = _0xa764x3a.feed.entry;
                    if (_0xa764x3c != undefined) {
                        for (var _0xa764x4 = 0, _0xa764x27 = _0xa764x3c; _0xa764x4 < _0xa764x27.length; _0xa764x4++) {
                            var _0xa764x29 = _0xa764x26(_0xa764x27, _0xa764x4),
                                _0xa764x22 = _0xa764x2a(_0xa764x27, _0xa764x4, _0xa764x29),
                                _0xa764x3d = _0xa764x2d(_0xa764x27, _0xa764x4),
                                _0xa764x3e = _0xa764x32(_0xa764x27, _0xa764x4);
                            var _0xa764x3f = "";
                            if (_0xa764x11.match("mega-menu")) {
                                _0xa764x3f += "<div class=\"mega-item item-" + _0xa764x4 + "\"><div class=\"mega-content\"><div class=\"post-image-wrap\"><a class=\"post-image-link\" href=\"" + _0xa764x29 + "\">" + _0xa764x3d + "</a>" + _0xa764x3e[1] + "</div><h2 class=\"post-title\">" + _0xa764x22 + "</h2>" + _0xa764x3e[0] + "</div></div>"
                            } else {
                                if (_0xa764x11.match("hot-posts")) {
                                    _0xa764x3f += "<li class=\"hot-item item-" + _0xa764x4 + "\"><div class=\"hot-item-inner\"><a class=\"post-image-link\" href=\"" + _0xa764x29 + "\">" + _0xa764x3d + "</a>" + _0xa764x3e[1] + "<div class=\"product-info\"><h2 class=\"post-title\">" + _0xa764x22 + "</h2>" + _0xa764x3e[0] + "</div></div></li>"
                                } else {
                                    if (_0xa764x11.match("post-list")) {
                                        _0xa764x3f += "<li class=\"item-" + _0xa764x4 + "\"><a class=\"post-image-link\" href=\"" + _0xa764x29 + "\">" + _0xa764x3d + "</a><div class=\"product-info\"><h2 class=\"post-title\">" + _0xa764x22 + "</h2>" + _0xa764x3e[0] + "</div></div></li>"
                                    } else {
                                        if (_0xa764x11.match("related")) {
                                            _0xa764x3f += "<li class=\"related-item item-" + _0xa764x4 + "\"><div class=\"post-image-wrap\"><a class=\"post-image-link\" href=\"" + _0xa764x29 + "\">" + _0xa764x3d + "</a>" + _0xa764x3e[1] + "</div><h2 class=\"post-title\">" + _0xa764x22 + "</h2>" + _0xa764x3e[0] + "</li>"
                                        }
                                    }
                                }
                            };
                            _0xa764x3b += _0xa764x3f
                        };
                        _0xa764x3b += "</ul>"
                    } else {
                        _0xa764x3b = "<ul class=\"no-posts\">Error: No Posts Found <i class=\"fa fa-frown\"/></ul>"
                    };
                    if (_0xa764x11.match("mega-menu")) {
                        _0xa764xf.addClass("has-sub mega-menu").append(_0xa764x3b);
                        _0xa764xf.find("a:first").attr("href", function (_0xa764xf, _0xa764x1e) {
                            if (_0xa764x13 == "recent" || _0xa764x13 == "random") {
                                _0xa764x1e = _0xa764x1e.replace(_0xa764x1e, "/search/?&max-results=" + postPerPage)
                            } else {
                                _0xa764x1e = _0xa764x1e.replace(_0xa764x1e, "/search/label/" + _0xa764x13 + "?&max-results=" + postPerPage)
                            };
                            return _0xa764x1e
                        })
                    } else {
                        if (_0xa764x11.match("hot-posts")) {
                            _0xa764xf.html(_0xa764x3b).parent().addClass("show-hot")
                        } else {
                            _0xa764xf.html(_0xa764x3b)
                        }
                    }
                }
            })
        }
    }
    $(".blog-post-comments").each(function () {
        var _0xa764x40 = commentsSystem,
            _0xa764x41 = disqus_blogger_current_url,
            _0xa764x42 = "<div id=\"disqus_thread\"/>",
            _0xa764x43 = $(location).attr("href"),
            _0xa764x44 = "<div class=\"fb-comments\" data-width=\"100%\" data-href=\"" + _0xa764x43 + "\" data-numposts=\"5\"></div>",
            _0xa764x45 = "comments-system-" + _0xa764x40;
        if (_0xa764x40 == "blogger") {
            $(this).addClass(_0xa764x45).show()
        } else {
            if (_0xa764x40 == "disqus") {
                (function () {
                    var _0xa764x46 = document.createElement("script");
                    _0xa764x46.type = "text/javascript";
                    _0xa764x46.async = true;
                    _0xa764x46.src = "//" + disqusShortname + ".disqus.com/embed.js";
                    (document.getElementsByTagName("head")[0] || document.getElementsByTagName("body")[0]).appendChild(_0xa764x46)
                })();
                $("#comments, #gpluscomments").remove();
                $(this).append(_0xa764x42).addClass(_0xa764x45).show()
            } else {
                if (_0xa764x40 == "facebook") {
                    $("#comments, #gpluscomments").remove();
                    $(this).append(_0xa764x44).addClass(_0xa764x45).show()
                } else {
                    if (_0xa764x40 == "hide") {
                        $(this).hide()
                    } else {
                        $(this).addClass("comments-system-default").show()
                    }
                }
            }
        }
    })
})
//]]>
</script>  
  
<script>
//<![CDATA[
const players = Array.from(document.querySelectorAll('.js-player')).map(sethPlyr => new Plyr(sethPlyr));
//]]>
</script>  

<!-- Mobile Menu, Overlay and Back To Top --> 
<div id='slide-menu'>
  <div class='slide-menu-header'>
    <div class='mobile-logo'/>
    <span class='hide-mobile-menu'/>
  </div>
  <div class='slide-menu-flex'>
    <div class='mobile-menu' id='mobile-menu'/>
    <div class='social-mobile'/>
  </div>
</div>
<div class='overlay'/>
<div class='back-top' title='Back to Top'/>
</body>
</html>